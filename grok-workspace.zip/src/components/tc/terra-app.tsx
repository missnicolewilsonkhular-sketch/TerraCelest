import { useEffect, useRef, useState } from "react";
import { toast, Toaster } from "sonner";
import { Bell, Home, LayoutGrid, Menu, Plus, Search } from "lucide-react";
import { greeting, t, USERS, type CopyKey, type UserId } from "@/lib/tc/model";
import { liveSession, unreadCount, useTc, type TableKey } from "@/lib/tc/store";
import { Mark, Wordmark } from "@/components/tc/mark";
import { Sheet } from "@/components/tc/chrome";
import {
  CreateMenu,
  DetailBody,
  FormBody,
  HomeScreen,
  MenuBody,
  OfficeScreen,
  PayBody,
  SettingsBody,
  TABLE_META,
  TableScreen,
  UpdatesScreen,
} from "@/components/tc/screens";

type Phase = "splash" | "login" | "app";
type Page = { name: "home" } | { name: "office" } | { name: "updates" } | { name: "table"; table: TableKey };
type Overlay =
  | null
  | { kind: "menu" }
  | { kind: "settings" }
  | { kind: "create" }
  | { kind: "detail"; table: TableKey; id: string }
  | { kind: "form"; table: TableKey; id?: string }
  | { kind: "pay"; bookingId: string };

const STEPS = ["Opening your workspace", "Checking your session", "Loading today’s jobs", "Ready"];

export function TerraApp() {
  const theme = useTc((s) => s.theme);
  const lang = useTc((s) => s.lang);
  const session = useTc((s) => s.session);
  const login = useTc((s) => s.login);
  const logout = useTc((s) => s.logout);
  const sync = useTc((s) => s.sync);
  const markFeedRead = useTc((s) => s.markFeedRead);
  const feed = useTc((s) => s.feed);
  const softDelete = useTc((s) => s.softDelete);
  const restore = useTc((s) => s.restore);

  const [phase, setPhase] = useState<Phase>("splash");
  const [ready, setReady] = useState(false);
  const [waited, setWaited] = useState(false);
  const [page, setPage] = useState<Page>({ name: "home" });
  const [overlay, setOverlay] = useState<Overlay>(null);
  const [query, setQuery] = useState("");
  const [lastTable, setLastTable] = useState<TableKey | null>(null);
  const [confirm, setConfirm] = useState<{ title: string; message: string; onYes: () => void } | null>(null);

  useEffect(() => {
    document.documentElement.dataset.theme = theme === "default" ? "" : theme;
  }, [theme]);

  useEffect(() => {
    let settled = false;
    const finish = () => {
      if (!settled) {
        settled = true;
        setReady(true);
      }
    };
    const unsub = useTc.persist.onFinishHydration(finish);
    if (useTc.persist.hasHydrated()) finish();
    const timer = window.setTimeout(() => setWaited(true), 1500);
    return () => {
      unsub();
      window.clearTimeout(timer);
    };
  }, []);

  useEffect(() => {
    if (!ready || !waited || phase !== "splash") return;
    const live = liveSession(useTc.getState().session);
    if (useTc.getState().session && !live) useTc.getState().logout();
    setPhase(live ? "app" : "login");
  }, [ready, waited, phase]);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") {
        setConfirm(null);
        setOverlay(null);
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        document.getElementById("tc-search")?.focus();
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "n") {
        e.preventDefault();
        openCreate();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const user = USERS.find((u) => u.id === liveSession(session)?.userId);
  const unread = unreadCount(feed);
  const helloKey = greeting() as CopyKey;

  function openTable(table: TableKey) {
    setLastTable(table);
    setPage({ name: "table", table });
    setOverlay(null);
    setQuery("");
  }

  function openCreate() {
    if (page.name === "table" && page.table !== "invoices" && page.table !== "payments") {
      setOverlay({ kind: "form", table: page.table });
      return;
    }
    setOverlay({ kind: "create" });
  }

  function askDelete(table: TableKey, id: string, name: string) {
    setConfirm({
      title: `Delete “${name}”?`,
      message: "It leaves the active lists. Undo is available for a few seconds. Records are not wiped forever.",
      onYes: () => {
        softDelete(table, id);
        setOverlay(null);
        setConfirm(null);
        toast(`${name} removed`, { action: { label: "Undo", onClick: () => restore(table, id) } });
      },
    });
  }

  const shortName = user ? user.name.replace(/^Miss\s+/, "").split(" ")[0] : "";
  const title =
    page.name === "home"
      ? user
        ? `${t(lang, helloKey)}, ${shortName}`
        : "Command"
      : page.name === "office"
        ? t(lang, "office")
        : page.name === "updates"
          ? t(lang, "updates")
          : TABLE_META[page.table].label;

  return (
    <div className="min-h-dvh bg-navy text-ink lg:grid lg:grid-cols-[minmax(0,1fr)_430px]">
      <aside className="hidden flex-col justify-between px-10 py-12 text-on-navy lg:flex">
        <div>
          <div className="flex items-center gap-5">
            <span className="grid size-24 place-items-center rounded-3xl bg-paper shadow-lg">
              <Mark className="h-16" />
            </span>
            <div>
              <p className="text-3xl font-extrabold tracking-wide text-on-navy">TERRA CELEST</p>
              <p className="mt-1 text-sm font-bold tracking-brand text-teal">FACILITIES</p>
            </div>
          </div>
          <p className="mt-8 text-xs font-bold tracking-brand text-aqua">CLEAN SPACES. BETTER PLACES.</p>
          <h1 className="mt-3 max-w-md text-4xl font-extrabold leading-tight text-balance">The floor, from quote to the last room.</h1>
          <p className="mt-6 max-w-sm text-sm leading-relaxed text-pretty text-on-navy/80">
            Bookings, deposits, internal costing and the team that shows up across Ekurhuleni.
          </p>
        </div>
        <div className="flex gap-6 text-xs font-extrabold tracking-brand text-aqua">
          <span>EMPOWER</span>
          <span>INNOVATE</span>
          <span>ELEVATE</span>
        </div>
      </aside>

      <div className="relative mx-auto flex h-dvh w-full max-w-[430px] flex-col overflow-hidden bg-canvas shadow-2xl">
        <Toaster position="top-center" />
        {phase === "splash" ? <Splash /> : null}
        {phase === "login" ? <Login onLogin={(id) => { login(id); setPhase("app"); }} /> : null}
        {phase === "app" ? (
          <>
            <header className="shrink-0 px-4 pt-4 pb-2">
              <div className="flex items-center gap-3">
                {page.name === "table" ? (
                  <button type="button" className="text-xs font-extrabold text-teal" onClick={() => setPage({ name: "office" })}>
                    Office
                  </button>
                ) : (
                  <Mark className="h-10" />
                )}
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-extrabold tracking-brand text-teal">TERRA CELEST</p>
                  <h1 className="truncate text-lg font-extrabold text-ink">{title}</h1>
                </div>
                <button
                  type="button"
                  className="h-11 rounded-full px-3 text-xs font-extrabold text-teal"
                  onClick={() => {
                    sync();
                    toast.success("Workspace synced");
                  }}
                >
                  Sync
                </button>
              </div>
              {page.name === "home" || page.name === "table" ? (
                <label className="mt-3 flex h-12 items-center gap-2 rounded-2xl border border-line bg-paper px-3">
                  <Search className="size-4 text-teal" />
                  <input
                    id="tc-search"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder={t(lang, "search")}
                    className="h-full w-full bg-transparent text-sm font-semibold text-ink outline-none placeholder:text-muted"
                  />
                </label>
              ) : (
                <p className="mt-1 text-xs font-medium text-muted">{page.name === "updates" ? "Creates, payments, quotes and fleet notes." : "Department tables. Tap one to work the list."}</p>
              )}
            </header>
            <main className="min-h-0 flex-1 overflow-y-auto">
              {page.name === "home" ? (
                <HomeScreen lang={lang} query={query} onOpen={openTable} onDetail={(table, id) => setOverlay({ kind: "detail", table, id })} />
              ) : null}
              {page.name === "office" ? <OfficeScreen lastTable={lastTable} onOpen={openTable} /> : null}
              {page.name === "updates" ? <UpdatesScreen /> : null}
              {page.name === "table" ? (
                <TableScreen
                  table={page.table}
                  query={query}
                  onDetail={(id) => setOverlay({ kind: "detail", table: page.table, id })}
                  onCreate={() => setOverlay({ kind: "form", table: page.table })}
                />
              ) : null}
            </main>
            <nav className="relative grid h-[4.5rem] shrink-0 grid-cols-5 border-t border-line bg-paper pb-nav">
              <NavButton label={t(lang, "home")} active={page.name === "home"} onClick={() => { setPage({ name: "home" }); setQuery(""); }}>
                <Home className="size-5" />
              </NavButton>
              <NavButton label={t(lang, "office")} active={page.name === "office" || page.name === "table"} onClick={() => { setPage({ name: "office" }); setQuery(""); }}>
                <LayoutGrid className="size-5" />
              </NavButton>
              <div className="relative">
                <button
                  type="button"
                  aria-label="Create"
                  onClick={openCreate}
                  className="absolute -top-5 left-1/2 grid size-14 -translate-x-1/2 place-items-center rounded-full bg-teal text-on-teal shadow-lg active:scale-95"
                >
                  <Plus className="size-6" />
                </button>
              </div>
              <NavButton
                label={t(lang, "updates")}
                active={page.name === "updates"}
                badge={unread}
                onClick={() => {
                  setPage({ name: "updates" });
                  markFeedRead();
                }}
              >
                <Bell className="size-5" />
              </NavButton>
              <NavButton label={t(lang, "menu")} active={overlay?.kind === "menu"} onClick={() => setOverlay({ kind: "menu" })}>
                <Menu className="size-5" />
              </NavButton>
            </nav>

            {overlay?.kind === "menu" ? (
              <div className="absolute inset-0 z-40 flex bg-navy/45" onClick={() => setOverlay(null)}>
                <div className="h-full w-[84%] max-w-xs shadow-xl" onClick={(e) => e.stopPropagation()}>
                  <MenuBody
                    name={user?.name ?? "Team"}
                    role={user?.role ?? ""}
                    onOpen={openTable}
                    onSettings={() => setOverlay({ kind: "settings" })}
                    onLogout={() => {
                      setConfirm({
                        title: "Log out?",
                        message: "You will need a PIN to come back in. Today’s jobs stay on this phone.",
                        onYes: () => {
                          logout();
                          setConfirm(null);
                          setOverlay(null);
                          setPhase("login");
                        },
                      });
                    }}
                  />
                </div>
              </div>
            ) : null}

            {overlay?.kind === "settings" ? (
              <Sheet title="Settings" onClose={() => setOverlay(null)}>
                <SettingsBody onClose={() => setOverlay(null)} />
              </Sheet>
            ) : null}
            {overlay?.kind === "create" ? (
              <Sheet title="Create" onClose={() => setOverlay(null)}>
                <CreateMenu onPick={(table) => { setLastTable(table); setPage({ name: "table", table }); setOverlay({ kind: "form", table }); }} />
              </Sheet>
            ) : null}
            {overlay?.kind === "detail" ? (
              <Sheet title={TABLE_META[overlay.table].label} onClose={() => setOverlay(null)}>
                <DetailBody
                  table={overlay.table}
                  id={overlay.id}
                  onEdit={() => setOverlay({ kind: "form", table: overlay.table, id: overlay.id })}
                  onDelete={(name) => askDelete(overlay.table, overlay.id, name)}
                  onPay={() => setOverlay({ kind: "pay", bookingId: overlay.id })}
                />
              </Sheet>
            ) : null}
            {overlay?.kind === "form" ? (
              <Sheet title={overlay.id ? `Edit ${TABLE_META[overlay.table].label}` : `New ${TABLE_META[overlay.table].label.replace(/s$/, "")}`} onClose={() => setOverlay(null)}>
                <FormBody table={overlay.table} id={overlay.id} onDone={() => setOverlay(null)} />
              </Sheet>
            ) : null}
            {overlay?.kind === "pay" ? (
              <Sheet title="Log payment" onClose={() => setOverlay(null)}>
                <PayBody bookingId={overlay.bookingId} onDone={() => setOverlay(null)} />
              </Sheet>
            ) : null}
            {confirm ? (
              <div className="absolute inset-0 z-50 grid place-items-center bg-navy/50 px-6" role="dialog" aria-modal="true" aria-label={confirm.title}>
                <div className="w-full rounded-3xl bg-paper p-5 text-center">
                  <h2 className="text-lg font-extrabold text-ink">{confirm.title}</h2>
                  <p className="mt-2 text-sm leading-relaxed text-muted">{confirm.message}</p>
                  <div className="mt-4 grid grid-cols-2 gap-2">
                    <button type="button" className="h-12 rounded-2xl border border-line text-sm font-extrabold" onClick={() => setConfirm(null)}>Cancel</button>
                    <button type="button" className="h-12 rounded-2xl bg-navy text-sm font-extrabold text-on-navy" onClick={confirm.onYes}>Yes, proceed</button>
                  </div>
                </div>
              </div>
            ) : null}
          </>
        ) : null}
      </div>
    </div>
  );
}

function NavButton({
  label,
  active,
  onClick,
  children,
  badge = 0,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
  badge?: number;
}) {
  return (
    <button type="button" onClick={onClick} className={`flex flex-col items-center justify-center gap-0.5 text-xs font-extrabold ${active ? "text-teal" : "text-muted"}`}>
      <span className="relative">
        {children}
        {badge > 0 ? <span className="absolute -top-1 -right-2 grid min-w-4 place-items-center rounded-full bg-teal px-1 text-[10px] text-on-teal">{badge}</span> : null}
      </span>
      {label}
    </button>
  );
}

function Splash() {
  return (
    <div className="tc-splash flex h-full flex-col justify-between px-6 py-10 text-on-navy">
      <div>
        <span className="grid size-24 place-items-center rounded-3xl bg-paper shadow-xl">
          <Mark className="h-16" />
        </span>
        <p className="mt-6 text-2xl font-extrabold tracking-wide">TERRA CELEST</p>
        <p className="mt-1 text-xs font-bold tracking-brand text-on-navy/90">FACILITIES</p>
        <p className="mt-3 text-xs font-semibold tracking-widest">CLEAN SPACES. BETTER PLACES.</p>
      </div>
      <ul className="space-y-3">
        {STEPS.map((step, i) => (
          <li key={step} className="flex items-center gap-3 text-sm font-semibold" style={{ animation: `tc-rise 0.4s ease ${i * 0.28}s both` }}>
            <span className="grid size-6 place-items-center rounded-full bg-paper text-xs font-extrabold text-teal">{i + 1}</span>
            {step}
          </li>
        ))}
      </ul>
    </div>
  );
}

function Login({ onLogin }: { onLogin: (id: UserId) => void }) {
  const [userId, setUserId] = useState<UserId>("phindi");
  const [pin, setPin] = useState("");
  const [shake, setShake] = useState(false);
  const pinRef = useRef("");
  const user = USERS.find((u) => u.id === userId)!;

  function setDigits(next: string) {
    pinRef.current = next;
    setPin(next);
  }

  function push(digit: string) {
    const next = (pinRef.current + digit).slice(0, 4);
    setDigits(next);
    if (next.length < 4) return;
    if (next === user.pin) onLogin(user.id);
    else {
      setShake(true);
      setDigits("");
      toast.error("That PIN does not match this profile.");
      window.setTimeout(() => setShake(false), 400);
    }
  }

  return (
    <div className="flex h-full flex-col bg-canvas px-5 pt-8 pb-6">
      <div className="flex items-center gap-3">
        <Mark className="h-14" />
        <Wordmark />
      </div>
      <h1 className="mt-4 text-2xl font-extrabold text-ink">Sign in</h1>
      <p className="text-xs font-bold tracking-brand text-teal">CLEAN SPACES. BETTER PLACES.</p>
      <p className="mt-2 text-sm font-medium text-muted">Choose your profile, then the 4-digit training PIN.</p>
      <div className="mt-4 grid grid-cols-2 gap-2">
        {USERS.map((u) => (
          <button key={u.id} type="button" onClick={() => { setUserId(u.id); setDigits(""); }} className={`rounded-2xl border px-3 py-3 text-left ${userId === u.id ? "border-teal bg-wash" : "border-line bg-paper"}`}>
            <span className="block text-sm font-extrabold text-ink">{u.name}</span>
            <span className="block text-xs font-semibold text-muted">{u.role}</span>
            <span className="mt-1 block text-xs font-extrabold text-teal">PIN {u.pin}</span>
          </button>
        ))}
      </div>
      <p className="mt-4 text-center text-sm font-extrabold text-ink">{user.name}</p>
      <div className={`mt-2 flex justify-center gap-3 ${shake ? "tc-shake" : ""}`}>
        {[0, 1, 2, 3].map((i) => (
          <span key={i} className={`size-3 rounded-full ${pin.length > i ? "bg-teal" : "bg-line"}`} />
        ))}
      </div>
      <div className="mt-auto grid grid-cols-3 gap-2">
        {["1", "2", "3", "4", "5", "6", "7", "8", "9", "C", "0", "⌫"].map((key) => (
          <button
            key={key}
            type="button"
            className="h-14 rounded-2xl bg-paper text-lg font-extrabold text-ink shadow-sm active:bg-wash"
            onClick={() => {
              if (key === "C") setDigits("");
              else if (key === "⌫") setDigits(pinRef.current.slice(0, -1));
              else push(key);
            }}
          >
            {key}
          </button>
        ))}
      </div>
      <p className="mt-3 text-center text-xs font-semibold text-muted">
        Forgot PIN? Call <a className="text-teal" href="tel:0614679207">061 467 9207</a>
      </p>
    </div>
  );
}

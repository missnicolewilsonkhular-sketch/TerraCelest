import type { ReactNode } from "react";
import { X } from "lucide-react";

export function StatusPill({ status }: { status: string }) {
  const key = status.toLowerCase();
  const solid = ["paid", "completed", "active", "accepted", "done", "in fleet", "received"].includes(key);
  const strong = ["cancelled", "declined", "overdue", "unpaid", "no show", "terminated", "suspended"].includes(key);
  const cls = solid
    ? "bg-teal text-on-teal"
    : strong
      ? "bg-navy text-on-navy"
      : "border border-line bg-paper text-ink";
  return <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-bold ${cls}`}>{status}</span>;
}

export function Sheet({
  title,
  onClose,
  children,
  footer,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
  footer?: ReactNode;
}) {
  return (
    <div className="absolute inset-0 z-40 flex flex-col justify-end bg-navy/45" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="tc-rise flex max-h-[92%] flex-col rounded-t-3xl bg-paper shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mx-auto mt-2 h-1 w-10 rounded-full bg-line" />
        <div className="flex items-center justify-between gap-3 px-4 py-3">
          <h2 className="text-lg font-extrabold tracking-tight text-ink">{title}</h2>
          <button type="button" onClick={onClose} aria-label="Close" className="grid size-11 place-items-center rounded-full text-ink">
            <X className="size-5" />
          </button>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-4">{children}</div>
        {footer ? <div className="border-t border-line p-4 pb-nav">{footer}</div> : null}
      </div>
    </div>
  );
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="mb-3 block">
      <span className="mb-1.5 block text-xs font-bold tracking-wide text-muted uppercase">{label}</span>
      {children}
    </label>
  );
}

export const inputClass =
  "h-12 w-full rounded-2xl border border-line bg-canvas px-3 text-sm font-semibold text-ink outline-none focus:border-teal";

export function PrimaryButton({
  children,
  onClick,
  type = "button",
}: {
  children: ReactNode;
  onClick?: () => void;
  type?: "button" | "submit";
}) {
  return (
    <button type={type} onClick={onClick} className="h-12 w-full rounded-2xl bg-teal text-base font-extrabold text-on-teal active:scale-[0.98]">
      {children}
    </button>
  );
}

export function GhostButton({ children, onClick }: { children: ReactNode; onClick?: () => void }) {
  return (
    <button type="button" onClick={onClick} className="h-12 w-full rounded-2xl border border-line bg-paper text-sm font-bold text-ink">
      {children}
    </button>
  );
}

export function RowCard({
  title,
  meta,
  status,
  trailing,
  onClick,
}: {
  title: string;
  meta: string;
  status?: string;
  trailing?: string;
  onClick: () => void;
}) {
  return (
    <button type="button" onClick={onClick} className="mb-2 flex w-full items-center gap-3 rounded-2xl border border-line bg-paper px-3 py-3 text-left active:bg-wash">
      <span className="min-w-0 flex-1">
        <span className="block truncate text-sm font-extrabold text-ink">{title}</span>
        <span className="mt-0.5 block truncate text-xs font-medium text-muted">{meta}</span>
      </span>
      <span className="flex shrink-0 flex-col items-end gap-1">
        {trailing ? <span className="text-sm font-extrabold text-ink tabular-nums">{trailing}</span> : null}
        {status ? <StatusPill status={status} /> : null}
      </span>
    </button>
  );
}

export function Empty({ title, action, onAction }: { title: string; action: string; onAction: () => void }) {
  return (
    <div className="rounded-3xl border border-dashed border-line bg-paper px-4 py-8 text-center">
      <p className="text-sm font-semibold text-muted">{title}</p>
      <button type="button" onClick={onAction} className="mt-4 h-11 rounded-2xl bg-teal px-4 text-sm font-extrabold text-on-teal">
        {action}
      </button>
    </div>
  );
}

export function SectionLabel({ children }: { children: ReactNode }) {
  return <h3 className="mt-4 mb-2 text-xs font-extrabold tracking-widest text-teal uppercase">{children}</h3>;
}

export function MoneyRow({ label, value, strong = false }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className={`flex items-center justify-between gap-3 border-b border-line py-2 text-sm ${strong ? "font-extrabold text-ink" : "font-semibold text-muted"}`}>
      <span>{label}</span>
      <span className="shrink-0 tabular-nums">{value}</span>
    </div>
  );
}

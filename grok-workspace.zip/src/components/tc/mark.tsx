export function Mark({ className }: { className?: string }) {
  return <img src="/brand-mark.png" alt="" className={`w-auto object-contain ${className ?? ""}`} />;
}

export function Wordmark({ onNavy = false }: { onNavy?: boolean }) {
  return (
    <div>
      <p className={`text-sm font-extrabold tracking-wide ${onNavy ? "text-on-navy" : "text-ink"}`}>TERRA CELEST</p>
      <p className="text-xs font-bold tracking-brand text-teal">FACILITIES</p>
    </div>
  );
}

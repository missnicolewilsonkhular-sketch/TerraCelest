import { useMemo, useState } from "react";
import { toast } from "sonner";
import {
  Archive,
  Building2,
  Calendar,
  ClipboardList,
  FileText,
  MessageSquare,
  Phone,
  Receipt,
  Users,
  Wallet,
  Wrench,
} from "lucide-react";
import {
  active,
  costBooking,
  depositFor,
  EXTRA_ROOM_RATE,
  formatDay,
  formatWhen,
  LABOUR_RATE,
  money,
  serviceById,
  SERVICES,
  timeAgo,
  todayISO,
  USERS,
  vatOf,
  type Booking,
  type BookingStatus,
  type Lang,
  type Quote,
} from "@/lib/tc/model";
import { liveSession, openBookings, useTc, type BookingDraft, type TableKey } from "@/lib/tc/store";
import { Empty, Field, GhostButton, inputClass, MoneyRow, PrimaryButton, RowCard, SectionLabel, StatusPill } from "@/components/tc/chrome";

export const TABLE_META: Record<TableKey, { label: string; group: string; hint: string }> = {
  bookings: { label: "Bookings", group: "Operations", hint: "Jobs on the board" },
  tasks: { label: "Tasks", group: "Operations", hint: "What still needs a person" },
  quotes: { label: "Quotes", group: "Operations", hint: "Proposals and packages" },
  clients: { label: "Clients", group: "People", hint: "People and organisations" },
  properties: { label: "Properties", group: "People", hint: "Addresses we clean" },
  team: { label: "Team", group: "People", hint: "Cleaners and supervisors" },
  invoices: { label: "Internal invoices", group: "Finance", hint: "Costing, not the customer bill" },
  payments: { label: "Payments", group: "Finance", hint: "Deposits and balances" },
  budget: { label: "Budget", group: "Finance", hint: "Supplies and fuel" },
  documents: { label: "Documents", group: "Knowledge", hint: "Contracts and profiles" },
  scripts: { label: "Scripts", group: "Knowledge", hint: "WhatsApp, call, email" },
  equipment: { label: "Equipment", group: "Knowledge", hint: "Tools in the fleet" },
};

export const GROUPS = ["Operations", "People", "Finance", "Knowledge"] as const;

const GROUP_ICON = {
  Operations: Calendar,
  People: Users,
  Finance: Wallet,
  Knowledge: FileText,
} as const;

function qhit(q: string, parts: Array<string | number | undefined>) {
  const n = q.trim().toLowerCase();
  if (!n) return true;
  return parts.join(" ").toLowerCase().includes(n);
}

export function HomeScreen({
  lang,
  query,
  onOpen,
  onDetail,
}: {
  lang: Lang;
  query: string;
  onOpen: (table: TableKey) => void;
  onDetail: (table: TableKey, id: string) => void;
}) {
  const bookings = useTc((s) => s.bookings);
  const clients = useTc((s) => s.clients);
  const quotes = useTc((s) => s.quotes);
  const payments = useTc((s) => s.payments);
  const team = useTc((s) => s.team);
  const feed = useTc((s) => s.feed);
  const today = todayISO();
  const live = active(bookings);
  const open = openBookings(bookings);
  const collect = live
    .filter((b) => b.status !== "Cancelled")
    .reduce((sum, b) => sum + costBooking(b, depositFor(b.id, payments)).balanceDue, 0);
  const onDuty = active(team).filter((m) => m.status === "Active").length;
  const todays = live.filter((b) => b.serviceDate === today);
  const clientName = (id: string) => clients.find((c) => c.id === id)?.name ?? "Client";

  const searching = query.trim().length > 0;
  const foundBookings = live.filter((b) => qhit(query, [b.name, b.ref, b.status, clientName(b.clientId)]));
  const foundClients = active(clients).filter((c) => qhit(query, [c.name, c.ref, c.area, c.phone]));
  const foundQuotes = active(quotes).filter((q) => qhit(query, [q.name, q.ref, q.venue, q.status]));

  return (
    <div className="px-4 pb-6">
      <div className="grid grid-cols-3 gap-2">
        <Stat n={String(open.length)} label="Open jobs" />
        <Stat n={money(collect).replace(".00", "")} label="Still to collect" />
        <Stat n={String(onDuty)} label="On duty" />
      </div>
      <div className="mt-4 rounded-3xl bg-navy px-4 py-4 text-on-navy">
        <p className="text-xs font-extrabold tracking-brand text-aqua">SPRING SPECIAL</p>
        <p className="mt-1 text-xl font-extrabold">R750 · up to 4 rooms</p>
        <p className="mt-1 text-sm text-on-navy/80">Kitchen, lounge, bathroom and bedroom. We bring the products.</p>
      </div>

      {searching ? (
        <div className="mt-4">
          <SectionLabel>Matches</SectionLabel>
          {foundBookings.map((b) => (
            <RowCard
              key={b.id}
              title={clientName(b.clientId)}
              meta={`${b.ref} · ${formatDay(b.serviceDate)}`}
              status={b.status}
              trailing={money(costBooking(b, depositFor(b.id, payments)).revenue)}
              onClick={() => onDetail("bookings", b.id)}
            />
          ))}
          {foundClients.map((c) => (
            <RowCard key={c.id} title={c.name} meta={`${c.ref} · ${c.area}`} status={c.status} onClick={() => onDetail("clients", c.id)} />
          ))}
          {foundQuotes.map((q) => (
            <RowCard key={q.id} title={q.name} meta={q.ref} status={q.status} trailing={money(vatOf(q.exclVat).total)} onClick={() => onDetail("quotes", q.id)} />
          ))}
          {foundBookings.length + foundClients.length + foundQuotes.length === 0 ? (
            <p className="text-sm font-semibold text-muted">Nothing matches that search.</p>
          ) : null}
        </div>
      ) : (
        <>
          <div className="mt-5 flex items-end justify-between">
            <h2 className="text-base font-extrabold text-ink">{lang === "af" ? "Vandag se rondte" : lang === "zu" ? "Umsebenzi wanamuhla" : "Today’s run"}</h2>
            <button type="button" className="text-xs font-bold text-teal" onClick={() => onOpen("bookings")}>
              All bookings
            </button>
          </div>
          <div className="mt-2">
            {todays.length === 0 ? (
              <Empty title="No job is dated for today." action="Open bookings" onAction={() => onOpen("bookings")} />
            ) : (
              todays.map((b) => <BookingRow key={b.id} booking={b} onClick={() => onDetail("bookings", b.id)} />)
            )}
          </div>

          <SectionLabel>Contribution on the board</SectionLabel>
          <div className="rounded-3xl border border-line bg-paper p-3">
            {open.slice(0, 4).map((b) => {
              const cost = costBooking(b, depositFor(b.id, payments));
              const width = Math.min(100, Math.max(8, Math.abs(cost.margin) * 100 * 4));
              return (
                <button key={b.id} type="button" onClick={() => onDetail("bookings", b.id)} className="mb-3 block w-full text-left last:mb-0">
                  <span className="flex items-center justify-between gap-2 text-xs font-bold text-ink">
                    <span className="truncate">{clientName(b.clientId)}</span>
                    <span className="tabular-nums">{money(cost.contribution)}</span>
                  </span>
                  <span className="mt-1 block h-2 overflow-hidden rounded-full bg-wash">
                    <span className="block h-full rounded-full bg-teal" style={{ width: `${width}%` }} />
                  </span>
                </button>
              );
            })}
            <p className="text-xs font-medium text-muted">Spring special at R750 with two cleaners for 4 hours lands near a 9.5% contribution after labour, products, transport and overhead.</p>
          </div>

          <SectionLabel>{lang === "zu" ? "Okusanda kwenzeka" : lang === "af" ? "Onlangse aktiwiteit" : "Recent activity"}</SectionLabel>
          {feed.slice(0, 4).map((f) => (
            <button key={f.id} type="button" onClick={() => onOpen("bookings")} className="mb-2 flex w-full gap-3 rounded-2xl border border-line bg-paper px-3 py-3 text-left">
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-extrabold text-ink">{f.title}</span>
                <span className="mt-0.5 block text-xs font-medium text-muted">{f.body}</span>
              </span>
              <span className="shrink-0 text-xs font-bold text-teal">{timeAgo(f.at)}</span>
            </button>
          ))}
        </>
      )}
    </div>
  );
}

function Stat({ n, label }: { n: string; label: string }) {
  return (
    <div className="rounded-2xl bg-navy px-2 py-3 text-on-navy">
      <div className="truncate text-sm font-extrabold tabular-nums">{n}</div>
      <div className="mt-1 text-[11px] font-semibold text-aqua">{label}</div>
    </div>
  );
}

function BookingRow({ booking, onClick }: { booking: Booking; onClick: () => void }) {
  const clients = useTc((s) => s.clients);
  const properties = useTc((s) => s.properties);
  const payments = useTc((s) => s.payments);
  const client = clients.find((c) => c.id === booking.clientId);
  const property = properties.find((p) => p.id === booking.propertyId);
  const cost = costBooking(booking, depositFor(booking.id, payments));
  return (
    <RowCard
      title={client?.name ?? booking.name}
      meta={`${formatDay(booking.serviceDate)} · ${property?.area ?? ""} · ${serviceById(booking.serviceId).name}`}
      status={booking.status}
      trailing={money(cost.revenue)}
      onClick={onClick}
    />
  );
}

export function OfficeScreen({ lastTable, onOpen }: { lastTable: TableKey | null; onOpen: (t: TableKey) => void }) {
  return (
    <div className="px-4 pb-6">
      <p className="mb-3 text-sm font-medium text-muted">Tables grouped the way the floor uses them. Last opened stays marked.</p>
      {GROUPS.map((group) => {
        const Icon = GROUP_ICON[group];
        const tables = (Object.keys(TABLE_META) as TableKey[]).filter((id) => TABLE_META[id].group === group);
        return (
          <section key={group} className="mb-4">
            <div className="mb-2 flex items-center gap-2 text-ink">
              <Icon className="size-4 text-teal" />
              <h2 className="text-sm font-extrabold">{group}</h2>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {tables.map((id) => {
                const meta = TABLE_META[id];
                const on = lastTable === id;
                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() => onOpen(id)}
                    className={`rounded-2xl border px-3 py-3 text-left ${on ? "border-teal bg-wash" : "border-line bg-paper"}`}
                  >
                    <span className="block text-sm font-extrabold text-ink">{meta.label}</span>
                    <span className="mt-1 block text-xs font-medium text-muted">{meta.hint}</span>
                  </button>
                );
              })}
            </div>
          </section>
        );
      })}
    </div>
  );
}

export function UpdatesScreen() {
  const feed = useTc((s) => s.feed);
  if (feed.length === 0) return <div className="px-4"><Empty title="Activity will show as the team works." action="Back to home" onAction={() => undefined} /></div>;
  return (
    <div className="px-4 pb-6">
      {feed.map((f) => (
        <article key={f.id} className="mb-2 rounded-2xl border border-line bg-paper px-3 py-3">
          <div className="flex items-start justify-between gap-2">
            <h3 className="text-sm font-extrabold text-ink">{f.title}</h3>
            <span className="shrink-0 text-xs font-bold text-teal">{timeAgo(f.at)}</span>
          </div>
          <p className="mt-1 text-xs font-medium leading-relaxed text-muted">{f.body}</p>
        </article>
      ))}
    </div>
  );
}

export function TableScreen({
  table,
  query,
  onDetail,
  onCreate,
}: {
  table: TableKey;
  query: string;
  onDetail: (id: string) => void;
  onCreate: () => void;
}) {
  const [budgetMode, setBudgetMode] = useState<"open" | "archived">("open");
  const [jobFilter, setJobFilter] = useState<"all" | "today" | "open" | "unpaid">("all");
  const data = useTc();
  const meta = TABLE_META[table];

  const rows = useMemo(() => {
    if (table === "bookings") {
      return active(data.bookings)
        .filter((b) => {
          const cost = costBooking(b, depositFor(b.id, data.payments));
          if (jobFilter === "today") return b.serviceDate === todayISO();
          if (jobFilter === "open") return !["Completed", "Cancelled", "No Show"].includes(b.status);
          if (jobFilter === "unpaid") return cost.balanceDue > 0 && b.status !== "Cancelled";
          return true;
        })
        .filter((b) => qhit(query, [b.name, b.ref, b.status, data.clients.find((c) => c.id === b.clientId)?.name]))
        .sort((a, b) => b.serviceDate.localeCompare(a.serviceDate));
    }
    if (table === "clients") return active(data.clients).filter((r) => qhit(query, [r.name, r.ref, r.area, r.phone, r.type]));
    if (table === "properties") return active(data.properties).filter((r) => qhit(query, [r.name, r.address, r.area, r.base]));
    if (table === "team") return active(data.team).filter((r) => qhit(query, [r.name, r.role, r.base, r.status]));
    if (table === "quotes") return active(data.quotes).filter((r) => qhit(query, [r.name, r.ref, r.venue, r.status]));
    if (table === "invoices") return active(data.invoices).filter((r) => qhit(query, [r.ref, r.status, r.notes]));
    if (table === "payments") return active(data.payments).filter((r) => qhit(query, [r.name, r.ref, r.method]));
    if (table === "tasks") return active(data.tasks).filter((r) => qhit(query, [r.name, r.status, r.owner]));
    if (table === "documents") return active(data.documents).filter((r) => qhit(query, [r.name, r.category, r.summary]));
    if (table === "scripts") return active(data.scripts).filter((r) => qhit(query, [r.name, r.type, r.body]));
    if (table === "equipment") return active(data.equipment).filter((r) => qhit(query, [r.name, r.spec, r.base]));
    return active(data.budget).filter((r) => (budgetMode === "archived" ? r.archived : !r.archived) && qhit(query, [r.name, r.category, r.store]));
  }, [table, query, data, budgetMode, jobFilter]);

  return (
    <div className="px-4 pb-6">
      <p className="mb-3 text-sm font-medium text-muted">{meta.hint}</p>
      {table === "bookings" ? (
        <div className="mb-3 flex gap-2 overflow-x-auto">
          {(["all", "today", "open", "unpaid"] as const).map((f) => (
            <button key={f} type="button" onClick={() => setJobFilter(f)} className={`h-9 shrink-0 rounded-full px-3 text-xs font-extrabold capitalize ${jobFilter === f ? "bg-teal text-on-teal" : "bg-paper text-ink border border-line"}`}>
              {f}
            </button>
          ))}
        </div>
      ) : null}
      {table === "budget" ? (
        <div className="mb-3 flex gap-2">
          <button type="button" onClick={() => setBudgetMode("open")} className={`h-9 rounded-full px-3 text-xs font-extrabold ${budgetMode === "open" ? "bg-teal text-on-teal" : "border border-line bg-paper text-ink"}`}>Open</button>
          <button type="button" onClick={() => setBudgetMode("archived")} className={`h-9 rounded-full px-3 text-xs font-extrabold ${budgetMode === "archived" ? "bg-teal text-on-teal" : "border border-line bg-paper text-ink"}`}>Archived</button>
        </div>
      ) : null}
      {rows.length === 0 ? (
        <Empty title={table === "budget" && budgetMode === "archived" ? "Nothing is archived." : `No ${meta.label.toLowerCase()} yet.`} action={`Add ${meta.label.replace(/s$/, "").toLowerCase()}`} onAction={onCreate} />
      ) : (
        rows.map((row) => <TableRow key={row.id} table={table} id={row.id} onClick={() => onDetail(row.id)} />)
      )}
    </div>
  );
}

function TableRow({ table, id, onClick }: { table: TableKey; id: string; onClick: () => void }) {
  const s = useTc();
  if (table === "bookings") {
    const b = s.bookings.find((r) => r.id === id);
    if (!b) return null;
    return <BookingRow booking={b} onClick={onClick} />;
  }
  if (table === "clients") {
    const r = s.clients.find((x) => x.id === id)!;
    return <RowCard title={r.name} meta={`${r.type} · ${r.area} · ${r.phone}`} status={r.status} onClick={onClick} />;
  }
  if (table === "properties") {
    const r = s.properties.find((x) => x.id === id)!;
    const client = s.clients.find((c) => c.id === r.clientId);
    return <RowCard title={r.name} meta={`${client?.name ?? "Client"} · ${r.base} base · ${r.zone}`} onClick={onClick} />;
  }
  if (table === "team") {
    const r = s.team.find((x) => x.id === id)!;
    return <RowCard title={r.name} meta={`${r.role} · ${r.base}`} status={r.status} onClick={onClick} />;
  }
  if (table === "quotes") {
    const r = s.quotes.find((x) => x.id === id)!;
    return <RowCard title={r.name} meta={`${r.ref} · ${r.venue}`} status={r.status} trailing={money(vatOf(r.exclVat).total)} onClick={onClick} />;
  }
  if (table === "invoices") {
    const r = s.invoices.find((x) => x.id === id)!;
    const b = s.bookings.find((x) => x.id === r.bookingId);
    const cost = b ? costBooking(b, depositFor(b.id, s.payments)) : null;
    return <RowCard title={r.ref} meta={b?.name ?? "Booking"} status={cost && cost.balanceDue > 0 && r.status !== "Paid" ? r.status : r.status} trailing={cost ? money(cost.balanceDue) : ""} onClick={onClick} />;
  }
  if (table === "payments") {
    const r = s.payments.find((x) => x.id === id)!;
    return <RowCard title={r.name} meta={`${r.method} · ${formatWhen(r.paidAt)}`} trailing={money(r.amount)} status="Received" onClick={onClick} />;
  }
  if (table === "tasks") {
    const r = s.tasks.find((x) => x.id === id)!;
    return <RowCard title={r.name} meta={`${r.owner} · due ${formatDay(r.due)}`} status={r.status} onClick={onClick} />;
  }
  if (table === "documents") {
    const r = s.documents.find((x) => x.id === id)!;
    return <RowCard title={r.name} meta={`${r.category} · ${r.version}`} status={r.status} onClick={onClick} />;
  }
  if (table === "scripts") {
    const r = s.scripts.find((x) => x.id === id)!;
    return <RowCard title={r.name} meta={`${r.type} · ${r.audience}`} status={r.status} onClick={onClick} />;
  }
  if (table === "equipment") {
    const r = s.equipment.find((x) => x.id === id)!;
    return <RowCard title={r.name} meta={`${r.spec} · ${r.base}`} status={r.status} onClick={onClick} />;
  }
  const r = s.budget.find((x) => x.id === id)!;
  return <RowCard title={r.name} meta={`${r.category} · ${r.store} · qty ${r.qty}`} trailing={money(r.price * r.qty)} status={r.purchased ? "Paid" : "Pending"} onClick={onClick} />;
}

const BOOKING_FLOW: BookingStatus[] = ["Draft", "Pending", "Confirmed", "Assigned", "In Progress", "Completed", "Cancelled", "No Show"];

export function DetailBody({
  table,
  id,
  onEdit,
  onDelete,
  onPay,
}: {
  table: TableKey;
  id: string;
  onEdit: () => void;
  onDelete: (name: string) => void;
  onPay: () => void;
}) {
  const s = useTc();
  if (table === "bookings") {
    const b = s.bookings.find((r) => r.id === id);
    if (!b) return null;
    const client = s.clients.find((c) => c.id === b.clientId);
    const property = s.properties.find((p) => p.id === b.propertyId);
    const cost = costBooking(b, depositFor(b.id, s.payments));
    const invoice = s.invoices.find((i) => i.bookingId === b.id && !i.deleted);
    const crew = s.team.filter((m) => b.teamIds.includes(m.id));
    return (
      <div>
        <div className="flex items-start justify-between gap-2">
          <div>
            <p className="text-xs font-bold text-teal">{b.ref}</p>
            <h3 className="text-xl font-extrabold text-ink">{client?.name}</h3>
            <p className="text-sm font-medium text-muted">{serviceById(b.serviceId).name}</p>
          </div>
          <StatusPill status={b.status} />
        </div>
        <p className="mt-3 text-sm font-semibold text-ink">{property?.address}</p>
        <p className="text-xs font-medium text-muted">{formatDay(b.serviceDate)} · {property?.base} base · {property?.zone} zone · {b.cleaners} cleaners · {b.hours} hrs</p>
        {client?.phone ? (
          <a href={`tel:${client.phone.replace(/\s/g, "")}`} className="mt-3 inline-flex h-11 items-center gap-2 rounded-2xl bg-wash px-3 text-sm font-extrabold text-teal">
            <Phone className="size-4" /> Call {client.phone}
          </a>
        ) : null}
        <div className="mt-3 grid grid-cols-2 gap-2">
          <PrimaryButton onClick={onPay}>Log payment</PrimaryButton>
          <GhostButton onClick={onEdit}>Edit job</GhostButton>
        </div>
        <SectionLabel>Team</SectionLabel>
        <p className="text-sm font-semibold text-ink">{crew.length ? crew.map((m) => m.name).join(", ") : "Not assigned yet"}</p>
        <CostBlock booking={b} />
        {invoice ? <p className="mt-2 text-xs font-bold text-muted">Internal record {invoice.ref} · {invoice.status}</p> : null}
        <SectionLabel>Move the job</SectionLabel>
        <div className="flex flex-wrap gap-2">
          {BOOKING_FLOW.map((st) => (
            <button key={st} type="button" onClick={() => s.setBookingStatus(b.id, st)} className={`h-9 rounded-full px-3 text-xs font-extrabold ${b.status === st ? "bg-navy text-on-navy" : "border border-line bg-paper text-ink"}`}>
              {st}
            </button>
          ))}
        </div>
        {b.notes ? <p className="mt-3 text-sm leading-relaxed text-muted">{b.notes}</p> : null}
        <button type="button" className="mt-3 h-11 w-full text-sm font-bold text-muted" onClick={() => onDelete(client?.name ?? b.ref)}>
          Delete {client?.name}
        </button>
      </div>
    );
  }

  if (table === "invoices") {
    const inv = s.invoices.find((r) => r.id === id);
    const b = inv ? s.bookings.find((x) => x.id === inv.bookingId) : undefined;
    if (!inv || !b) return null;
    const client = s.clients.find((c) => c.id === b.clientId);
    const property = s.properties.find((p) => p.id === b.propertyId);
    return (
      <div>
        <p className="text-xs font-extrabold tracking-widest text-teal">INTERNAL INVOICE</p>
        <h3 className="text-xl font-extrabold text-ink">{inv.ref}</h3>
        <p className="text-sm font-medium text-muted">Costing record · not the customer invoice</p>
        <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
          <Info k="Customer" v={client?.name ?? "—"} />
          <Info k="Booking" v={b.ref} />
          <Info k="Service date" v={formatDay(b.serviceDate)} />
          <Info k="Area" v={property?.area ?? "—"} />
          <Info k="Address" v={property?.address ?? "—"} />
          <Info k="Base" v={property?.base ?? "—"} />
        </div>
        <CostBlock booking={b} />
        <p className="mt-3 text-xs leading-relaxed text-muted">{inv.notes}</p>
        <div className="mt-3 flex flex-wrap gap-2">
          {(["Draft", "Sent", "Partially Paid", "Paid", "Overdue", "Cancelled"] as const).map((st) => (
            <button key={st} type="button" onClick={() => s.setInvoiceStatus(inv.id, st)} className={`h-9 rounded-full px-3 text-xs font-extrabold ${inv.status === st ? "bg-teal text-on-teal" : "border border-line"}`}>
              {st}
            </button>
          ))}
        </div>
      </div>
    );
  }

  if (table === "quotes") {
    const q = s.quotes.find((r) => r.id === id);
    if (!q) return null;
    return <QuoteDetail quote={q} onEdit={onEdit} onDelete={() => onDelete(q.name)} />;
  }

  if (table === "scripts") {
    const r = s.scripts.find((x) => x.id === id);
    if (!r) return null;
    const sample = fillScript(r.body);
    return (
      <div>
        <StatusPill status={r.type} />
        <h3 className="mt-2 text-xl font-extrabold text-ink">{r.name}</h3>
        <p className="text-sm text-muted">{r.audience}</p>
        <pre className="mt-3 whitespace-pre-wrap rounded-2xl bg-wash p-3 font-sans text-sm leading-relaxed text-ink">{sample}</pre>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <PrimaryButton onClick={() => { void navigator.clipboard.writeText(sample).then(() => toast.success("Script copied")); }}>Copy</PrimaryButton>
          <GhostButton onClick={onEdit}>Edit</GhostButton>
        </div>
      </div>
    );
  }

  const simple = simpleDetail(table, id, s);
  if (!simple) return null;
  return (
    <div>
      <div className="flex items-start justify-between gap-2">
        <h3 className="text-xl font-extrabold text-ink">{simple.title}</h3>
        {simple.status ? <StatusPill status={simple.status} /> : null}
      </div>
      <p className="text-xs font-bold text-teal">{simple.ref}</p>
      <div className="mt-3">
        {simple.lines.map((line) => (
          <div key={line.k} className="border-b border-line py-2">
            <div className="text-xs font-bold tracking-wide text-muted uppercase">{line.k}</div>
            <div className="text-sm font-semibold text-ink">{line.v}</div>
          </div>
        ))}
      </div>
      <div className="mt-4 grid grid-cols-2 gap-2">
        {table === "budget" ? (
          <PrimaryButton
            onClick={() => {
              const row = s.budget.find((b) => b.id === id);
              if (!row) return;
              s.archiveBudget(id, !row.archived);
              toast(row.archived ? "Restored to the open list" : "Archived", {
                action: { label: "Undo", onClick: () => s.archiveBudget(id, row.archived) },
              });
            }}
          >
            <span className="inline-flex items-center justify-center gap-2"><Archive className="size-4" /> {s.budget.find((b) => b.id === id)?.archived ? "Restore" : "Archive"}</span>
          </PrimaryButton>
        ) : (
          <PrimaryButton onClick={onEdit}>Edit</PrimaryButton>
        )}
        <GhostButton onClick={() => onDelete(simple.title)}>Delete</GhostButton>
      </div>
      {table === "budget" ? <div className="mt-2"><GhostButton onClick={onEdit}>Edit line</GhostButton></div> : null}
    </div>
  );
}

function Info({ k, v }: { k: string; v: string }) {
  return (
    <div className="rounded-2xl bg-canvas px-3 py-2">
      <div className="text-[11px] font-bold tracking-wide text-muted uppercase">{k}</div>
      <div className="text-sm font-bold text-ink">{v}</div>
    </div>
  );
}

function CostBlock({ booking }: { booking: Booking }) {
  const payments = useTc((s) => s.payments);
  const received = depositFor(booking.id, payments);
  const c = costBooking(booking, received);
  const below = c.contribution < 0;
  return (
    <div className="mt-3 rounded-3xl border border-line bg-canvas p-3">
      <SectionLabel>Revenue</SectionLabel>
      <MoneyRow label={serviceById(booking.serviceId).name} value={money(booking.serviceAmount)} />
      <MoneyRow label={`Additional rooms (${booking.extraRooms} × R${EXTRA_ROOM_RATE})`} value={money(booking.extraRooms * EXTRA_ROOM_RATE)} />
      <MoneyRow label="Additional services" value={money(booking.extraServices)} />
      <MoneyRow label="Logistics / travel" value={money(booking.travelCharge)} />
      <MoneyRow label="Discounts" value={money(-booking.discount)} />
      <MoneyRow label="Customer invoice total" value={money(c.revenue)} strong />
      <SectionLabel>Payment position</SectionLabel>
      <MoneyRow label="Required deposit — 40%" value={money(c.depositRequired)} />
      <MoneyRow label="Deposit received" value={money(c.depositReceived)} />
      <MoneyRow label="Balance due" value={money(c.balanceDue)} strong />
      <MoneyRow label="Balance before cleaning" value={money(c.balanceBeforeCleaning)} />
      <SectionLabel>Internal delivery cost</SectionLabel>
      <MoneyRow label={`Labour · ${c.labourHours} hrs × R${LABOUR_RATE}`} value={money(c.labour)} />
      <MoneyRow label="Cleaning products" value={money(c.products)} />
      <MoneyRow label="Equipment" value={money(c.equipment)} />
      <MoneyRow label="Transport" value={money(c.transport)} />
      <MoneyRow label="Payment processing · 2.5%" value={money(c.processing)} />
      <MoneyRow label="Customer acquisition" value={money(c.acquisition)} />
      <MoneyRow label="Administration" value={money(c.admin)} />
      <MoneyRow label="Risk / contingency" value={money(c.risk)} />
      <MoneyRow label="Total delivery cost" value={money(c.delivery)} strong />
      <div className={`mt-2 rounded-2xl px-3 py-2 ${below ? "bg-paper" : "bg-wash"}`}>
        <MoneyRow label="Estimated contribution" value={money(c.contribution)} strong />
        <MoneyRow label="Contribution margin" value={`${(c.margin * 100).toFixed(2)}%`} strong />
        {below ? <p className="pb-2 text-xs font-bold text-ink">Below cost. Reprice or cut the overhead before you confirm.</p> : null}
      </div>
    </div>
  );
}

function QuoteDetail({ quote, onEdit, onDelete }: { quote: Quote; onEdit: () => void; onDelete: () => void }) {
  const setQuoteStatus = useTc((s) => s.setQuoteStatus);
  const client = useTc((s) => s.clients.find((c) => c.id === quote.clientId));
  const totals = vatOf(quote.exclVat);
  return (
    <div>
      <p className="text-xs font-extrabold tracking-widest text-teal">{quote.ref}</p>
      <h3 className="text-xl font-extrabold text-ink">{quote.name}</h3>
      <p className="text-sm text-muted">Prepared for {client?.name} · {formatDay(quote.proposalDate)}</p>
      <div className="mt-3 rounded-3xl bg-navy p-4 text-on-navy">
        <p className="text-xs font-bold text-aqua">Your event</p>
        <p className="mt-2 text-sm font-semibold">{formatDay(quote.eventDate)}</p>
        <p className="text-lg font-extrabold">{quote.venue}</p>
        {quote.people ? <p className="mt-3 text-3xl font-extrabold text-aqua">{quote.people}<span className="ml-2 text-sm font-bold text-on-navy">people</span></p> : null}
        {quote.dayShift ? <p className="mt-2 text-xs font-semibold">Day · {quote.dayShift}</p> : null}
        {quote.eveningShift ? <p className="text-xs font-semibold">Evening · {quote.eveningShift}</p> : null}
      </div>
      <div className="mt-3 rounded-3xl bg-teal px-4 py-3 text-on-teal">
        <div className="flex justify-between text-sm font-semibold"><span>Excl. VAT</span><span>{money(quote.exclVat)}</span></div>
        <div className="flex justify-between text-sm font-semibold"><span>VAT 15%</span><span>{money(totals.vat)}</span></div>
        <div className="mt-1 flex justify-between text-base font-extrabold"><span>Total quotation</span><span>{money(totals.total)}</span></div>
      </div>
      <ul className="mt-3 space-y-1">
        {quote.scope.map((item) => (
          <li key={item} className="text-sm font-medium text-ink">• {item}</li>
        ))}
      </ul>
      <p className="mt-3 text-sm leading-relaxed text-muted">{quote.notes}</p>
      <div className="mt-3 flex flex-wrap gap-2">
        {(["Draft", "Sent", "Accepted", "Declined", "Expired"] as const).map((st) => (
          <button key={st} type="button" onClick={() => setQuoteStatus(quote.id, st)} className={`h-9 rounded-full px-3 text-xs font-extrabold ${quote.status === st ? "bg-navy text-on-navy" : "border border-line"}`}>
            {st}
          </button>
        ))}
      </div>
      <div className="mt-4 grid grid-cols-2 gap-2">
        <GhostButton onClick={onEdit}>Edit</GhostButton>
        <GhostButton onClick={onDelete}>Delete</GhostButton>
      </div>
    </div>
  );
}

function fillScript(body: string) {
  return body
    .replaceAll("{name}", "Jabulani")
    .replaceAll("{service}", "Spring Cleaning Special")
    .replaceAll("{date}", "16 August 2026")
    .replaceAll("{address}", "1159 Sindane Street, Vosloorus")
    .replaceAll("{deposit}", "R300.00")
    .replaceAll("{before}", "R450.00")
    .replaceAll("{leader}", "Thandi")
    .replaceAll("{hours}", "4")
    .replaceAll("{cleaners}", "2")
    .replaceAll("{event}", "Cafe69 All White Affair");
}

function simpleDetail(table: TableKey, id: string, s: ReturnType<typeof useTc.getState> extends never ? never : {
  clients: ReturnType<typeof useTc.getState>["clients"];
  properties: ReturnType<typeof useTc.getState>["properties"];
  team: ReturnType<typeof useTc.getState>["team"];
  payments: ReturnType<typeof useTc.getState>["payments"];
  tasks: ReturnType<typeof useTc.getState>["tasks"];
  documents: ReturnType<typeof useTc.getState>["documents"];
  equipment: ReturnType<typeof useTc.getState>["equipment"];
  budget: ReturnType<typeof useTc.getState>["budget"];
  bookings: ReturnType<typeof useTc.getState>["bookings"];
}) {
  if (table === "clients") {
    const r = s.clients.find((x) => x.id === id);
    if (!r) return null;
    return { title: r.name, ref: r.ref, status: r.status, lines: [{ k: "Phone", v: r.phone || "—" }, { k: "Email", v: r.email || "—" }, { k: "Area", v: r.area }, { k: "Type", v: r.type }, { k: "Notes", v: r.notes || "—" }] };
  }
  if (table === "properties") {
    const r = s.properties.find((x) => x.id === id);
    if (!r) return null;
    const client = s.clients.find((c) => c.id === r.clientId);
    return { title: r.name, ref: r.ref, status: r.zone, lines: [{ k: "Client", v: client?.name ?? "—" }, { k: "Address", v: r.address }, { k: "Area", v: r.area }, { k: "Operational base", v: r.base }, { k: "Notes", v: r.notes || "—" }] };
  }
  if (table === "team") {
    const r = s.team.find((x) => x.id === id);
    if (!r) return null;
    return { title: r.name, ref: r.ref, status: r.status, lines: [{ k: "Role", v: r.role }, { k: "Phone", v: r.phone }, { k: "Base", v: r.base }, { k: "Notes", v: r.notes || "—" }] };
  }
  if (table === "payments") {
    const r = s.payments.find((x) => x.id === id);
    if (!r) return null;
    const b = s.bookings.find((x) => x.id === r.bookingId);
    return { title: r.name, ref: r.ref, status: "Received", lines: [{ k: "Booking", v: b?.ref ?? "—" }, { k: "Amount", v: money(r.amount) }, { k: "Method", v: r.method }, { k: "When", v: formatWhen(r.paidAt) }] };
  }
  if (table === "tasks") {
    const r = s.tasks.find((x) => x.id === id);
    if (!r) return null;
    return { title: r.name, ref: r.ref, status: r.status, lines: [{ k: "Owner", v: r.owner }, { k: "Due", v: formatDay(r.due) }, { k: "Notes", v: r.notes || "—" }] };
  }
  if (table === "documents") {
    const r = s.documents.find((x) => x.id === id);
    if (!r) return null;
    return { title: r.name, ref: r.ref, status: r.status, lines: [{ k: "Category", v: r.category }, { k: "Version", v: r.version }, { k: "Summary", v: r.summary }] };
  }
  if (table === "equipment") {
    const r = s.equipment.find((x) => x.id === id);
    if (!r) return null;
    return { title: r.name, ref: r.ref, status: r.status, lines: [{ k: "Spec", v: r.spec }, { k: "Base", v: r.base }, { k: "Notes", v: r.notes || "—" }] };
  }
  if (table === "budget") {
    const r = s.budget.find((x) => x.id === id);
    if (!r) return null;
    return { title: r.name, ref: r.ref, status: r.purchased ? "Paid" : "Pending", lines: [{ k: "Category", v: r.category }, { k: "Store", v: r.store }, { k: "Price", v: money(r.price) }, { k: "Qty", v: String(r.qty) }, { k: "Line total", v: money(r.price * r.qty) }, { k: "Notes", v: r.notes || "—" }] };
  }
  return null;
}

export function FormBody({ table, id, onDone }: { table: TableKey; id?: string; onDone: () => void }) {
  if (table === "bookings") return <BookingForm id={id} onDone={onDone} />;
  if (table === "clients") return <ClientForm id={id} onDone={onDone} />;
  if (table === "properties") return <PropertyForm id={id} onDone={onDone} />;
  if (table === "team") return <TeamForm id={id} onDone={onDone} />;
  if (table === "quotes") return <QuoteForm id={id} onDone={onDone} />;
  if (table === "tasks") return <TaskForm id={id} onDone={onDone} />;
  if (table === "budget") return <BudgetForm id={id} onDone={onDone} />;
  if (table === "documents") return <DocForm id={id} onDone={onDone} />;
  if (table === "scripts") return <ScriptForm id={id} onDone={onDone} />;
  if (table === "equipment") return <EquipForm id={id} onDone={onDone} />;
  if (table === "payments" || table === "invoices") {
    return <p className="text-sm font-semibold leading-relaxed text-muted">Payments and internal invoices follow the booking. Open a job and log the deposit there — the costing record updates itself.</p>;
  }
}

function BookingForm({ id, onDone }: { id?: string; onDone: () => void }) {
  const existing = useTc((s) => s.bookings.find((b) => b.id === id));
  const clients = useTc((s) => active(s.clients));
  const properties = useTc((s) => active(s.properties));
  const team = useTc((s) => active(s.team));
  const saveBooking = useTc((s) => s.saveBooking);
  const saveClient = useTc((s) => s.saveClient);
  const saveProperty = useTc((s) => s.saveProperty);
  const svc = serviceById(existing?.serviceId ?? "spring");
  const [clientId, setClientId] = useState(existing?.clientId ?? clients[0]?.id ?? "");
  const [fresh, setFresh] = useState(false);
  const [freshName, setFreshName] = useState("");
  const [freshPhone, setFreshPhone] = useState("");
  const [freshArea, setFreshArea] = useState("");
  const [propertyId, setPropertyId] = useState(existing?.propertyId ?? "");
  const [address, setAddress] = useState("");
  const [base, setBase] = useState("Tsakane");
  const [serviceId, setServiceId] = useState(existing?.serviceId ?? "spring");
  const [serviceDate, setServiceDate] = useState(existing?.serviceDate ?? todayISO());
  const [cleaners, setCleaners] = useState(existing?.cleaners ?? svc.cleaners);
  const [hours, setHours] = useState(existing?.hours ?? svc.hours);
  const [serviceAmount, setServiceAmount] = useState(existing?.serviceAmount ?? svc.price);
  const [extraRooms, setExtraRooms] = useState(existing?.extraRooms ?? 0);
  const [extraServices, setExtraServices] = useState(existing?.extraServices ?? 0);
  const [travelCharge, setTravelCharge] = useState(existing?.travelCharge ?? 0);
  const [discount, setDiscount] = useState(existing?.discount ?? 0);
  const [teamIds, setTeamIds] = useState<string[]>(existing?.teamIds ?? []);
  const [notes, setNotes] = useState(existing?.notes ?? "");

  const draftPreview: BookingDraft = {
    clientId: clientId || "pending",
    propertyId: propertyId || "pending",
    serviceId,
    serviceDate,
    status: existing?.status ?? "Pending",
    cleaners,
    hours,
    serviceAmount,
    extraRooms,
    extraServices,
    travelCharge,
    discount,
    products: existing?.products ?? 85,
    equipment: existing?.equipment ?? 25,
    transport: existing?.transport ?? 90,
    acquisition: existing?.acquisition ?? 50,
    admin: existing?.admin ?? 25,
    risk: existing?.risk ?? 25,
    teamIds,
    notes,
  };
  const preview = costBooking(draftPreview, 0);
  const props = properties.filter((p) => p.clientId === clientId);

  function applyService(nextId: string) {
    const next = serviceById(nextId);
    setServiceId(nextId);
    setCleaners(next.cleaners);
    setHours(next.hours);
    setServiceAmount(next.price);
  }

  function save() {
    let cid = clientId;
    let pid = propertyId;
    if (fresh) {
      if (!freshName.trim() || !freshPhone.trim()) {
        toast.error("Add the client name and phone.");
        return;
      }
      cid = saveClient({ name: freshName, phone: freshPhone, email: "", area: freshArea || "Ekurhuleni", type: "Residential", status: "Active", notes: "" });
      pid = saveProperty({ name: address.trim() || freshName, clientId: cid, address: address.trim() || freshArea || "Address to confirm", area: freshArea || "Ekurhuleni", base, zone: "Inner", notes: "" });
    } else if (!cid) {
      toast.error("Choose a client.");
      return;
    } else if (!pid) {
      if (!address.trim()) {
        toast.error("Choose a property or type the address.");
        return;
      }
      const client = clients.find((c) => c.id === cid);
      pid = saveProperty({ name: address.trim(), clientId: cid, address: address.trim(), area: client?.area ?? freshArea, base, zone: "Inner", notes: "" });
    }
    saveBooking({ ...draftPreview, clientId: cid, propertyId: pid }, existing?.id);
    toast.success(existing ? "Booking updated" : "Booking saved to the board");
    onDone();
  }

  return (
    <div>
      <div className="mb-3 flex gap-2">
        <button type="button" onClick={() => setFresh(false)} className={`h-10 flex-1 rounded-2xl text-xs font-extrabold ${!fresh ? "bg-navy text-on-navy" : "border border-line"}`}>Existing client</button>
        <button type="button" onClick={() => setFresh(true)} className={`h-10 flex-1 rounded-2xl text-xs font-extrabold ${fresh ? "bg-navy text-on-navy" : "border border-line"}`}>New client</button>
      </div>
      {fresh ? (
        <>
          <Field label="Client name"><input className={inputClass} value={freshName} onChange={(e) => setFreshName(e.target.value)} /></Field>
          <Field label="Phone"><input className={inputClass} value={freshPhone} onChange={(e) => setFreshPhone(e.target.value)} inputMode="tel" /></Field>
          <Field label="Area"><input className={inputClass} value={freshArea} onChange={(e) => setFreshArea(e.target.value)} placeholder="KwaThema, Tsakane, Vosloorus…" /></Field>
        </>
      ) : (
        <Field label="Client">
          <div className="flex flex-col gap-2">
            {clients.map((c) => (
              <button key={c.id} type="button" onClick={() => { setClientId(c.id); setPropertyId(""); }} className={`h-11 rounded-2xl px-3 text-left text-sm font-bold ${clientId === c.id ? "bg-wash text-ink ring-1 ring-teal" : "border border-line"}`}>
                {c.name} · {c.area}
              </button>
            ))}
          </div>
        </Field>
      )}
      {!fresh && props.length > 0 ? (
        <Field label="Property">
          {props.map((p) => (
            <button key={p.id} type="button" onClick={() => setPropertyId(p.id)} className={`mb-2 h-11 w-full rounded-2xl px-3 text-left text-sm font-bold ${propertyId === p.id ? "bg-wash ring-1 ring-teal" : "border border-line"}`}>
              {p.address}
            </button>
          ))}
        </Field>
      ) : null}
      {fresh || !propertyId ? <Field label="Service address"><input className={inputClass} value={address} onChange={(e) => setAddress(e.target.value)} /></Field> : null}
      <Field label="Operational base">
        <div className="grid grid-cols-3 gap-2">
          {["Tsakane", "Benoni", "Daveyton"].map((b) => (
            <button key={b} type="button" onClick={() => setBase(b)} className={`h-11 rounded-2xl text-xs font-extrabold ${base === b ? "bg-teal text-on-teal" : "border border-line"}`}>{b}</button>
          ))}
        </div>
      </Field>
      <Field label="Service">
        {SERVICES.map((sv) => (
          <button key={sv.id} type="button" onClick={() => applyService(sv.id)} className={`mb-2 flex w-full items-center justify-between rounded-2xl px-3 py-3 text-left ${serviceId === sv.id ? "bg-wash ring-1 ring-teal" : "border border-line"}`}>
            <span className="text-sm font-extrabold">{sv.name}</span>
            <span className="text-sm font-extrabold tabular-nums">{money(sv.price)}</span>
          </button>
        ))}
      </Field>
      <Field label="Service date"><input type="date" className={inputClass} value={serviceDate} onChange={(e) => setServiceDate(e.target.value)} /></Field>
      <div className="grid grid-cols-2 gap-2">
        <Field label="Cleaners"><input type="number" min={1} className={inputClass} value={cleaners} onChange={(e) => setCleaners(Number(e.target.value) || 1)} /></Field>
        <Field label="Hours each"><input type="number" min={1} className={inputClass} value={hours} onChange={(e) => setHours(Number(e.target.value) || 1)} /></Field>
        <Field label="Service amount"><input type="number" className={inputClass} value={serviceAmount} onChange={(e) => setServiceAmount(Number(e.target.value) || 0)} /></Field>
        <Field label="Extra rooms"><input type="number" min={0} className={inputClass} value={extraRooms} onChange={(e) => setExtraRooms(Number(e.target.value) || 0)} /></Field>
        <Field label="Extra services"><input type="number" className={inputClass} value={extraServices} onChange={(e) => setExtraServices(Number(e.target.value) || 0)} /></Field>
        <Field label="Travel charge"><input type="number" className={inputClass} value={travelCharge} onChange={(e) => setTravelCharge(Number(e.target.value) || 0)} /></Field>
        <Field label="Discount"><input type="number" className={inputClass} value={discount} onChange={(e) => setDiscount(Number(e.target.value) || 0)} /></Field>
      </div>
      <Field label="Assign team">
        <div className="flex flex-wrap gap-2">
          {team.map((m) => {
            const on = teamIds.includes(m.id);
            return (
              <button key={m.id} type="button" onClick={() => setTeamIds(on ? teamIds.filter((x) => x !== m.id) : [...teamIds, m.id])} className={`h-10 rounded-full px-3 text-xs font-extrabold ${on ? "bg-navy text-on-navy" : "border border-line"} ${m.status !== "Active" ? "opacity-50" : ""}`}>
                {m.name.split(" ")[0]}
              </button>
            );
          })}
        </div>
      </Field>
      <Field label="Notes"><textarea className={`${inputClass} h-24 py-3`} value={notes} onChange={(e) => setNotes(e.target.value)} /></Field>
      <div className="mb-3 rounded-2xl bg-navy px-3 py-3 text-on-navy">
        <div className="flex justify-between text-sm font-bold"><span>Invoice total</span><span>{money(preview.revenue)}</span></div>
        <div className="flex justify-between text-sm"><span>Delivery cost</span><span>{money(preview.delivery)}</span></div>
        <div className="flex justify-between text-sm font-extrabold text-aqua"><span>Contribution</span><span>{money(preview.contribution)} · {(preview.margin * 100).toFixed(1)}%</span></div>
        <p className="mt-1 text-xs">Deposit to lock the team: {money(preview.depositRequired)}. Balance before cleaning: {money(preview.balanceBeforeCleaning)}.</p>
      </div>
      <PrimaryButton onClick={save}>{existing ? "Save booking" : "Commit booking"}</PrimaryButton>
    </div>
  );
}

function ClientForm({ id, onDone }: { id?: string; onDone: () => void }) {
  const existing = useTc((s) => s.clients.find((c) => c.id === id));
  const save = useTc((s) => s.saveClient);
  const [name, setName] = useState(existing?.name ?? "");
  const [phone, setPhone] = useState(existing?.phone ?? "");
  const [email, setEmail] = useState(existing?.email ?? "");
  const [area, setArea] = useState(existing?.area ?? "");
  const [type, setType] = useState(existing?.type ?? "Residential");
  const [status, setStatus] = useState(existing?.status ?? "Active");
  const [notes, setNotes] = useState(existing?.notes ?? "");
  return (
    <form onSubmit={(e) => { e.preventDefault(); if (!name.trim()) return toast.error("Name is required."); save({ id, name, phone, email, area, type, status, notes }); toast.success("Client saved"); onDone(); }}>
      <Field label="Name"><input className={inputClass} value={name} onChange={(e) => setName(e.target.value)} required /></Field>
      <Field label="Phone"><input className={inputClass} value={phone} onChange={(e) => setPhone(e.target.value)} inputMode="tel" /></Field>
      <Field label="Email"><input className={inputClass} value={email} onChange={(e) => setEmail(e.target.value)} inputMode="email" /></Field>
      <Field label="Area"><input className={inputClass} value={area} onChange={(e) => setArea(e.target.value)} /></Field>
      <Choice label="Type" value={type} options={["Residential", "Corporate", "Event"]} onChange={(v) => setType(v as typeof type)} />
      <Choice label="Status" value={status} options={["Active", "Lead", "Inactive", "Archived"]} onChange={(v) => setStatus(v as typeof status)} />
      <Field label="Notes"><textarea className={`${inputClass} h-24 py-3`} value={notes} onChange={(e) => setNotes(e.target.value)} /></Field>
      <PrimaryButton type="submit">Save client</PrimaryButton>
    </form>
  );
}

function PropertyForm({ id, onDone }: { id?: string; onDone: () => void }) {
  const existing = useTc((s) => s.properties.find((p) => p.id === id));
  const clients = useTc((s) => active(s.clients));
  const save = useTc((s) => s.saveProperty);
  const [name, setName] = useState(existing?.name ?? "");
  const [clientId, setClientId] = useState(existing?.clientId ?? clients[0]?.id ?? "");
  const [address, setAddress] = useState(existing?.address ?? "");
  const [area, setArea] = useState(existing?.area ?? "");
  const [base, setBase] = useState(existing?.base ?? "Tsakane");
  const [zone, setZone] = useState(existing?.zone ?? "Inner");
  const [notes, setNotes] = useState(existing?.notes ?? "");
  return (
    <form onSubmit={(e) => { e.preventDefault(); if (!name.trim() || !clientId) return toast.error("Name and client are required."); save({ id, name, clientId, address, area, base, zone, notes }); toast.success("Property saved"); onDone(); }}>
      <Field label="Name"><input className={inputClass} value={name} onChange={(e) => setName(e.target.value)} /></Field>
      <Field label="Client">
        {clients.map((c) => (
          <button key={c.id} type="button" onClick={() => setClientId(c.id)} className={`mb-2 h-11 w-full rounded-2xl px-3 text-left text-sm font-bold ${clientId === c.id ? "bg-wash ring-1 ring-teal" : "border border-line"}`}>{c.name}</button>
        ))}
      </Field>
      <Field label="Address"><input className={inputClass} value={address} onChange={(e) => setAddress(e.target.value)} /></Field>
      <Field label="Area"><input className={inputClass} value={area} onChange={(e) => setArea(e.target.value)} /></Field>
      <Choice label="Base" value={base} options={["Tsakane", "Benoni", "Daveyton"]} onChange={setBase} />
      <Field label="Coverage zone"><input className={inputClass} value={zone} onChange={(e) => setZone(e.target.value)} /></Field>
      <Field label="Notes"><textarea className={`${inputClass} h-20 py-3`} value={notes} onChange={(e) => setNotes(e.target.value)} /></Field>
      <PrimaryButton type="submit">Save property</PrimaryButton>
    </form>
  );
}

function TeamForm({ id, onDone }: { id?: string; onDone: () => void }) {
  const existing = useTc((s) => s.team.find((t) => t.id === id));
  const save = useTc((s) => s.saveTeam);
  const [name, setName] = useState(existing?.name ?? "");
  const [role, setRole] = useState(existing?.role ?? "Professional Residential Cleaner");
  const [phone, setPhone] = useState(existing?.phone ?? "");
  const [base, setBase] = useState(existing?.base ?? "Tsakane");
  const [status, setStatus] = useState(existing?.status ?? "Probation");
  const [notes, setNotes] = useState(existing?.notes ?? "");
  return (
    <form onSubmit={(e) => { e.preventDefault(); if (!name.trim()) return toast.error("Name is required."); save({ id, name, role, phone, base, status, notes }); toast.success("Team member saved"); onDone(); }}>
      <Field label="Full name"><input className={inputClass} value={name} onChange={(e) => setName(e.target.value)} /></Field>
      <Field label="Role"><input className={inputClass} value={role} onChange={(e) => setRole(e.target.value)} /></Field>
      <Field label="Phone"><input className={inputClass} value={phone} onChange={(e) => setPhone(e.target.value)} /></Field>
      <Choice label="Base" value={base} options={["Tsakane", "Benoni", "Daveyton"]} onChange={setBase} />
      <Choice label="Status" value={status} options={["Active", "On Leave", "Probation", "Suspended"]} onChange={(v) => setStatus(v as typeof status)} />
      <Field label="Notes"><textarea className={`${inputClass} h-20 py-3`} value={notes} onChange={(e) => setNotes(e.target.value)} /></Field>
      <PrimaryButton type="submit">Save team member</PrimaryButton>
    </form>
  );
}

function QuoteForm({ id, onDone }: { id?: string; onDone: () => void }) {
  const existing = useTc((s) => s.quotes.find((q) => q.id === id));
  const clients = useTc((s) => active(s.clients));
  const save = useTc((s) => s.saveQuote);
  const [name, setName] = useState(existing?.name ?? "");
  const [clientId, setClientId] = useState(existing?.clientId ?? clients[0]?.id ?? "");
  const [venue, setVenue] = useState(existing?.venue ?? "");
  const [eventDate, setEventDate] = useState(existing?.eventDate ?? todayISO());
  const [exclVat, setExclVat] = useState(existing?.exclVat ?? 0);
  const [people, setPeople] = useState(existing?.people ?? 2);
  const [notes, setNotes] = useState(existing?.notes ?? "");
  const [scopeText, setScopeText] = useState((existing?.scope ?? ["Pre-clean", "Service delivery", "Handover"]).join("\n"));
  return (
    <form onSubmit={(e) => {
      e.preventDefault();
      if (!name.trim() || !clientId) return toast.error("Name and client are required.");
      save({
        id,
        name,
        clientId,
        status: existing?.status ?? "Draft",
        venue,
        eventDate,
        proposalDate: existing?.proposalDate ?? todayISO(),
        exclVat: Number(exclVat) || 0,
        people: Number(people) || 0,
        dayShift: existing?.dayShift ?? "",
        eveningShift: existing?.eveningShift ?? "",
        scope: scopeText.split("\n").map((l) => l.trim()).filter(Boolean),
        notes,
      });
      toast.success("Quote saved");
      onDone();
    }}>
      <Field label="Quote name"><input className={inputClass} value={name} onChange={(e) => setName(e.target.value)} /></Field>
      <Field label="Client">
        {clients.map((c) => (
          <button key={c.id} type="button" onClick={() => setClientId(c.id)} className={`mb-2 h-11 w-full rounded-2xl px-3 text-left text-sm font-bold ${clientId === c.id ? "bg-wash ring-1 ring-teal" : "border border-line"}`}>{c.name}</button>
        ))}
      </Field>
      <Field label="Venue"><input className={inputClass} value={venue} onChange={(e) => setVenue(e.target.value)} /></Field>
      <Field label="Event or start date"><input type="date" className={inputClass} value={eventDate} onChange={(e) => setEventDate(e.target.value)} /></Field>
      <Field label="Amount excl. VAT"><input type="number" className={inputClass} value={exclVat} onChange={(e) => setExclVat(Number(e.target.value))} /></Field>
      <p className="mb-3 text-sm font-bold text-ink">Incl. VAT {money(vatOf(Number(exclVat) || 0).total)}</p>
      <Field label="People"><input type="number" className={inputClass} value={people} onChange={(e) => setPeople(Number(e.target.value))} /></Field>
      <Field label="Scope (one line each)"><textarea className={`${inputClass} h-28 py-3`} value={scopeText} onChange={(e) => setScopeText(e.target.value)} /></Field>
      <Field label="Notes"><textarea className={`${inputClass} h-20 py-3`} value={notes} onChange={(e) => setNotes(e.target.value)} /></Field>
      <PrimaryButton type="submit">Save quote</PrimaryButton>
    </form>
  );
}

function TaskForm({ id, onDone }: { id?: string; onDone: () => void }) {
  const existing = useTc((s) => s.tasks.find((t) => t.id === id));
  const save = useTc((s) => s.saveTask);
  const session = liveSession(useTc((s) => s.session));
  const user = USERS.find((u) => u.id === session?.userId);
  const [name, setName] = useState(existing?.name ?? "");
  const [status, setStatus] = useState(existing?.status ?? "To Do");
  const [due, setDue] = useState(existing?.due ?? todayISO());
  const [owner, setOwner] = useState(existing?.owner ?? user?.name ?? "Miss Phindi");
  const [notes, setNotes] = useState(existing?.notes ?? "");
  return (
    <form onSubmit={(e) => { e.preventDefault(); if (!name.trim()) return toast.error("Task name is required."); save({ id, name, status, due, owner, notes }); toast.success("Task saved"); onDone(); }}>
      <Field label="Task"><input className={inputClass} value={name} onChange={(e) => setName(e.target.value)} /></Field>
      <Choice label="Status" value={status} options={["To Do", "In Progress", "Blocked", "Done", "Cancelled"]} onChange={(v) => setStatus(v as typeof status)} />
      <Field label="Due"><input type="date" className={inputClass} value={due} onChange={(e) => setDue(e.target.value)} /></Field>
      <Field label="Owner"><input className={inputClass} value={owner} onChange={(e) => setOwner(e.target.value)} /></Field>
      <Field label="Notes"><textarea className={`${inputClass} h-20 py-3`} value={notes} onChange={(e) => setNotes(e.target.value)} /></Field>
      <PrimaryButton type="submit">Save task</PrimaryButton>
    </form>
  );
}

function BudgetForm({ id, onDone }: { id?: string; onDone: () => void }) {
  const existing = useTc((s) => s.budget.find((b) => b.id === id));
  const save = useTc((s) => s.saveBudget);
  const [name, setName] = useState(existing?.name ?? "");
  const [category, setCategory] = useState(existing?.category ?? "Consumables");
  const [store, setStore] = useState(existing?.store ?? "");
  const [price, setPrice] = useState(existing?.price ?? 0);
  const [qty, setQty] = useState(existing?.qty ?? 1);
  const [purchased, setPurchased] = useState(existing?.purchased ?? false);
  const [notes, setNotes] = useState(existing?.notes ?? "");
  return (
    <form onSubmit={(e) => { e.preventDefault(); if (!name.trim()) return toast.error("Name the line."); save({ id, name, category, store, price: Number(price) || 0, qty: Number(qty) || 1, purchased, notes }); toast.success("Budget line saved"); onDone(); }}>
      <Field label="Item"><input className={inputClass} value={name} onChange={(e) => setName(e.target.value)} /></Field>
      <Choice label="Category" value={category} options={["Consumables", "Chemicals", "PPE", "Transport", "Equipment", "Other"]} onChange={setCategory} />
      <Field label="Store"><input className={inputClass} value={store} onChange={(e) => setStore(e.target.value)} /></Field>
      <div className="grid grid-cols-2 gap-2">
        <Field label="Price (R)"><input type="number" className={inputClass} value={price} onChange={(e) => setPrice(Number(e.target.value))} /></Field>
        <Field label="Qty"><input type="number" className={inputClass} value={qty} onChange={(e) => setQty(Number(e.target.value))} /></Field>
      </div>
      <p className="mb-3 text-sm font-extrabold">Line total {money((Number(price) || 0) * (Number(qty) || 0))}</p>
      <button type="button" onClick={() => setPurchased((v) => !v)} className={`mb-3 h-11 w-full rounded-2xl text-sm font-extrabold ${purchased ? "bg-teal text-on-teal" : "border border-line"}`}>{purchased ? "Marked purchased" : "Not purchased yet"}</button>
      <Field label="Notes"><textarea className={`${inputClass} h-20 py-3`} value={notes} onChange={(e) => setNotes(e.target.value)} /></Field>
      <PrimaryButton type="submit">Save line</PrimaryButton>
    </form>
  );
}

function DocForm({ id, onDone }: { id?: string; onDone: () => void }) {
  const existing = useTc((s) => s.documents.find((d) => d.id === id));
  const save = useTc((s) => s.saveDoc);
  const [name, setName] = useState(existing?.name ?? "");
  const [category, setCategory] = useState(existing?.category ?? "Business Documents");
  const [status, setStatus] = useState(existing?.status ?? "Draft");
  const [version, setVersion] = useState(existing?.version ?? "1.0");
  const [summary, setSummary] = useState(existing?.summary ?? "");
  return (
    <form onSubmit={(e) => { e.preventDefault(); if (!name.trim()) return toast.error("Document needs a name."); save({ id, name, category, status, version, summary }); toast.success("Document registered"); onDone(); }}>
      <Field label="Name"><input className={inputClass} value={name} onChange={(e) => setName(e.target.value)} /></Field>
      <Choice label="Category" value={category} options={["Business Documents", "Contracts", "Invoices", "Brand", "Certificates"]} onChange={setCategory} />
      <Field label="Version"><input className={inputClass} value={version} onChange={(e) => setVersion(e.target.value)} /></Field>
      <Choice label="Status" value={status} options={["Draft", "Active", "Archived"]} onChange={setStatus} />
      <Field label="Summary"><textarea className={`${inputClass} h-28 py-3`} value={summary} onChange={(e) => setSummary(e.target.value)} /></Field>
      <PrimaryButton type="submit">Register document</PrimaryButton>
    </form>
  );
}

function ScriptForm({ id, onDone }: { id?: string; onDone: () => void }) {
  const existing = useTc((s) => s.scripts.find((d) => d.id === id));
  const save = useTc((s) => s.saveScript);
  const [name, setName] = useState(existing?.name ?? "");
  const [type, setType] = useState(existing?.type ?? "WhatsApp");
  const [audience, setAudience] = useState(existing?.audience ?? "Residential customer");
  const [body, setBody] = useState(existing?.body ?? "");
  const [status, setStatus] = useState(existing?.status ?? "Active");
  return (
    <form onSubmit={(e) => { e.preventDefault(); if (!name.trim() || !body.trim()) return toast.error("Name and script body are required."); save({ id, name, type, audience, body, status }); toast.success("Script saved"); onDone(); }}>
      <Field label="Name"><input className={inputClass} value={name} onChange={(e) => setName(e.target.value)} /></Field>
      <Choice label="Type" value={type} options={["WhatsApp", "Call", "Email"]} onChange={(v) => setType(v as typeof type)} />
      <Field label="Audience"><input className={inputClass} value={audience} onChange={(e) => setAudience(e.target.value)} /></Field>
      <Field label="Script body"><textarea className={`${inputClass} h-36 py-3`} value={body} onChange={(e) => setBody(e.target.value)} /></Field>
      <Choice label="Status" value={status} options={["Active", "Draft"]} onChange={setStatus} />
      <PrimaryButton type="submit">Save script</PrimaryButton>
    </form>
  );
}

function EquipForm({ id, onDone }: { id?: string; onDone: () => void }) {
  const existing = useTc((s) => s.equipment.find((d) => d.id === id));
  const save = useTc((s) => s.saveEquipment);
  const [name, setName] = useState(existing?.name ?? "");
  const [spec, setSpec] = useState(existing?.spec ?? "");
  const [status, setStatus] = useState(existing?.status ?? "In Fleet");
  const [base, setBase] = useState(existing?.base ?? "Benoni");
  const [notes, setNotes] = useState(existing?.notes ?? "");
  return (
    <form onSubmit={(e) => { e.preventDefault(); if (!name.trim()) return toast.error("Name the equipment."); save({ id, name, spec, status, base, notes }); toast.success("Equipment logged"); onDone(); }}>
      <Field label="Name"><input className={inputClass} value={name} onChange={(e) => setName(e.target.value)} /></Field>
      <Field label="Spec"><input className={inputClass} value={spec} onChange={(e) => setSpec(e.target.value)} /></Field>
      <Choice label="Status" value={status} options={["In Fleet", "In Repair", "Retired"]} onChange={(v) => setStatus(v as typeof status)} />
      <Choice label="Base" value={base} options={["Tsakane", "Benoni", "Daveyton"]} onChange={setBase} />
      <Field label="Notes"><textarea className={`${inputClass} h-20 py-3`} value={notes} onChange={(e) => setNotes(e.target.value)} /></Field>
      <PrimaryButton type="submit">Save equipment</PrimaryButton>
    </form>
  );
}

function Choice({ label, value, options, onChange }: { label: string; value: string; options: string[]; onChange: (v: string) => void }) {
  return (
    <Field label={label}>
      <div className="flex flex-wrap gap-2">
        {options.map((opt) => (
          <button key={opt} type="button" onClick={() => onChange(opt)} className={`h-10 rounded-full px-3 text-xs font-extrabold ${value === opt ? "bg-teal text-on-teal" : "border border-line bg-paper text-ink"}`}>
            {opt}
          </button>
        ))}
      </div>
    </Field>
  );
}

export function PayBody({ bookingId, onDone }: { bookingId: string; onDone: () => void }) {
  const booking = useTc((s) => s.bookings.find((b) => b.id === bookingId));
  const payments = useTc((s) => s.payments);
  const logPayment = useTc((s) => s.logPayment);
  const cost = booking ? costBooking(booking, depositFor(booking.id, payments)) : null;
  const [amount, setAmount] = useState(cost?.depositRequired && cost.depositReceived < cost.depositRequired ? cost.depositRequired - cost.depositReceived : cost?.balanceDue ?? 0);
  const [method, setMethod] = useState<"EFT" | "Cash" | "Card">("EFT");
  if (!booking || !cost) return null;
  return (
    <div>
      <p className="text-sm font-semibold text-muted">Balance due {money(cost.balanceDue)}. Required deposit {money(cost.depositRequired)}.</p>
      <Field label="Amount">
        <input type="number" className={inputClass} value={amount} onChange={(e) => setAmount(Number(e.target.value))} />
      </Field>
      <Choice label="Method" value={method} options={["EFT", "Cash", "Card"]} onChange={(v) => setMethod(v as typeof method)} />
      <PrimaryButton onClick={() => { if (amount <= 0) return toast.error("Enter an amount."); logPayment(booking.id, amount, method); toast.success("Payment logged"); onDone(); }}>
        Record {money(Number(amount) || 0)}
      </PrimaryButton>
    </div>
  );
}

export function CreateMenu({ onPick }: { onPick: (table: TableKey) => void }) {
  const items: { id: TableKey; label: string; icon: typeof Calendar }[] = [
    { id: "bookings", label: "Booking", icon: Calendar },
    { id: "quotes", label: "Quote", icon: Receipt },
    { id: "clients", label: "Client", icon: Users },
    { id: "tasks", label: "Task", icon: ClipboardList },
    { id: "budget", label: "Budget line", icon: Wallet },
    { id: "equipment", label: "Equipment", icon: Wrench },
    { id: "scripts", label: "Script", icon: MessageSquare },
    { id: "properties", label: "Property", icon: Building2 },
  ];
  return (
    <div className="grid grid-cols-2 gap-2">
      {items.map((item) => (
        <button key={item.id} type="button" onClick={() => onPick(item.id)} className="flex h-20 flex-col items-start justify-center rounded-2xl border border-line bg-canvas px-3 text-left">
          <item.icon className="size-4 text-teal" />
          <span className="mt-1 text-sm font-extrabold text-ink">{item.label}</span>
        </button>
      ))}
    </div>
  );
}

export function MenuBody({
  name,
  role,
  onOpen,
  onSettings,
  onLogout,
}: {
  name: string;
  role: string;
  onOpen: (t: TableKey) => void;
  onSettings: () => void;
  onLogout: () => void;
}) {
  return (
    <div className="flex h-full flex-col bg-paper">
      <div className="bg-navy px-4 pt-6 pb-5 text-on-navy">
        <p className="text-xs font-bold tracking-widest text-aqua">SIGNED IN</p>
        <h2 className="mt-1 text-xl font-extrabold">{name}</h2>
        <p className="text-sm text-aqua">{role}</p>
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto px-3 py-3">
        {GROUPS.map((group) => (
          <div key={group} className="mb-3">
            <p className="px-2 text-xs font-extrabold tracking-widest text-muted">{group}</p>
            {(Object.keys(TABLE_META) as TableKey[]).filter((id) => TABLE_META[id].group === group).map((id) => (
              <button key={id} type="button" onClick={() => onOpen(id)} className="flex h-11 w-full items-center rounded-xl px-2 text-left text-sm font-bold text-ink active:bg-wash">
                {TABLE_META[id].label}
              </button>
            ))}
          </div>
        ))}
      </div>
      <div className="border-t border-line p-3 pb-nav">
        <button type="button" onClick={onSettings} className="mb-2 h-11 w-full rounded-2xl bg-wash text-sm font-extrabold text-ink">Settings</button>
        <button type="button" onClick={onLogout} className="h-11 w-full rounded-2xl text-sm font-extrabold text-muted">Log out</button>
      </div>
    </div>
  );
}

export function SettingsBody({ onClose }: { onClose: () => void }) {
  const theme = useTc((s) => s.theme);
  const lang = useTc((s) => s.lang);
  const setTheme = useTc((s) => s.setTheme);
  const setLang = useTc((s) => s.setLang);
  const lastSync = useTc((s) => s.lastSync);
  const resetDemo = useTc((s) => s.resetDemo);
  const [about, setAbout] = useState(false);
  const [help, setHelp] = useState(false);
  return (
    <div>
      <p className="text-xs font-bold text-muted">Version 1.3 · Last sync {formatWhen(new Date(lastSync).toISOString())}</p>
      <SectionLabel>Theme</SectionLabel>
      <div className="grid grid-cols-3 gap-2">
        {([["default", "Default"], ["dark", "Dark"], ["ios", "iOS"]] as const).map(([id, label]) => (
          <button key={id} type="button" onClick={() => setTheme(id)} className={`h-16 rounded-2xl text-sm font-extrabold ${theme === id ? "bg-teal text-on-teal" : "border border-line"}`}>
            <span className={`mx-auto mb-1 block size-4 rounded-full ${id === "dark" ? "bg-navy" : id === "ios" ? "bg-canvas ring-1 ring-line" : "bg-teal"}`} />
            {label}
          </button>
        ))}
      </div>
      <SectionLabel>Language</SectionLabel>
      <div className="grid grid-cols-3 gap-2">
        {([["en", "English"], ["zu", "isiZulu"], ["af", "Afrikaans"]] as const).map(([id, label]) => (
          <button key={id} type="button" onClick={() => setLang(id)} className={`h-11 rounded-2xl text-xs font-extrabold ${lang === id ? "bg-navy text-on-navy" : "border border-line"}`}>{label}</button>
        ))}
      </div>
      <p className="mt-3 text-xs font-medium text-muted">Currency stays Rand. TerraCelest bills in ZAR only.</p>
      <div className="mt-4 grid gap-2">
        <GhostButton onClick={() => setAbout(true)}>About TerraCelest</GhostButton>
        <GhostButton onClick={() => setHelp(true)}>Get help</GhostButton>
        <GhostButton onClick={() => { resetDemo(); toast.success("Training data reset"); onClose(); }}>Reset training data</GhostButton>
      </div>
      {about ? (
        <div className="mt-4 rounded-3xl bg-navy p-4 text-on-navy">
          <p className="text-xs font-bold tracking-brand text-aqua">CLEAN SPACES. BETTER PLACES.</p>
          <p className="mt-2 text-sm leading-relaxed">TerraCelest Group of Companies (PTY) LTD · 2026/665752/07. 6690 Mala Street, Daveyton, Benoni, 1520. Also at Unit 5, Greenstone Office Park, Modderfontein. Empower · Innovate · Elevate.</p>
          <button type="button" className="mt-3 text-sm font-bold text-aqua" onClick={() => setAbout(false)}>Close</button>
        </div>
      ) : null}
      {help ? (
        <div className="mt-4 rounded-3xl border border-line p-4">
          <p className="text-sm font-semibold text-ink">Desk: 061 467 9207</p>
          <div className="mt-2 flex gap-2">
            <a className="inline-flex h-11 items-center rounded-2xl bg-teal px-3 text-sm font-extrabold text-on-teal" href="tel:0614679207">Call</a>
            <a className="inline-flex h-11 items-center rounded-2xl bg-navy px-3 text-sm font-extrabold text-on-navy" href="https://wa.me/27614679207" target="_blank" rel="noreferrer">WhatsApp</a>
          </div>
          <p className="mt-2 text-xs text-muted">info@terracelest.co.za · team@terracelest.com</p>
        </div>
      ) : null}
    </div>
  );
}

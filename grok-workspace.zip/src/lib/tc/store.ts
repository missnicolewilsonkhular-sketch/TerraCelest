import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  active,
  costBooking,
  depositFor,
  nid,
  nextRef,
  seedWorkspace,
  serviceById,
  type Booking,
  type BookingStatus,
  type BudgetItem,
  type Client,
  type DocItem,
  type Equipment,
  type FeedItem,
  type Invoice,
  type InvoiceStatus,
  type Lang,
  type Payment,
  type Property,
  type Quote,
  type QuoteStatus,
  type ScriptItem,
  type TaskItem,
  type TeamMember,
  type ThemeName,
  type UserId,
  type WorkspaceData,
} from "@/lib/tc/model";

const SESSION_MS = 8 * 60 * 60 * 1000;

export interface Session {
  userId: UserId;
  expires: number;
}

export interface BookingDraft {
  clientId: string;
  propertyId: string;
  serviceId: string;
  serviceDate: string;
  status: BookingStatus;
  cleaners: number;
  hours: number;
  serviceAmount: number;
  extraRooms: number;
  extraServices: number;
  travelCharge: number;
  discount: number;
  products: number;
  equipment: number;
  transport: number;
  acquisition: number;
  admin: number;
  risk: number;
  teamIds: string[];
  notes: string;
}

interface TcState extends WorkspaceData {
  session: Session | null;
  theme: ThemeName;
  lang: Lang;
  lastSync: number;
  login: (userId: UserId) => void;
  logout: () => void;
  setTheme: (theme: ThemeName) => void;
  setLang: (lang: Lang) => void;
  sync: () => void;
  markFeedRead: () => void;
  resetDemo: () => void;
  saveClient: (input: Omit<Client, "id" | "ref" | "deleted" | "createdAt"> & { id?: string }) => string;
  saveProperty: (input: Omit<Property, "id" | "ref" | "deleted" | "createdAt"> & { id?: string }) => string;
  saveTeam: (input: Omit<TeamMember, "id" | "ref" | "deleted" | "createdAt"> & { id?: string }) => string;
  saveBooking: (draft: BookingDraft, existingId?: string) => string;
  setBookingStatus: (id: string, status: BookingStatus) => void;
  logPayment: (bookingId: string, amount: number, method: Payment["method"]) => void;
  setInvoiceStatus: (id: string, status: InvoiceStatus) => void;
  saveQuote: (input: Omit<Quote, "id" | "ref" | "deleted" | "createdAt" | "rich"> & { id?: string }) => string;
  setQuoteStatus: (id: string, status: QuoteStatus) => void;
  saveTask: (input: Omit<TaskItem, "id" | "ref" | "deleted" | "createdAt"> & { id?: string }) => string;
  saveBudget: (input: Omit<BudgetItem, "id" | "ref" | "deleted" | "createdAt" | "archived"> & { id?: string }) => string;
  archiveBudget: (id: string, archived: boolean) => void;
  saveDoc: (input: Omit<DocItem, "id" | "ref" | "deleted" | "createdAt"> & { id?: string }) => string;
  saveScript: (input: Omit<ScriptItem, "id" | "ref" | "deleted" | "createdAt"> & { id?: string }) => string;
  saveEquipment: (input: Omit<Equipment, "id" | "ref" | "deleted" | "createdAt"> & { id?: string }) => string;
  softDelete: (table: TableKey, id: string) => void;
  restore: (table: TableKey, id: string) => void;
}

export type TableKey =
  | "clients"
  | "properties"
  | "team"
  | "bookings"
  | "invoices"
  | "quotes"
  | "payments"
  | "tasks"
  | "budget"
  | "documents"
  | "scripts"
  | "equipment";

function pushFeed(feed: FeedItem[], item: Omit<FeedItem, "id" | "at" | "read">): FeedItem[] {
  return [{ id: nid("fd"), at: new Date().toISOString(), read: false, ...item }, ...feed].slice(0, 40);
}

function upsert<T extends { id: string }>(rows: T[], row: T): T[] {
  const i = rows.findIndex((r) => r.id === row.id);
  if (i < 0) return [row, ...rows];
  const next = rows.slice();
  next[i] = row;
  return next;
}

const seeded = seedWorkspace();

export const useTc = create<TcState>()(
  persist(
    (set, get) => ({
      ...seeded,
      session: null,
      theme: "default",
      lang: "en",
      lastSync: Date.now(),

      login: (userId) => set({ session: { userId, expires: Date.now() + SESSION_MS } }),
      logout: () => set({ session: null }),
      setTheme: (theme) => set({ theme }),
      setLang: (lang) => set({ lang }),
      sync: () => set({ lastSync: Date.now() }),
      markFeedRead: () => set({ feed: get().feed.map((f) => ({ ...f, read: true })) }),
      resetDemo: () => {
        const fresh = seedWorkspace();
        set({ ...fresh, lastSync: Date.now() });
      },

      saveClient: (input) => {
        const id = input.id ?? nid("cli");
        const existing = get().clients.find((c) => c.id === id);
        const row: Client = {
          id,
          ref: existing?.ref ?? nextRef("CLI", get().clients.map((c) => c.ref)),
          name: input.name.trim(),
          phone: input.phone.trim(),
          email: input.email.trim(),
          area: input.area.trim(),
          type: input.type,
          status: input.status,
          notes: input.notes.trim(),
          deleted: false,
          createdAt: existing?.createdAt ?? new Date().toISOString(),
        };
        set({
          clients: upsert(get().clients, row),
          feed: pushFeed(get().feed, { kind: "system", title: existing ? `Client updated · ${row.name}` : `Client added · ${row.name}`, body: `${row.ref} · ${row.area} · ${row.type}` }),
        });
        return id;
      },

      saveProperty: (input) => {
        const id = input.id ?? nid("prop");
        const existing = get().properties.find((p) => p.id === id);
        const row: Property = {
          ...input,
          id,
          ref: existing?.ref ?? nextRef("PROP", get().properties.map((p) => p.ref)),
          name: input.name.trim(),
          address: input.address.trim(),
          notes: input.notes.trim(),
          deleted: false,
          createdAt: existing?.createdAt ?? new Date().toISOString(),
        };
        set({ properties: upsert(get().properties, row) });
        return id;
      },

      saveTeam: (input) => {
        const id = input.id ?? nid("emp");
        const existing = get().team.find((p) => p.id === id);
        const row: TeamMember = {
          ...input,
          id,
          ref: existing?.ref ?? nextRef("EMP", get().team.map((p) => p.ref)),
          name: input.name.trim(),
          notes: input.notes.trim(),
          deleted: false,
          createdAt: existing?.createdAt ?? new Date().toISOString(),
        };
        set({
          team: upsert(get().team, row),
          feed: pushFeed(get().feed, { kind: "system", title: `${existing ? "Team updated" : "Team added"} · ${row.name}`, body: `${row.role} · ${row.base}` }),
        });
        return id;
      },

      saveBooking: (draft, existingId) => {
        const id = existingId ?? nid("bkg");
        const existing = get().bookings.find((b) => b.id === id);
        const client = get().clients.find((c) => c.id === draft.clientId);
        const service = serviceById(draft.serviceId);
        const row: Booking = {
          ...draft,
          id,
          ref: existing?.ref ?? nextRef("BK", get().bookings.map((b) => b.ref)),
          name: `${client?.name ?? "Client"} · ${service.name}`,
          notes: draft.notes.trim(),
          deleted: false,
          createdAt: existing?.createdAt ?? new Date().toISOString(),
        };
        const bookings = upsert(get().bookings, row);
        let invoices = get().invoices;
        if (!invoices.some((inv) => inv.bookingId === id && !inv.deleted)) {
          const inv: Invoice = {
            id: nid("inv"),
            ref: nextRef("TC-INT", invoices.map((i) => i.ref)),
            bookingId: id,
            status: "Draft",
            notes: "Internal costing record. Not the customer-facing invoice.",
            deleted: false,
            createdAt: new Date().toISOString(),
          };
          invoices = [inv, ...invoices];
        }
        const cost = costBooking(row, depositFor(id, get().payments));
        set({
          bookings,
          invoices,
          feed: pushFeed(get().feed, {
            kind: "booking",
            title: `${existing ? "Booking updated" : "Booking created"} · ${client?.name ?? row.ref}`,
            body: `${row.ref} · ${service.name} · ${row.serviceDate} · revenue ${cost.revenue.toFixed(2)}`,
          }),
        });
        return id;
      },

      setBookingStatus: (id, status) => {
        const row = get().bookings.find((b) => b.id === id);
        if (!row) return;
        set({
          bookings: get().bookings.map((b) => (b.id === id ? { ...b, status } : b)),
          feed: pushFeed(get().feed, { kind: "booking", title: `${row.ref} · ${status}`, body: row.name }),
        });
      },

      logPayment: (bookingId, amount, method) => {
        const booking = get().bookings.find((b) => b.id === bookingId);
        if (!booking || amount <= 0) return;
        const pay: Payment = {
          id: nid("pay"),
          ref: nextRef("PAY", get().payments.map((p) => p.ref)),
          name: `${booking.ref} ${method}`,
          bookingId,
          amount: Math.round(amount * 100) / 100,
          method,
          paidAt: new Date().toISOString(),
          deleted: false,
          createdAt: new Date().toISOString(),
        };
        const payments = [pay, ...get().payments];
        const received = depositFor(bookingId, payments);
        const cost = costBooking(booking, received);
        const invoices = get().invoices.map((inv) => {
          if (inv.bookingId !== bookingId || inv.deleted) return inv;
          const status: InvoiceStatus = cost.balanceDue <= 0 ? "Paid" : "Partially Paid";
          return { ...inv, status };
        });
        set({
          payments,
          invoices,
          feed: pushFeed(get().feed, { kind: "payment", title: `Payment · ${booking.ref}`, body: `${method} R${amount.toFixed(2)}. Balance due R${cost.balanceDue.toFixed(2)}.` }),
        });
      },

      setInvoiceStatus: (id, status) => set({ invoices: get().invoices.map((i) => (i.id === id ? { ...i, status } : i)) }),

      saveQuote: (input) => {
        const id = input.id ?? nid("qt");
        const existing = get().quotes.find((q) => q.id === id);
        const row: Quote = {
          ...input,
          id,
          ref: existing?.ref ?? nextRef("QT", get().quotes.map((q) => q.ref)),
          name: input.name.trim(),
          notes: input.notes.trim(),
          rich: existing?.rich ?? false,
          deleted: false,
          createdAt: existing?.createdAt ?? new Date().toISOString(),
        };
        set({
          quotes: upsert(get().quotes, row),
          feed: pushFeed(get().feed, { kind: "quote", title: `${existing ? "Quote updated" : "Quote drafted"} · ${row.name}`, body: row.ref }),
        });
        return id;
      },

      setQuoteStatus: (id, status) => {
        const row = get().quotes.find((q) => q.id === id);
        if (!row) return;
        set({
          quotes: get().quotes.map((q) => (q.id === id ? { ...q, status } : q)),
          feed: pushFeed(get().feed, { kind: "quote", title: `${row.name} · ${status}`, body: row.ref }),
        });
      },

      saveTask: (input) => {
        const id = input.id ?? nid("tsk");
        const existing = get().tasks.find((t) => t.id === id);
        const row: TaskItem = {
          ...input,
          id,
          ref: existing?.ref ?? nextRef("TSK", get().tasks.map((t) => t.ref)),
          name: input.name.trim(),
          notes: input.notes.trim(),
          deleted: false,
          createdAt: existing?.createdAt ?? new Date().toISOString(),
        };
        set({ tasks: upsert(get().tasks, row) });
        return id;
      },

      saveBudget: (input) => {
        const id = input.id ?? nid("exp");
        const existing = get().budget.find((b) => b.id === id);
        const row: BudgetItem = {
          ...input,
          id,
          ref: existing?.ref ?? nextRef("EXP", get().budget.map((b) => b.ref)),
          name: input.name.trim(),
          notes: input.notes.trim(),
          archived: existing?.archived ?? false,
          deleted: false,
          createdAt: existing?.createdAt ?? new Date().toISOString(),
        };
        set({ budget: upsert(get().budget, row) });
        return id;
      },

      archiveBudget: (id, archived) => set({ budget: get().budget.map((b) => (b.id === id ? { ...b, archived } : b)) }),

      saveDoc: (input) => {
        const id = input.id ?? nid("doc");
        const existing = get().documents.find((d) => d.id === id);
        const row: DocItem = {
          ...input,
          id,
          ref: existing?.ref ?? nextRef("DOC", get().documents.map((d) => d.ref)),
          deleted: false,
          createdAt: existing?.createdAt ?? new Date().toISOString(),
        };
        set({ documents: upsert(get().documents, row) });
        return id;
      },

      saveScript: (input) => {
        const id = input.id ?? nid("scr");
        const existing = get().scripts.find((d) => d.id === id);
        const row: ScriptItem = {
          ...input,
          id,
          ref: existing?.ref ?? nextRef("SCR", get().scripts.map((d) => d.ref)),
          deleted: false,
          createdAt: existing?.createdAt ?? new Date().toISOString(),
        };
        set({ scripts: upsert(get().scripts, row) });
        return id;
      },

      saveEquipment: (input) => {
        const id = input.id ?? nid("eq");
        const existing = get().equipment.find((d) => d.id === id);
        const row: Equipment = {
          ...input,
          id,
          ref: existing?.ref ?? nextRef("EQ", get().equipment.map((d) => d.ref)),
          deleted: false,
          createdAt: existing?.createdAt ?? new Date().toISOString(),
        };
        set({
          equipment: upsert(get().equipment, row),
          feed: pushFeed(get().feed, { kind: "fleet", title: `Equipment · ${row.name}`, body: `${row.spec} · ${row.base}` }),
        });
        return id;
      },

      softDelete: (table, id) => {
        const flag = <T extends { id: string; deleted: boolean }>(rows: T[]) =>
          rows.map((row) => (row.id === id ? { ...row, deleted: true } : row));
        const s = get();
        switch (table) {
          case "clients":
            set({ clients: flag(s.clients) });
            break;
          case "properties":
            set({ properties: flag(s.properties) });
            break;
          case "team":
            set({ team: flag(s.team) });
            break;
          case "bookings":
            set({ bookings: flag(s.bookings) });
            break;
          case "invoices":
            set({ invoices: flag(s.invoices) });
            break;
          case "quotes":
            set({ quotes: flag(s.quotes) });
            break;
          case "payments":
            set({ payments: flag(s.payments) });
            break;
          case "tasks":
            set({ tasks: flag(s.tasks) });
            break;
          case "budget":
            set({ budget: flag(s.budget) });
            break;
          case "documents":
            set({ documents: flag(s.documents) });
            break;
          case "scripts":
            set({ scripts: flag(s.scripts) });
            break;
          case "equipment":
            set({ equipment: flag(s.equipment) });
            break;
        }
      },

      restore: (table, id) => {
        const flag = <T extends { id: string; deleted: boolean }>(rows: T[]) =>
          rows.map((row) => (row.id === id ? { ...row, deleted: false } : row));
        const s = get();
        switch (table) {
          case "clients":
            set({ clients: flag(s.clients) });
            break;
          case "properties":
            set({ properties: flag(s.properties) });
            break;
          case "team":
            set({ team: flag(s.team) });
            break;
          case "bookings":
            set({ bookings: flag(s.bookings) });
            break;
          case "invoices":
            set({ invoices: flag(s.invoices) });
            break;
          case "quotes":
            set({ quotes: flag(s.quotes) });
            break;
          case "payments":
            set({ payments: flag(s.payments) });
            break;
          case "tasks":
            set({ tasks: flag(s.tasks) });
            break;
          case "budget":
            set({ budget: flag(s.budget) });
            break;
          case "documents":
            set({ documents: flag(s.documents) });
            break;
          case "scripts":
            set({ scripts: flag(s.scripts) });
            break;
          case "equipment":
            set({ equipment: flag(s.equipment) });
            break;
        }
      },
    }),
    {
      name: "tc_facilities_v13",
      partialize: (s) => ({
        clients: s.clients,
        properties: s.properties,
        team: s.team,
        bookings: s.bookings,
        invoices: s.invoices,
        quotes: s.quotes,
        payments: s.payments,
        tasks: s.tasks,
        budget: s.budget,
        documents: s.documents,
        scripts: s.scripts,
        equipment: s.equipment,
        feed: s.feed,
        session: s.session,
        theme: s.theme,
        lang: s.lang,
        lastSync: s.lastSync,
      }),
    },
  ),
);

export function liveSession(session: Session | null) {
  if (!session) return null;
  if (session.expires < Date.now()) return null;
  return session;
}

export function unreadCount(feed: FeedItem[]) {
  return feed.filter((f) => !f.read).length;
}

export function openBookings(bookings: Booking[]) {
  return active(bookings).filter((b) => !["Completed", "Cancelled", "No Show"].includes(b.status));
}

export type Lang = "en" | "zu" | "af";
export type ThemeName = "default" | "dark" | "ios";

export type BookingStatus =
  | "Draft"
  | "Pending"
  | "Confirmed"
  | "Assigned"
  | "In Progress"
  | "Completed"
  | "Cancelled"
  | "No Show";

export type QuoteStatus = "Draft" | "Sent" | "Accepted" | "Declined" | "Expired";
export type InvoiceStatus = "Draft" | "Sent" | "Partially Paid" | "Paid" | "Overdue" | "Cancelled";

export interface Client {
  id: string;
  ref: string;
  name: string;
  phone: string;
  email: string;
  area: string;
  type: "Residential" | "Corporate" | "Event";
  status: "Active" | "Lead" | "Inactive" | "Archived";
  notes: string;
  deleted: boolean;
  createdAt: string;
}

export interface Property {
  id: string;
  ref: string;
  name: string;
  clientId: string;
  address: string;
  area: string;
  base: string;
  zone: string;
  notes: string;
  deleted: boolean;
  createdAt: string;
}

export interface TeamMember {
  id: string;
  ref: string;
  name: string;
  role: string;
  phone: string;
  base: string;
  status: "Active" | "On Leave" | "Probation" | "Suspended";
  notes: string;
  deleted: boolean;
  createdAt: string;
}

export interface Booking {
  id: string;
  ref: string;
  name: string;
  clientId: string;
  propertyId: string;
  serviceId: string;
  serviceDate: string;
  status: BookingStatus;
  cleaners: number;
  hours: number;
  serviceAmount: number;
  extraRooms: number;
  extraServices: number;
  travelCharge: number;
  discount: number;
  products: number;
  equipment: number;
  transport: number;
  acquisition: number;
  admin: number;
  risk: number;
  teamIds: string[];
  notes: string;
  deleted: boolean;
  createdAt: string;
}

export interface Invoice {
  id: string;
  ref: string;
  bookingId: string;
  status: InvoiceStatus;
  notes: string;
  deleted: boolean;
  createdAt: string;
}

export interface Quote {
  id: string;
  ref: string;
  name: string;
  clientId: string;
  status: QuoteStatus;
  venue: string;
  eventDate: string;
  proposalDate: string;
  exclVat: number;
  people: number;
  dayShift: string;
  eveningShift: string;
  scope: string[];
  notes: string;
  rich: boolean;
  deleted: boolean;
  createdAt: string;
}

export interface Payment {
  id: string;
  ref: string;
  name: string;
  bookingId: string;
  amount: number;
  method: "Cash" | "EFT" | "Card";
  paidAt: string;
  deleted: boolean;
  createdAt: string;
}

export interface TaskItem {
  id: string;
  ref: string;
  name: string;
  status: "To Do" | "In Progress" | "Blocked" | "Done" | "Cancelled";
  due: string;
  owner: string;
  notes: string;
  deleted: boolean;
  createdAt: string;
}

export interface BudgetItem {
  id: string;
  ref: string;
  name: string;
  category: string;
  store: string;
  price: number;
  qty: number;
  purchased: boolean;
  archived: boolean;
  deleted: boolean;
  notes: string;
  createdAt: string;
}

export interface DocItem {
  id: string;
  ref: string;
  name: string;
  category: string;
  status: string;
  version: string;
  summary: string;
  deleted: boolean;
  createdAt: string;
}

export interface ScriptItem {
  id: string;
  ref: string;
  name: string;
  type: "WhatsApp" | "Call" | "Email";
  audience: string;
  body: string;
  status: string;
  deleted: boolean;
  createdAt: string;
}

export interface Equipment {
  id: string;
  ref: string;
  name: string;
  spec: string;
  status: "In Fleet" | "In Repair" | "Retired";
  base: string;
  notes: string;
  deleted: boolean;
  createdAt: string;
}

export interface FeedItem {
  id: string;
  title: string;
  body: string;
  at: string;
  kind: "booking" | "payment" | "quote" | "fleet" | "task" | "system";
  read: boolean;
}

export interface ServiceDef {
  id: string;
  name: string;
  price: number;
  cleaners: number;
  hours: number;
}

export const LABOUR_RATE = 45;
export const DEPOSIT_RATE = 0.4;
export const PROCESSING_RATE = 0.025;
export const EXTRA_ROOM_RATE = 80;
export const VAT_RATE = 0.15;

export const SERVICES: ServiceDef[] = [
  { id: "spring", name: "Spring Cleaning Special", price: 750, cleaners: 2, hours: 4 },
  { id: "standard", name: "Standard Home Clean", price: 450, cleaners: 1, hours: 4 },
  { id: "deep", name: "Deep Clean", price: 1200, cleaners: 2, hours: 6 },
  { id: "move", name: "Move-In / Move-Out", price: 980, cleaners: 2, hours: 5 },
  { id: "commercial", name: "Commercial Once-off", price: 1800, cleaners: 3, hours: 5 },
];

export const USERS = [
  { id: "phindi", name: "Miss Phindi", role: "Founder", pin: "0710", base: "Daveyton" },
  { id: "madhal", name: "Halandi Madalane", role: "Operations", pin: "2026", base: "Tsakane" },
  { id: "nicole", name: "Nicole Wilson", role: "Studio", pin: "1408", base: "Benoni" },
  { id: "admin", name: "Admin Desk", role: "Supervisor", pin: "1234", base: "Ekurhuleni" },
] as const;

export type UserId = (typeof USERS)[number]["id"];

export interface CostBreakdown {
  revenue: number;
  labour: number;
  labourHours: number;
  products: number;
  equipment: number;
  transport: number;
  processing: number;
  acquisition: number;
  admin: number;
  risk: number;
  delivery: number;
  contribution: number;
  margin: number;
  depositRequired: number;
  depositReceived: number;
  balanceDue: number;
  balanceBeforeCleaning: number;
}

export function round2(n: number) {
  return Math.round(n * 100) / 100;
}

export function money(n: number) {
  const sign = n < 0 ? "-" : "";
  const abs = Math.abs(n);
  return `${sign}R${abs.toLocaleString("en-ZA", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function todayISO(now = new Date()) {
  const m = String(now.getMonth() + 1).padStart(2, "0");
  const d = String(now.getDate()).padStart(2, "0");
  return `${now.getFullYear()}-${m}-${d}`;
}

export function parseDay(iso: string) {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y || 2026, (m || 1) - 1, d || 1);
}

export function formatDay(iso: string) {
  return new Intl.DateTimeFormat("en-ZA", { day: "2-digit", month: "long", year: "numeric" }).format(parseDay(iso));
}

export function formatWhen(iso: string) {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return new Intl.DateTimeFormat("en-ZA", {
    day: "2-digit",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(date);
}

export function timeAgo(iso: string, now = Date.now()) {
  const diff = now - new Date(iso).getTime();
  const m = Math.round(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.round(h / 24);
  if (d < 21) return `${d}d ago`;
  return formatWhen(iso);
}

export function greeting(now = new Date()) {
  const h = now.getHours();
  if (h < 12) return "morning";
  if (h < 17) return "afternoon";
  return "evening";
}

export function serviceById(id: string) {
  return SERVICES.find((s) => s.id === id) ?? SERVICES[0];
}

export function costBooking(b: Pick<
  Booking,
  | "cleaners"
  | "hours"
  | "serviceAmount"
  | "extraRooms"
  | "extraServices"
  | "travelCharge"
  | "discount"
  | "products"
  | "equipment"
  | "transport"
  | "acquisition"
  | "admin"
  | "risk"
>, depositReceived: number): CostBreakdown {
  const rooms = round2(b.extraRooms * EXTRA_ROOM_RATE);
  const revenue = round2(b.serviceAmount + rooms + b.extraServices + b.travelCharge - b.discount);
  const labourHours = b.cleaners * b.hours;
  const labour = round2(labourHours * LABOUR_RATE);
  const processing = round2(revenue * PROCESSING_RATE);
  const delivery = round2(labour + b.products + b.equipment + b.transport + processing + b.acquisition + b.admin + b.risk);
  const contribution = round2(revenue - delivery);
  const margin = revenue ? contribution / revenue : 0;
  const depositRequired = round2(revenue * DEPOSIT_RATE);
  return {
    revenue,
    labour,
    labourHours,
    products: b.products,
    equipment: b.equipment,
    transport: b.transport,
    processing,
    acquisition: b.acquisition,
    admin: b.admin,
    risk: b.risk,
    delivery,
    contribution,
    margin,
    depositRequired,
    depositReceived: round2(depositReceived),
    balanceDue: round2(revenue - depositReceived),
    balanceBeforeCleaning: round2(revenue - depositRequired),
  };
}

export function vatOf(excl: number) {
  const vat = round2(excl * VAT_RATE);
  return { vat, total: round2(excl + vat) };
}

export function nid(prefix: string) {
  return `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
}

export function nextRef(prefix: string, refs: string[]) {
  let max = 0;
  for (const ref of refs) {
    const n = Number(ref.replace(/\D/g, ""));
    if (!Number.isNaN(n)) max = Math.max(max, n);
  }
  return `${prefix}-${String(max + 1).padStart(6, "0")}`;
}

const COPY = {
  en: {
    home: "Home",
    office: "Office",
    updates: "Updates",
    menu: "Menu",
    morning: "Good morning",
    afternoon: "Good afternoon",
    evening: "Good evening",
    search: "Search clients, jobs, quotes",
    signIn: "Sign in",
    workspace: "Operations workspace",
    today: "Today’s run",
    recent: "Recent activity",
    settings: "Settings",
    logout: "Log out",
    about: "About",
    help: "Get help",
    newRecord: "New record",
  },
  zu: {
    home: "Ekhaya",
    office: "Ihhovisi",
    updates: "Izindaba",
    menu: "Imenyu",
    morning: "Sawubona",
    afternoon: "Sawubona",
    evening: "Sawubona",
    search: "Sesha amakhasimende nemisebenzi",
    signIn: "Ngena",
    workspace: "Indawo yokusebenza",
    today: "Umsebenzi wanamuhla",
    recent: "Okusanda kwenzeka",
    settings: "Izilungiselelo",
    logout: "Phuma",
    about: "Mayelana",
    help: "Usizo",
    newRecord: "Okusha",
  },
  af: {
    home: "Tuis",
    office: "Kantoor",
    updates: "Nuus",
    menu: "Kieslys",
    morning: "Goeiemôre",
    afternoon: "Goeiemiddag",
    evening: "Goeienaand",
    search: "Soek kliënte, werk, kwotasies",
    signIn: "Meld aan",
    workspace: "Bedryfswerkruimte",
    today: "Vandag se rondte",
    recent: "Onlangse aktiwiteit",
    settings: "Instellings",
    logout: "Teken uit",
    about: "Oor ons",
    help: "Hulp",
    newRecord: "Nuwe rekord",
  },
} as const;

export type CopyKey = keyof (typeof COPY)["en"];

export function t(lang: Lang, key: CopyKey) {
  return COPY[lang][key] || COPY.en[key];
}

const DEFAULT_OVERHEAD = {
  products: 85,
  equipment: 25,
  transport: 90,
  acquisition: 50,
  admin: 25,
  risk: 25,
};

export interface WorkspaceData {
  clients: Client[];
  properties: Property[];
  team: TeamMember[];
  bookings: Booking[];
  invoices: Invoice[];
  quotes: Quote[];
  payments: Payment[];
  tasks: TaskItem[];
  budget: BudgetItem[];
  documents: DocItem[];
  scripts: ScriptItem[];
  equipment: Equipment[];
  feed: FeedItem[];
}

export function seedWorkspace(now = new Date()): WorkspaceData {
  const today = todayISO(now);
  const stamp = now.toISOString();
  const ago = (hours: number) => new Date(now.getTime() - hours * 3600_000).toISOString();

  const clients: Client[] = [
    { id: "cli_john", ref: "CLI-000001", name: "John Doe", phone: "082 555 0142", email: "john.doe@email.com", area: "KwaThema", type: "Residential", status: "Active", notes: "Spring clean. Inner zone from Tsakane.", deleted: false, createdAt: "2026-08-04T08:00:00.000Z" },
    { id: "cli_jabu", ref: "CLI-000002", name: "Jabulani Bafana Nkosi", phone: "073 441 2280", email: "", area: "Vosloorus", type: "Residential", status: "Active", notes: "Deposit still outstanding before the team rolls.", deleted: false, createdAt: "2026-08-09T08:00:00.000Z" },
    { id: "cli_tebogo", ref: "CLI-000003", name: "Tebogo Mantambo", phone: "061 880 4412", email: "events@cafe69.co.za", area: "KwaThema", type: "Event", status: "Lead", notes: "Cafe69 All White Affair. Confirm attendance before locking headcount.", deleted: false, createdAt: "2026-09-20T08:00:00.000Z" },
    { id: "cli_lindi", ref: "CLI-000004", name: "Lindiwe Mahlangu", phone: "071 334 9088", email: "", area: "Tsakane", type: "Residential", status: "Active", notes: "Prefers morning arrival. Gate code with security.", deleted: false, createdAt: ago(48) },
    { id: "cli_green", ref: "CLI-000005", name: "Greenstone Medical", phone: "011 458 2200", email: "facilities@greenstonemed.co.za", area: "Modderfontein", type: "Corporate", status: "Lead", notes: "Requested a corporate cleaning assessment.", deleted: false, createdAt: ago(72) },
  ];

  const properties: Property[] = [
    { id: "prop_john", ref: "PROP-000001", name: "123 Main Street", clientId: "cli_john", address: "123 Main Street, KwaThema", area: "KwaThema", base: "Tsakane", zone: "Inner", notes: "", deleted: false, createdAt: "2026-08-04T08:00:00.000Z" },
    { id: "prop_jabu", ref: "PROP-000002", name: "1159 Sindane Street", clientId: "cli_jabu", address: "1159 Sindane Street, Vosloorus Extension 2, 1475", area: "Vosloorus", base: "Benoni", zone: "—", notes: "", deleted: false, createdAt: "2026-08-09T08:00:00.000Z" },
    { id: "prop_stadium", ref: "PROP-000003", name: "Kwa-Thema Stadium", clientId: "cli_tebogo", address: "Kwa-Thema Stadium, KwaThema", area: "KwaThema", base: "Tsakane", zone: "Event", notes: "Up to 9,000 guests. Planning figure only.", deleted: false, createdAt: "2026-09-20T08:00:00.000Z" },
    { id: "prop_lindi", ref: "PROP-000004", name: "42 Ndabezitha Street", clientId: "cli_lindi", address: "42 Ndabezitha Street, Tsakane", area: "Tsakane", base: "Tsakane", zone: "Inner", notes: "", deleted: false, createdAt: ago(48) },
    { id: "prop_green", ref: "PROP-000005", name: "Greenstone consulting rooms", clientId: "cli_green", address: "Emerald Boulevard, Greenstone, Modderfontein", area: "Modderfontein", base: "Benoni", zone: "Commercial", notes: "", deleted: false, createdAt: ago(72) },
  ];

  const team: TeamMember[] = [
    { id: "emp_thandi", ref: "EMP-0001", name: "Thandi Mokoena", role: "Team Leader", phone: "072 610 4410", base: "Tsakane", status: "Active", notes: "Leads residential pairs.", deleted: false, createdAt: "2026-03-01T08:00:00.000Z" },
    { id: "emp_sipho", ref: "EMP-0002", name: "Sipho Dlamini", role: "Professional Residential Cleaner", phone: "073 220 1184", base: "Tsakane", status: "Active", notes: "Probation completed.", deleted: false, createdAt: "2026-04-12T08:00:00.000Z" },
    { id: "emp_nomsa", ref: "EMP-0003", name: "Nomsa Khumalo", role: "Professional Residential Cleaner", phone: "082 771 0933", base: "Benoni", status: "Active", notes: "", deleted: false, createdAt: "2026-05-02T08:00:00.000Z" },
    { id: "emp_lerato", ref: "EMP-0004", name: "Lerato Nkosi", role: "Professional Residential Cleaner", phone: "071 909 6621", base: "Daveyton", status: "On Leave", notes: "Back Monday.", deleted: false, createdAt: "2026-02-18T08:00:00.000Z" },
    { id: "emp_karabo", ref: "EMP-0005", name: "Karabo Molefe", role: "Supervisor", phone: "060 448 2175", base: "Benoni", status: "Active", notes: "Event deployments and quality sign-off.", deleted: false, createdAt: "2026-01-09T08:00:00.000Z" },
  ];

  const spring = serviceById("spring");
  const bookings: Booking[] = [
    {
      id: "bkg_lindi",
      ref: "BK-000003",
      name: "Lindiwe Mahlangu · Spring clean",
      clientId: "cli_lindi",
      propertyId: "prop_lindi",
      serviceId: spring.id,
      serviceDate: today,
      status: "Assigned",
      cleaners: spring.cleaners,
      hours: spring.hours,
      serviceAmount: spring.price,
      extraRooms: 0,
      extraServices: 0,
      travelCharge: 0,
      discount: 0,
      ...DEFAULT_OVERHEAD,
      teamIds: ["emp_thandi", "emp_sipho"],
      notes: "Deposit received. Team meets at Tsakane base, then Ndabezitha Street.",
      deleted: false,
      createdAt: ago(20),
    },
    {
      id: "bkg_jabu",
      ref: "TC-SPR-0002",
      name: "Jabulani Bafana Nkosi · Spring clean",
      clientId: "cli_jabu",
      propertyId: "prop_jabu",
      serviceId: "spring",
      serviceDate: "2026-08-16",
      status: "Pending",
      cleaners: 2,
      hours: 4,
      serviceAmount: 750,
      extraRooms: 0,
      extraServices: 0,
      travelCharge: 0,
      discount: 0,
      ...DEFAULT_OVERHEAD,
      teamIds: ["emp_nomsa", "emp_thandi"],
      notes: "Do not roll the team until the 40% deposit lands. Benoni base.",
      deleted: false,
      createdAt: "2026-08-11T16:40:00.000Z",
    },
    {
      id: "bkg_john",
      ref: "TC-BKG-79790",
      name: "John Doe · Spring clean",
      clientId: "cli_john",
      propertyId: "prop_john",
      serviceId: "spring",
      serviceDate: "2026-08-11",
      status: "Completed",
      cleaners: 2,
      hours: 4,
      serviceAmount: 750,
      extraRooms: 0,
      extraServices: 0,
      travelCharge: 0,
      discount: 0,
      ...DEFAULT_OVERHEAD,
      teamIds: ["emp_sipho", "emp_nomsa"],
      notes: "Job done. Customer invoice still unpaid in full.",
      deleted: false,
      createdAt: "2026-08-08T09:00:00.000Z",
    },
  ];

  const invoices: Invoice[] = [
    { id: "inv_lindi", ref: "TC-INT-0003", bookingId: "bkg_lindi", status: "Partially Paid", notes: "Internal costing. Not the customer invoice.", deleted: false, createdAt: ago(20) },
    { id: "inv_jabu", ref: "TC-INT-0002", bookingId: "bkg_jabu", status: "Sent", notes: "Booking TC-SPR-0002 · Vosloorus · Benoni base.", deleted: false, createdAt: "2026-08-11T16:40:00.000Z" },
    { id: "inv_john", ref: "TC-INT-43599", bookingId: "bkg_john", status: "Overdue", notes: "Booking TC-BKG-79790 · KwaThema · Tsakane base.", deleted: false, createdAt: "2026-08-11T10:00:00.000Z" },
  ];

  const quotes: Quote[] = [
    {
      id: "qt_cafe",
      ref: "QT-000001",
      name: "Cafe69 All White Affair",
      clientId: "cli_tebogo",
      status: "Sent",
      venue: "Kwa-Thema Stadium",
      eventDate: "2026-11-28",
      proposalDate: "2026-09-23",
      exclVat: 81653.33,
      people: 27,
      dayShift: "08:00–20:00 · 8 cleaners · 1 supervisor",
      eveningShift: "13:00–01:00 · 16 cleaners · 2 supervisors",
      scope: [
        "Venue ready before guests arrive",
        "Continuous cleaning while the event is live",
        "Bathroom monitoring through operating hours",
        "Litter control across the agreed stadium footprint",
        "VIP and food & beverage support",
        "Waste handling through to disposal",
        "Handover-ready venue after the last guest",
      ],
      notes: "Planning figure up to 9,000 guests. Lock headcount once ticket sales, bathrooms and hours are confirmed. Extra people are quoted before they are sent.",
      rich: true,
      deleted: false,
      createdAt: "2026-09-23T07:30:00.000Z",
    },
    {
      id: "qt_green",
      ref: "QT-000002",
      name: "Greenstone rooms · weekly clean",
      clientId: "cli_green",
      status: "Draft",
      venue: "Greenstone consulting rooms",
      eventDate: "2026-10-06",
      proposalDate: today,
      exclVat: 6400,
      people: 2,
      dayShift: "After-hours, two evenings a week",
      eveningShift: "",
      scope: ["Clinical waiting areas", "Consulting rooms", "Staff kitchen", "Weekly consumables"],
      notes: "Assessment still to be walked. Do not send until Karabo signs the floor count.",
      rich: false,
      deleted: false,
      createdAt: ago(6),
    },
  ];

  const payments: Payment[] = [
    { id: "pay_lindi", ref: "PAY-000001", name: "Lindiwe deposit", bookingId: "bkg_lindi", amount: 300, method: "EFT", paidAt: ago(18), deleted: false, createdAt: ago(18) },
  ];

  const tasks: TaskItem[] = [
    { id: "task_dep", ref: "TSK-000001", name: "Collect Jabulani deposit before rollout", status: "To Do", due: today, owner: "Miss Phindi", notes: "40% of R750 is R300. Balance before cleaning is R450.", deleted: false, createdAt: ago(30) },
    { id: "task_cafe", ref: "TSK-000002", name: "Confirm Cafe69 bathroom count", status: "In Progress", due: "2026-10-15", owner: "Karabo Molefe", notes: "Headcount stays 27 until Tebogo confirms attendance.", deleted: false, createdAt: ago(5) },
    { id: "task_vac", ref: "TSK-000003", name: "Log Dexter vacuum into the Benoni cage", status: "Done", due: "2026-09-18", owner: "Halandi Madalane", notes: "1400W · 20L · 15 kPa · blower.", deleted: false, createdAt: ago(120) },
  ];

  const budget: BudgetItem[] = [
    { id: "exp_1", ref: "EXP-000001", name: "Microfibre cloths (20)", category: "Consumables", store: "Builders", price: 12.5, qty: 20, purchased: true, archived: false, deleted: false, notes: "", createdAt: ago(80) },
    { id: "exp_2", ref: "EXP-000002", name: "All-purpose cleaner 5L", category: "Chemicals", store: "Checkers", price: 89, qty: 4, purchased: true, archived: false, deleted: false, notes: "", createdAt: ago(60) },
    { id: "exp_3", ref: "EXP-000003", name: "Nitrile gloves box", category: "PPE", store: "Builders", price: 64, qty: 6, purchased: false, archived: false, deleted: false, notes: "Restock before Saturday runs.", createdAt: ago(10) },
    { id: "exp_4", ref: "EXP-000004", name: "Fuel · Tsakane loop", category: "Transport", store: "Engen", price: 180, qty: 3, purchased: true, archived: false, deleted: false, notes: "", createdAt: ago(26) },
    { id: "exp_5", ref: "EXP-000005", name: "Bin liners heavy duty", category: "Consumables", store: "Makro", price: 45, qty: 8, purchased: false, archived: false, deleted: false, notes: "", createdAt: ago(8) },
  ];

  const documents: DocItem[] = [
    { id: "doc_contract", ref: "DOC-EMP-01", name: "Employment contract · residential cleaner", category: "Contracts", status: "Active", version: "1.0", summary: "Permanent or fixed-term professional residential cleaner. Three-month probation, extendable once. Work is at customer homes across Gauteng, not a fixed office. Complies with BCEA, LRA, OHSA and POPIA. Employer contact 061 467 9207 · info@terracelest.co.za.", deleted: false, createdAt: "2026-08-03T08:00:00.000Z" },
    { id: "doc_corp", ref: "DOC-CAP-01", name: "Corporate capability profile", category: "Business Documents", status: "Active", version: "1.0", summary: "Commercial, recurring, deep, post-construction, move-in/out and multi-site cleaning. Process: enquire, assess, propose, quote, schedule, deliver, continue. Focused on Ekurhuleni businesses.", deleted: false, createdAt: "2026-08-03T08:00:00.000Z" },
    { id: "doc_style", ref: "DOC-BRD-01", name: "Facilities design style guide", category: "Brand", status: "Active", version: "1.0", summary: "Teal #00A69C, navy #0B1D3A, aqua #35C1BC, Montserrat. Tagline: Clean spaces. Better places. Values: Empower, Innovate, Elevate.", deleted: false, createdAt: "2026-08-01T08:00:00.000Z" },
  ];

  const scripts: ScriptItem[] = [
    { id: "scr_wa", ref: "SCR-000001", name: "Deposit reminder", type: "WhatsApp", audience: "Residential customer", status: "Active", body: "Sawubona {name}, this is TerraCelest Facilities. Your {service} is booked for {date} at {address}. The 40% deposit is {deposit}. Please pay so we can lock your team. Balance before cleaning is {before}. Clean spaces. Better places.", deleted: false, createdAt: "2026-08-01T08:00:00.000Z" },
    { id: "scr_call", ref: "SCR-000002", name: "Morning arrival call", type: "Call", audience: "Residential customer", status: "Active", body: "Good morning, this is {leader} from TerraCelest. We are on the way to {address} and should be with you shortly. The clean is planned for {hours} hours with {cleaners} people. Please have water access open.", deleted: false, createdAt: "2026-08-01T08:00:00.000Z" },
    { id: "scr_mail", ref: "SCR-000003", name: "Event proposal cover", type: "Email", audience: "Event organiser", status: "Active", body: "Thank you for the opportunity to support {event}. This proposal sets out how TerraCelest will keep the venue clean before doors, through the event, and after the last guest leaves. Guests should notice the standard of the venue, not the work behind it.", deleted: false, createdAt: "2026-09-22T08:00:00.000Z" },
  ];

  const equipment: Equipment[] = [
    { id: "eq_dexter", ref: "EQ-000001", name: "Dexter Power 1400W wet & dry", spec: "20L stainless steel · 15 kPa · blower", status: "In Fleet", base: "Benoni", notes: "Added to the fleet for deep cleans and commercial work.", deleted: false, createdAt: ago(140) },
    { id: "eq_mop", ref: "EQ-000002", name: "Commercial mop system", spec: "Dual bucket · microfibre pads", status: "In Fleet", base: "Tsakane", notes: "", deleted: false, createdAt: "2026-06-01T08:00:00.000Z" },
  ];

  const feed: FeedItem[] = [
    { id: "fd_cafe", title: "Quote sent · Cafe69 All White Affair", body: "R93,901.33 incl. VAT for 27 people at Kwa-Thema Stadium on 28 November 2026.", at: "2026-09-23T07:40:00.000Z", kind: "quote", read: false },
    { id: "fd_vac", title: "Fleet · Dexter 1400W wet & dry", body: "20L stainless, 15 kPa, blower function. Logged at the Benoni cage.", at: ago(140), kind: "fleet", read: false },
    { id: "fd_dep", title: "Deposit received · Lindiwe Mahlangu", body: "R300.00 EFT against today’s spring clean. Balance due R450.00.", at: ago(18), kind: "payment", read: true },
    { id: "fd_jabu", title: "Booking still unpaid · Jabulani Nkosi", body: "TC-SPR-0002 is pending. Do not dispatch until R300 deposit is in.", at: ago(30), kind: "booking", read: true },
    { id: "fd_john", title: "Job completed · John Doe", body: "TC-BKG-79790 finished. Contribution on the internal record is R71.25 (9.50%). Invoice still overdue.", at: "2026-08-11T17:00:00.000Z", kind: "booking", read: true },
  ];

  void stamp;
  return { clients, properties, team, bookings, invoices, quotes, payments, tasks, budget, documents, scripts, equipment, feed };
}

export function depositFor(bookingId: string, payments: Payment[]) {
  return round2(payments.filter((p) => !p.deleted && p.bookingId === bookingId).reduce((s, p) => s + p.amount, 0));
}

export function active<T extends { deleted: boolean }>(rows: T[]) {
  return rows.filter((r) => !r.deleted);
}

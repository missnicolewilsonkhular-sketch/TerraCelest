import { createFileRoute } from "@tanstack/react-router";
import { TerraApp } from "@/components/tc/terra-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <TerraApp />;
}

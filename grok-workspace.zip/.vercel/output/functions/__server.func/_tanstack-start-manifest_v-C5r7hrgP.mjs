//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C5r7hrgP.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-D_-tkcgp.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D_-tkcgp.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DoGVR8gc.js"]
	}
} });
//#endregion
export { tsrStartManifest };

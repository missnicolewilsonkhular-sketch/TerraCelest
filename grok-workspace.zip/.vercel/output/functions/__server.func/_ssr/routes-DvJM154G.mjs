import { i as __toESM } from "../_runtime.mjs";
import { R as require_react, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Building2, c as Plus, d as Menu, f as LayoutGrid, g as Calendar, h as ClipboardList, i as Users, l as Phone, m as FileText, n as Wrench, o as Search, p as House, r as Wallet, s as Receipt, t as X, u as MessageSquare, v as Bell, y as Archive } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DvJM154G.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DEPOSIT_RATE = .4;
var PROCESSING_RATE = .025;
var VAT_RATE = .15;
var SERVICES = [
	{
		id: "spring",
		name: "Spring Cleaning Special",
		price: 750,
		cleaners: 2,
		hours: 4
	},
	{
		id: "standard",
		name: "Standard Home Clean",
		price: 450,
		cleaners: 1,
		hours: 4
	},
	{
		id: "deep",
		name: "Deep Clean",
		price: 1200,
		cleaners: 2,
		hours: 6
	},
	{
		id: "move",
		name: "Move-In / Move-Out",
		price: 980,
		cleaners: 2,
		hours: 5
	},
	{
		id: "commercial",
		name: "Commercial Once-off",
		price: 1800,
		cleaners: 3,
		hours: 5
	}
];
var USERS = [
	{
		id: "phindi",
		name: "Miss Phindi",
		role: "Founder",
		pin: "0710",
		base: "Daveyton"
	},
	{
		id: "madhal",
		name: "Halandi Madalane",
		role: "Operations",
		pin: "2026",
		base: "Tsakane"
	},
	{
		id: "nicole",
		name: "Nicole Wilson",
		role: "Studio",
		pin: "1408",
		base: "Benoni"
	},
	{
		id: "admin",
		name: "Admin Desk",
		role: "Supervisor",
		pin: "1234",
		base: "Ekurhuleni"
	}
];
function round2(n) {
	return Math.round(n * 100) / 100;
}
function money(n) {
	return `${n < 0 ? "-" : ""}R${Math.abs(n).toLocaleString("en-ZA", {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	})}`;
}
function todayISO(now = /* @__PURE__ */ new Date()) {
	const m = String(now.getMonth() + 1).padStart(2, "0");
	const d = String(now.getDate()).padStart(2, "0");
	return `${now.getFullYear()}-${m}-${d}`;
}
function parseDay(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	return new Date(y || 2026, (m || 1) - 1, d || 1);
}
function formatDay(iso) {
	return new Intl.DateTimeFormat("en-ZA", {
		day: "2-digit",
		month: "long",
		year: "numeric"
	}).format(parseDay(iso));
}
function formatWhen(iso) {
	const date = new Date(iso);
	if (Number.isNaN(date.getTime())) return iso;
	return new Intl.DateTimeFormat("en-ZA", {
		day: "2-digit",
		month: "long",
		year: "numeric",
		hour: "2-digit",
		minute: "2-digit",
		hour12: false
	}).format(date);
}
function timeAgo(iso, now = Date.now()) {
	const diff = now - new Date(iso).getTime();
	const m = Math.round(diff / 6e4);
	if (m < 1) return "just now";
	if (m < 60) return `${m}m ago`;
	const h = Math.round(m / 60);
	if (h < 24) return `${h}h ago`;
	const d = Math.round(h / 24);
	if (d < 21) return `${d}d ago`;
	return formatWhen(iso);
}
function greeting(now = /* @__PURE__ */ new Date()) {
	const h = now.getHours();
	if (h < 12) return "morning";
	if (h < 17) return "afternoon";
	return "evening";
}
function serviceById(id) {
	return SERVICES.find((s) => s.id === id) ?? SERVICES[0];
}
function costBooking(b, depositReceived) {
	const rooms = round2(b.extraRooms * 80);
	const revenue = round2(b.serviceAmount + rooms + b.extraServices + b.travelCharge - b.discount);
	const labourHours = b.cleaners * b.hours;
	const labour = round2(labourHours * 45);
	const processing = round2(revenue * PROCESSING_RATE);
	const delivery = round2(labour + b.products + b.equipment + b.transport + processing + b.acquisition + b.admin + b.risk);
	const contribution = round2(revenue - delivery);
	const margin = revenue ? contribution / revenue : 0;
	const depositRequired = round2(revenue * DEPOSIT_RATE);
	return {
		revenue,
		labour,
		labourHours,
		products: b.products,
		equipment: b.equipment,
		transport: b.transport,
		processing,
		acquisition: b.acquisition,
		admin: b.admin,
		risk: b.risk,
		delivery,
		contribution,
		margin,
		depositRequired,
		depositReceived: round2(depositReceived),
		balanceDue: round2(revenue - depositReceived),
		balanceBeforeCleaning: round2(revenue - depositRequired)
	};
}
function vatOf(excl) {
	const vat = round2(excl * VAT_RATE);
	return {
		vat,
		total: round2(excl + vat)
	};
}
function nid(prefix) {
	return `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
}
function nextRef(prefix, refs) {
	let max = 0;
	for (const ref of refs) {
		const n = Number(ref.replace(/\D/g, ""));
		if (!Number.isNaN(n)) max = Math.max(max, n);
	}
	return `${prefix}-${String(max + 1).padStart(6, "0")}`;
}
var COPY = {
	en: {
		home: "Home",
		office: "Office",
		updates: "Updates",
		menu: "Menu",
		morning: "Good morning",
		afternoon: "Good afternoon",
		evening: "Good evening",
		search: "Search clients, jobs, quotes",
		signIn: "Sign in",
		workspace: "Operations workspace",
		today: "Today’s run",
		recent: "Recent activity",
		settings: "Settings",
		logout: "Log out",
		about: "About",
		help: "Get help",
		newRecord: "New record"
	},
	zu: {
		home: "Ekhaya",
		office: "Ihhovisi",
		updates: "Izindaba",
		menu: "Imenyu",
		morning: "Sawubona",
		afternoon: "Sawubona",
		evening: "Sawubona",
		search: "Sesha amakhasimende nemisebenzi",
		signIn: "Ngena",
		workspace: "Indawo yokusebenza",
		today: "Umsebenzi wanamuhla",
		recent: "Okusanda kwenzeka",
		settings: "Izilungiselelo",
		logout: "Phuma",
		about: "Mayelana",
		help: "Usizo",
		newRecord: "Okusha"
	},
	af: {
		home: "Tuis",
		office: "Kantoor",
		updates: "Nuus",
		menu: "Kieslys",
		morning: "Goeiemôre",
		afternoon: "Goeiemiddag",
		evening: "Goeienaand",
		search: "Soek kliënte, werk, kwotasies",
		signIn: "Meld aan",
		workspace: "Bedryfswerkruimte",
		today: "Vandag se rondte",
		recent: "Onlangse aktiwiteit",
		settings: "Instellings",
		logout: "Teken uit",
		about: "Oor ons",
		help: "Hulp",
		newRecord: "Nuwe rekord"
	}
};
function t(lang, key) {
	return COPY[lang][key] || COPY.en[key];
}
var DEFAULT_OVERHEAD = {
	products: 85,
	equipment: 25,
	transport: 90,
	acquisition: 50,
	admin: 25,
	risk: 25
};
function seedWorkspace(now = /* @__PURE__ */ new Date()) {
	const today = todayISO(now);
	now.toISOString();
	const ago = (hours) => (/* @__PURE__ */ new Date(now.getTime() - hours * 36e5)).toISOString();
	const clients = [
		{
			id: "cli_john",
			ref: "CLI-000001",
			name: "John Doe",
			phone: "082 555 0142",
			email: "john.doe@email.com",
			area: "KwaThema",
			type: "Residential",
			status: "Active",
			notes: "Spring clean. Inner zone from Tsakane.",
			deleted: false,
			createdAt: "2026-08-04T08:00:00.000Z"
		},
		{
			id: "cli_jabu",
			ref: "CLI-000002",
			name: "Jabulani Bafana Nkosi",
			phone: "073 441 2280",
			email: "",
			area: "Vosloorus",
			type: "Residential",
			status: "Active",
			notes: "Deposit still outstanding before the team rolls.",
			deleted: false,
			createdAt: "2026-08-09T08:00:00.000Z"
		},
		{
			id: "cli_tebogo",
			ref: "CLI-000003",
			name: "Tebogo Mantambo",
			phone: "061 880 4412",
			email: "events@cafe69.co.za",
			area: "KwaThema",
			type: "Event",
			status: "Lead",
			notes: "Cafe69 All White Affair. Confirm attendance before locking headcount.",
			deleted: false,
			createdAt: "2026-09-20T08:00:00.000Z"
		},
		{
			id: "cli_lindi",
			ref: "CLI-000004",
			name: "Lindiwe Mahlangu",
			phone: "071 334 9088",
			email: "",
			area: "Tsakane",
			type: "Residential",
			status: "Active",
			notes: "Prefers morning arrival. Gate code with security.",
			deleted: false,
			createdAt: ago(48)
		},
		{
			id: "cli_green",
			ref: "CLI-000005",
			name: "Greenstone Medical",
			phone: "011 458 2200",
			email: "facilities@greenstonemed.co.za",
			area: "Modderfontein",
			type: "Corporate",
			status: "Lead",
			notes: "Requested a corporate cleaning assessment.",
			deleted: false,
			createdAt: ago(72)
		}
	];
	const properties = [
		{
			id: "prop_john",
			ref: "PROP-000001",
			name: "123 Main Street",
			clientId: "cli_john",
			address: "123 Main Street, KwaThema",
			area: "KwaThema",
			base: "Tsakane",
			zone: "Inner",
			notes: "",
			deleted: false,
			createdAt: "2026-08-04T08:00:00.000Z"
		},
		{
			id: "prop_jabu",
			ref: "PROP-000002",
			name: "1159 Sindane Street",
			clientId: "cli_jabu",
			address: "1159 Sindane Street, Vosloorus Extension 2, 1475",
			area: "Vosloorus",
			base: "Benoni",
			zone: "—",
			notes: "",
			deleted: false,
			createdAt: "2026-08-09T08:00:00.000Z"
		},
		{
			id: "prop_stadium",
			ref: "PROP-000003",
			name: "Kwa-Thema Stadium",
			clientId: "cli_tebogo",
			address: "Kwa-Thema Stadium, KwaThema",
			area: "KwaThema",
			base: "Tsakane",
			zone: "Event",
			notes: "Up to 9,000 guests. Planning figure only.",
			deleted: false,
			createdAt: "2026-09-20T08:00:00.000Z"
		},
		{
			id: "prop_lindi",
			ref: "PROP-000004",
			name: "42 Ndabezitha Street",
			clientId: "cli_lindi",
			address: "42 Ndabezitha Street, Tsakane",
			area: "Tsakane",
			base: "Tsakane",
			zone: "Inner",
			notes: "",
			deleted: false,
			createdAt: ago(48)
		},
		{
			id: "prop_green",
			ref: "PROP-000005",
			name: "Greenstone consulting rooms",
			clientId: "cli_green",
			address: "Emerald Boulevard, Greenstone, Modderfontein",
			area: "Modderfontein",
			base: "Benoni",
			zone: "Commercial",
			notes: "",
			deleted: false,
			createdAt: ago(72)
		}
	];
	const team = [
		{
			id: "emp_thandi",
			ref: "EMP-0001",
			name: "Thandi Mokoena",
			role: "Team Leader",
			phone: "072 610 4410",
			base: "Tsakane",
			status: "Active",
			notes: "Leads residential pairs.",
			deleted: false,
			createdAt: "2026-03-01T08:00:00.000Z"
		},
		{
			id: "emp_sipho",
			ref: "EMP-0002",
			name: "Sipho Dlamini",
			role: "Professional Residential Cleaner",
			phone: "073 220 1184",
			base: "Tsakane",
			status: "Active",
			notes: "Probation completed.",
			deleted: false,
			createdAt: "2026-04-12T08:00:00.000Z"
		},
		{
			id: "emp_nomsa",
			ref: "EMP-0003",
			name: "Nomsa Khumalo",
			role: "Professional Residential Cleaner",
			phone: "082 771 0933",
			base: "Benoni",
			status: "Active",
			notes: "",
			deleted: false,
			createdAt: "2026-05-02T08:00:00.000Z"
		},
		{
			id: "emp_lerato",
			ref: "EMP-0004",
			name: "Lerato Nkosi",
			role: "Professional Residential Cleaner",
			phone: "071 909 6621",
			base: "Daveyton",
			status: "On Leave",
			notes: "Back Monday.",
			deleted: false,
			createdAt: "2026-02-18T08:00:00.000Z"
		},
		{
			id: "emp_karabo",
			ref: "EMP-0005",
			name: "Karabo Molefe",
			role: "Supervisor",
			phone: "060 448 2175",
			base: "Benoni",
			status: "Active",
			notes: "Event deployments and quality sign-off.",
			deleted: false,
			createdAt: "2026-01-09T08:00:00.000Z"
		}
	];
	const spring = serviceById("spring");
	return {
		clients,
		properties,
		team,
		bookings: [
			{
				id: "bkg_lindi",
				ref: "BK-000003",
				name: "Lindiwe Mahlangu · Spring clean",
				clientId: "cli_lindi",
				propertyId: "prop_lindi",
				serviceId: spring.id,
				serviceDate: today,
				status: "Assigned",
				cleaners: spring.cleaners,
				hours: spring.hours,
				serviceAmount: spring.price,
				extraRooms: 0,
				extraServices: 0,
				travelCharge: 0,
				discount: 0,
				...DEFAULT_OVERHEAD,
				teamIds: ["emp_thandi", "emp_sipho"],
				notes: "Deposit received. Team meets at Tsakane base, then Ndabezitha Street.",
				deleted: false,
				createdAt: ago(20)
			},
			{
				id: "bkg_jabu",
				ref: "TC-SPR-0002",
				name: "Jabulani Bafana Nkosi · Spring clean",
				clientId: "cli_jabu",
				propertyId: "prop_jabu",
				serviceId: "spring",
				serviceDate: "2026-08-16",
				status: "Pending",
				cleaners: 2,
				hours: 4,
				serviceAmount: 750,
				extraRooms: 0,
				extraServices: 0,
				travelCharge: 0,
				discount: 0,
				...DEFAULT_OVERHEAD,
				teamIds: ["emp_nomsa", "emp_thandi"],
				notes: "Do not roll the team until the 40% deposit lands. Benoni base.",
				deleted: false,
				createdAt: "2026-08-11T16:40:00.000Z"
			},
			{
				id: "bkg_john",
				ref: "TC-BKG-79790",
				name: "John Doe · Spring clean",
				clientId: "cli_john",
				propertyId: "prop_john",
				serviceId: "spring",
				serviceDate: "2026-08-11",
				status: "Completed",
				cleaners: 2,
				hours: 4,
				serviceAmount: 750,
				extraRooms: 0,
				extraServices: 0,
				travelCharge: 0,
				discount: 0,
				...DEFAULT_OVERHEAD,
				teamIds: ["emp_sipho", "emp_nomsa"],
				notes: "Job done. Customer invoice still unpaid in full.",
				deleted: false,
				createdAt: "2026-08-08T09:00:00.000Z"
			}
		],
		invoices: [
			{
				id: "inv_lindi",
				ref: "TC-INT-0003",
				bookingId: "bkg_lindi",
				status: "Partially Paid",
				notes: "Internal costing. Not the customer invoice.",
				deleted: false,
				createdAt: ago(20)
			},
			{
				id: "inv_jabu",
				ref: "TC-INT-0002",
				bookingId: "bkg_jabu",
				status: "Sent",
				notes: "Booking TC-SPR-0002 · Vosloorus · Benoni base.",
				deleted: false,
				createdAt: "2026-08-11T16:40:00.000Z"
			},
			{
				id: "inv_john",
				ref: "TC-INT-43599",
				bookingId: "bkg_john",
				status: "Overdue",
				notes: "Booking TC-BKG-79790 · KwaThema · Tsakane base.",
				deleted: false,
				createdAt: "2026-08-11T10:00:00.000Z"
			}
		],
		quotes: [{
			id: "qt_cafe",
			ref: "QT-000001",
			name: "Cafe69 All White Affair",
			clientId: "cli_tebogo",
			status: "Sent",
			venue: "Kwa-Thema Stadium",
			eventDate: "2026-11-28",
			proposalDate: "2026-09-23",
			exclVat: 81653.33,
			people: 27,
			dayShift: "08:00–20:00 · 8 cleaners · 1 supervisor",
			eveningShift: "13:00–01:00 · 16 cleaners · 2 supervisors",
			scope: [
				"Venue ready before guests arrive",
				"Continuous cleaning while the event is live",
				"Bathroom monitoring through operating hours",
				"Litter control across the agreed stadium footprint",
				"VIP and food & beverage support",
				"Waste handling through to disposal",
				"Handover-ready venue after the last guest"
			],
			notes: "Planning figure up to 9,000 guests. Lock headcount once ticket sales, bathrooms and hours are confirmed. Extra people are quoted before they are sent.",
			rich: true,
			deleted: false,
			createdAt: "2026-09-23T07:30:00.000Z"
		}, {
			id: "qt_green",
			ref: "QT-000002",
			name: "Greenstone rooms · weekly clean",
			clientId: "cli_green",
			status: "Draft",
			venue: "Greenstone consulting rooms",
			eventDate: "2026-10-06",
			proposalDate: today,
			exclVat: 6400,
			people: 2,
			dayShift: "After-hours, two evenings a week",
			eveningShift: "",
			scope: [
				"Clinical waiting areas",
				"Consulting rooms",
				"Staff kitchen",
				"Weekly consumables"
			],
			notes: "Assessment still to be walked. Do not send until Karabo signs the floor count.",
			rich: false,
			deleted: false,
			createdAt: ago(6)
		}],
		payments: [{
			id: "pay_lindi",
			ref: "PAY-000001",
			name: "Lindiwe deposit",
			bookingId: "bkg_lindi",
			amount: 300,
			method: "EFT",
			paidAt: ago(18),
			deleted: false,
			createdAt: ago(18)
		}],
		tasks: [
			{
				id: "task_dep",
				ref: "TSK-000001",
				name: "Collect Jabulani deposit before rollout",
				status: "To Do",
				due: today,
				owner: "Miss Phindi",
				notes: "40% of R750 is R300. Balance before cleaning is R450.",
				deleted: false,
				createdAt: ago(30)
			},
			{
				id: "task_cafe",
				ref: "TSK-000002",
				name: "Confirm Cafe69 bathroom count",
				status: "In Progress",
				due: "2026-10-15",
				owner: "Karabo Molefe",
				notes: "Headcount stays 27 until Tebogo confirms attendance.",
				deleted: false,
				createdAt: ago(5)
			},
			{
				id: "task_vac",
				ref: "TSK-000003",
				name: "Log Dexter vacuum into the Benoni cage",
				status: "Done",
				due: "2026-09-18",
				owner: "Halandi Madalane",
				notes: "1400W · 20L · 15 kPa · blower.",
				deleted: false,
				createdAt: ago(120)
			}
		],
		budget: [
			{
				id: "exp_1",
				ref: "EXP-000001",
				name: "Microfibre cloths (20)",
				category: "Consumables",
				store: "Builders",
				price: 12.5,
				qty: 20,
				purchased: true,
				archived: false,
				deleted: false,
				notes: "",
				createdAt: ago(80)
			},
			{
				id: "exp_2",
				ref: "EXP-000002",
				name: "All-purpose cleaner 5L",
				category: "Chemicals",
				store: "Checkers",
				price: 89,
				qty: 4,
				purchased: true,
				archived: false,
				deleted: false,
				notes: "",
				createdAt: ago(60)
			},
			{
				id: "exp_3",
				ref: "EXP-000003",
				name: "Nitrile gloves box",
				category: "PPE",
				store: "Builders",
				price: 64,
				qty: 6,
				purchased: false,
				archived: false,
				deleted: false,
				notes: "Restock before Saturday runs.",
				createdAt: ago(10)
			},
			{
				id: "exp_4",
				ref: "EXP-000004",
				name: "Fuel · Tsakane loop",
				category: "Transport",
				store: "Engen",
				price: 180,
				qty: 3,
				purchased: true,
				archived: false,
				deleted: false,
				notes: "",
				createdAt: ago(26)
			},
			{
				id: "exp_5",
				ref: "EXP-000005",
				name: "Bin liners heavy duty",
				category: "Consumables",
				store: "Makro",
				price: 45,
				qty: 8,
				purchased: false,
				archived: false,
				deleted: false,
				notes: "",
				createdAt: ago(8)
			}
		],
		documents: [
			{
				id: "doc_contract",
				ref: "DOC-EMP-01",
				name: "Employment contract · residential cleaner",
				category: "Contracts",
				status: "Active",
				version: "1.0",
				summary: "Permanent or fixed-term professional residential cleaner. Three-month probation, extendable once. Work is at customer homes across Gauteng, not a fixed office. Complies with BCEA, LRA, OHSA and POPIA. Employer contact 061 467 9207 · info@terracelest.co.za.",
				deleted: false,
				createdAt: "2026-08-03T08:00:00.000Z"
			},
			{
				id: "doc_corp",
				ref: "DOC-CAP-01",
				name: "Corporate capability profile",
				category: "Business Documents",
				status: "Active",
				version: "1.0",
				summary: "Commercial, recurring, deep, post-construction, move-in/out and multi-site cleaning. Process: enquire, assess, propose, quote, schedule, deliver, continue. Focused on Ekurhuleni businesses.",
				deleted: false,
				createdAt: "2026-08-03T08:00:00.000Z"
			},
			{
				id: "doc_style",
				ref: "DOC-BRD-01",
				name: "Facilities design style guide",
				category: "Brand",
				status: "Active",
				version: "1.0",
				summary: "Teal #00A69C, navy #0B1D3A, aqua #35C1BC, Montserrat. Tagline: Clean spaces. Better places. Values: Empower, Innovate, Elevate.",
				deleted: false,
				createdAt: "2026-08-01T08:00:00.000Z"
			}
		],
		scripts: [
			{
				id: "scr_wa",
				ref: "SCR-000001",
				name: "Deposit reminder",
				type: "WhatsApp",
				audience: "Residential customer",
				status: "Active",
				body: "Sawubona {name}, this is TerraCelest Facilities. Your {service} is booked for {date} at {address}. The 40% deposit is {deposit}. Please pay so we can lock your team. Balance before cleaning is {before}. Clean spaces. Better places.",
				deleted: false,
				createdAt: "2026-08-01T08:00:00.000Z"
			},
			{
				id: "scr_call",
				ref: "SCR-000002",
				name: "Morning arrival call",
				type: "Call",
				audience: "Residential customer",
				status: "Active",
				body: "Good morning, this is {leader} from TerraCelest. We are on the way to {address} and should be with you shortly. The clean is planned for {hours} hours with {cleaners} people. Please have water access open.",
				deleted: false,
				createdAt: "2026-08-01T08:00:00.000Z"
			},
			{
				id: "scr_mail",
				ref: "SCR-000003",
				name: "Event proposal cover",
				type: "Email",
				audience: "Event organiser",
				status: "Active",
				body: "Thank you for the opportunity to support {event}. This proposal sets out how TerraCelest will keep the venue clean before doors, through the event, and after the last guest leaves. Guests should notice the standard of the venue, not the work behind it.",
				deleted: false,
				createdAt: "2026-09-22T08:00:00.000Z"
			}
		],
		equipment: [{
			id: "eq_dexter",
			ref: "EQ-000001",
			name: "Dexter Power 1400W wet & dry",
			spec: "20L stainless steel · 15 kPa · blower",
			status: "In Fleet",
			base: "Benoni",
			notes: "Added to the fleet for deep cleans and commercial work.",
			deleted: false,
			createdAt: ago(140)
		}, {
			id: "eq_mop",
			ref: "EQ-000002",
			name: "Commercial mop system",
			spec: "Dual bucket · microfibre pads",
			status: "In Fleet",
			base: "Tsakane",
			notes: "",
			deleted: false,
			createdAt: "2026-06-01T08:00:00.000Z"
		}],
		feed: [
			{
				id: "fd_cafe",
				title: "Quote sent · Cafe69 All White Affair",
				body: "R93,901.33 incl. VAT for 27 people at Kwa-Thema Stadium on 28 November 2026.",
				at: "2026-09-23T07:40:00.000Z",
				kind: "quote",
				read: false
			},
			{
				id: "fd_vac",
				title: "Fleet · Dexter 1400W wet & dry",
				body: "20L stainless, 15 kPa, blower function. Logged at the Benoni cage.",
				at: ago(140),
				kind: "fleet",
				read: false
			},
			{
				id: "fd_dep",
				title: "Deposit received · Lindiwe Mahlangu",
				body: "R300.00 EFT against today’s spring clean. Balance due R450.00.",
				at: ago(18),
				kind: "payment",
				read: true
			},
			{
				id: "fd_jabu",
				title: "Booking still unpaid · Jabulani Nkosi",
				body: "TC-SPR-0002 is pending. Do not dispatch until R300 deposit is in.",
				at: ago(30),
				kind: "booking",
				read: true
			},
			{
				id: "fd_john",
				title: "Job completed · John Doe",
				body: "TC-BKG-79790 finished. Contribution on the internal record is R71.25 (9.50%). Invoice still overdue.",
				at: "2026-08-11T17:00:00.000Z",
				kind: "booking",
				read: true
			}
		]
	};
}
function depositFor(bookingId, payments) {
	return round2(payments.filter((p) => !p.deleted && p.bookingId === bookingId).reduce((s, p) => s + p.amount, 0));
}
function active(rows) {
	return rows.filter((r) => !r.deleted);
}
var SESSION_MS = 288e5;
function pushFeed(feed, item) {
	return [{
		id: nid("fd"),
		at: (/* @__PURE__ */ new Date()).toISOString(),
		read: false,
		...item
	}, ...feed].slice(0, 40);
}
function upsert(rows, row) {
	const i = rows.findIndex((r) => r.id === row.id);
	if (i < 0) return [row, ...rows];
	const next = rows.slice();
	next[i] = row;
	return next;
}
var seeded = seedWorkspace();
var useTc = create()(persist((set, get) => ({
	...seeded,
	session: null,
	theme: "default",
	lang: "en",
	lastSync: Date.now(),
	login: (userId) => set({ session: {
		userId,
		expires: Date.now() + SESSION_MS
	} }),
	logout: () => set({ session: null }),
	setTheme: (theme) => set({ theme }),
	setLang: (lang) => set({ lang }),
	sync: () => set({ lastSync: Date.now() }),
	markFeedRead: () => set({ feed: get().feed.map((f) => ({
		...f,
		read: true
	})) }),
	resetDemo: () => {
		set({
			...seedWorkspace(),
			lastSync: Date.now()
		});
	},
	saveClient: (input) => {
		const id = input.id ?? nid("cli");
		const existing = get().clients.find((c) => c.id === id);
		const row = {
			id,
			ref: existing?.ref ?? nextRef("CLI", get().clients.map((c) => c.ref)),
			name: input.name.trim(),
			phone: input.phone.trim(),
			email: input.email.trim(),
			area: input.area.trim(),
			type: input.type,
			status: input.status,
			notes: input.notes.trim(),
			deleted: false,
			createdAt: existing?.createdAt ?? (/* @__PURE__ */ new Date()).toISOString()
		};
		set({
			clients: upsert(get().clients, row),
			feed: pushFeed(get().feed, {
				kind: "system",
				title: existing ? `Client updated · ${row.name}` : `Client added · ${row.name}`,
				body: `${row.ref} · ${row.area} · ${row.type}`
			})
		});
		return id;
	},
	saveProperty: (input) => {
		const id = input.id ?? nid("prop");
		const existing = get().properties.find((p) => p.id === id);
		const row = {
			...input,
			id,
			ref: existing?.ref ?? nextRef("PROP", get().properties.map((p) => p.ref)),
			name: input.name.trim(),
			address: input.address.trim(),
			notes: input.notes.trim(),
			deleted: false,
			createdAt: existing?.createdAt ?? (/* @__PURE__ */ new Date()).toISOString()
		};
		set({ properties: upsert(get().properties, row) });
		return id;
	},
	saveTeam: (input) => {
		const id = input.id ?? nid("emp");
		const existing = get().team.find((p) => p.id === id);
		const row = {
			...input,
			id,
			ref: existing?.ref ?? nextRef("EMP", get().team.map((p) => p.ref)),
			name: input.name.trim(),
			notes: input.notes.trim(),
			deleted: false,
			createdAt: existing?.createdAt ?? (/* @__PURE__ */ new Date()).toISOString()
		};
		set({
			team: upsert(get().team, row),
			feed: pushFeed(get().feed, {
				kind: "system",
				title: `${existing ? "Team updated" : "Team added"} · ${row.name}`,
				body: `${row.role} · ${row.base}`
			})
		});
		return id;
	},
	saveBooking: (draft, existingId) => {
		const id = existingId ?? nid("bkg");
		const existing = get().bookings.find((b) => b.id === id);
		const client = get().clients.find((c) => c.id === draft.clientId);
		const service = serviceById(draft.serviceId);
		const row = {
			...draft,
			id,
			ref: existing?.ref ?? nextRef("BK", get().bookings.map((b) => b.ref)),
			name: `${client?.name ?? "Client"} · ${service.name}`,
			notes: draft.notes.trim(),
			deleted: false,
			createdAt: existing?.createdAt ?? (/* @__PURE__ */ new Date()).toISOString()
		};
		const bookings = upsert(get().bookings, row);
		let invoices = get().invoices;
		if (!invoices.some((inv) => inv.bookingId === id && !inv.deleted)) invoices = [{
			id: nid("inv"),
			ref: nextRef("TC-INT", invoices.map((i) => i.ref)),
			bookingId: id,
			status: "Draft",
			notes: "Internal costing record. Not the customer-facing invoice.",
			deleted: false,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		}, ...invoices];
		const cost = costBooking(row, depositFor(id, get().payments));
		set({
			bookings,
			invoices,
			feed: pushFeed(get().feed, {
				kind: "booking",
				title: `${existing ? "Booking updated" : "Booking created"} · ${client?.name ?? row.ref}`,
				body: `${row.ref} · ${service.name} · ${row.serviceDate} · revenue ${cost.revenue.toFixed(2)}`
			})
		});
		return id;
	},
	setBookingStatus: (id, status) => {
		const row = get().bookings.find((b) => b.id === id);
		if (!row) return;
		set({
			bookings: get().bookings.map((b) => b.id === id ? {
				...b,
				status
			} : b),
			feed: pushFeed(get().feed, {
				kind: "booking",
				title: `${row.ref} · ${status}`,
				body: row.name
			})
		});
	},
	logPayment: (bookingId, amount, method) => {
		const booking = get().bookings.find((b) => b.id === bookingId);
		if (!booking || amount <= 0) return;
		const payments = [{
			id: nid("pay"),
			ref: nextRef("PAY", get().payments.map((p) => p.ref)),
			name: `${booking.ref} ${method}`,
			bookingId,
			amount: Math.round(amount * 100) / 100,
			method,
			paidAt: (/* @__PURE__ */ new Date()).toISOString(),
			deleted: false,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		}, ...get().payments];
		const cost = costBooking(booking, depositFor(bookingId, payments));
		set({
			payments,
			invoices: get().invoices.map((inv) => {
				if (inv.bookingId !== bookingId || inv.deleted) return inv;
				const status = cost.balanceDue <= 0 ? "Paid" : "Partially Paid";
				return {
					...inv,
					status
				};
			}),
			feed: pushFeed(get().feed, {
				kind: "payment",
				title: `Payment · ${booking.ref}`,
				body: `${method} R${amount.toFixed(2)}. Balance due R${cost.balanceDue.toFixed(2)}.`
			})
		});
	},
	setInvoiceStatus: (id, status) => set({ invoices: get().invoices.map((i) => i.id === id ? {
		...i,
		status
	} : i) }),
	saveQuote: (input) => {
		const id = input.id ?? nid("qt");
		const existing = get().quotes.find((q) => q.id === id);
		const row = {
			...input,
			id,
			ref: existing?.ref ?? nextRef("QT", get().quotes.map((q) => q.ref)),
			name: input.name.trim(),
			notes: input.notes.trim(),
			rich: existing?.rich ?? false,
			deleted: false,
			createdAt: existing?.createdAt ?? (/* @__PURE__ */ new Date()).toISOString()
		};
		set({
			quotes: upsert(get().quotes, row),
			feed: pushFeed(get().feed, {
				kind: "quote",
				title: `${existing ? "Quote updated" : "Quote drafted"} · ${row.name}`,
				body: row.ref
			})
		});
		return id;
	},
	setQuoteStatus: (id, status) => {
		const row = get().quotes.find((q) => q.id === id);
		if (!row) return;
		set({
			quotes: get().quotes.map((q) => q.id === id ? {
				...q,
				status
			} : q),
			feed: pushFeed(get().feed, {
				kind: "quote",
				title: `${row.name} · ${status}`,
				body: row.ref
			})
		});
	},
	saveTask: (input) => {
		const id = input.id ?? nid("tsk");
		const existing = get().tasks.find((t) => t.id === id);
		const row = {
			...input,
			id,
			ref: existing?.ref ?? nextRef("TSK", get().tasks.map((t) => t.ref)),
			name: input.name.trim(),
			notes: input.notes.trim(),
			deleted: false,
			createdAt: existing?.createdAt ?? (/* @__PURE__ */ new Date()).toISOString()
		};
		set({ tasks: upsert(get().tasks, row) });
		return id;
	},
	saveBudget: (input) => {
		const id = input.id ?? nid("exp");
		const existing = get().budget.find((b) => b.id === id);
		const row = {
			...input,
			id,
			ref: existing?.ref ?? nextRef("EXP", get().budget.map((b) => b.ref)),
			name: input.name.trim(),
			notes: input.notes.trim(),
			archived: existing?.archived ?? false,
			deleted: false,
			createdAt: existing?.createdAt ?? (/* @__PURE__ */ new Date()).toISOString()
		};
		set({ budget: upsert(get().budget, row) });
		return id;
	},
	archiveBudget: (id, archived) => set({ budget: get().budget.map((b) => b.id === id ? {
		...b,
		archived
	} : b) }),
	saveDoc: (input) => {
		const id = input.id ?? nid("doc");
		const existing = get().documents.find((d) => d.id === id);
		const row = {
			...input,
			id,
			ref: existing?.ref ?? nextRef("DOC", get().documents.map((d) => d.ref)),
			deleted: false,
			createdAt: existing?.createdAt ?? (/* @__PURE__ */ new Date()).toISOString()
		};
		set({ documents: upsert(get().documents, row) });
		return id;
	},
	saveScript: (input) => {
		const id = input.id ?? nid("scr");
		const existing = get().scripts.find((d) => d.id === id);
		const row = {
			...input,
			id,
			ref: existing?.ref ?? nextRef("SCR", get().scripts.map((d) => d.ref)),
			deleted: false,
			createdAt: existing?.createdAt ?? (/* @__PURE__ */ new Date()).toISOString()
		};
		set({ scripts: upsert(get().scripts, row) });
		return id;
	},
	saveEquipment: (input) => {
		const id = input.id ?? nid("eq");
		const existing = get().equipment.find((d) => d.id === id);
		const row = {
			...input,
			id,
			ref: existing?.ref ?? nextRef("EQ", get().equipment.map((d) => d.ref)),
			deleted: false,
			createdAt: existing?.createdAt ?? (/* @__PURE__ */ new Date()).toISOString()
		};
		set({
			equipment: upsert(get().equipment, row),
			feed: pushFeed(get().feed, {
				kind: "fleet",
				title: `Equipment · ${row.name}`,
				body: `${row.spec} · ${row.base}`
			})
		});
		return id;
	},
	softDelete: (table, id) => {
		const flag = (rows) => rows.map((row) => row.id === id ? {
			...row,
			deleted: true
		} : row);
		const s = get();
		switch (table) {
			case "clients":
				set({ clients: flag(s.clients) });
				break;
			case "properties":
				set({ properties: flag(s.properties) });
				break;
			case "team":
				set({ team: flag(s.team) });
				break;
			case "bookings":
				set({ bookings: flag(s.bookings) });
				break;
			case "invoices":
				set({ invoices: flag(s.invoices) });
				break;
			case "quotes":
				set({ quotes: flag(s.quotes) });
				break;
			case "payments":
				set({ payments: flag(s.payments) });
				break;
			case "tasks":
				set({ tasks: flag(s.tasks) });
				break;
			case "budget":
				set({ budget: flag(s.budget) });
				break;
			case "documents":
				set({ documents: flag(s.documents) });
				break;
			case "scripts":
				set({ scripts: flag(s.scripts) });
				break;
			case "equipment": set({ equipment: flag(s.equipment) });
		}
	},
	restore: (table, id) => {
		const flag = (rows) => rows.map((row) => row.id === id ? {
			...row,
			deleted: false
		} : row);
		const s = get();
		switch (table) {
			case "clients":
				set({ clients: flag(s.clients) });
				break;
			case "properties":
				set({ properties: flag(s.properties) });
				break;
			case "team":
				set({ team: flag(s.team) });
				break;
			case "bookings":
				set({ bookings: flag(s.bookings) });
				break;
			case "invoices":
				set({ invoices: flag(s.invoices) });
				break;
			case "quotes":
				set({ quotes: flag(s.quotes) });
				break;
			case "payments":
				set({ payments: flag(s.payments) });
				break;
			case "tasks":
				set({ tasks: flag(s.tasks) });
				break;
			case "budget":
				set({ budget: flag(s.budget) });
				break;
			case "documents":
				set({ documents: flag(s.documents) });
				break;
			case "scripts":
				set({ scripts: flag(s.scripts) });
				break;
			case "equipment": set({ equipment: flag(s.equipment) });
		}
	}
}), {
	name: "tc_facilities_v13",
	partialize: (s) => ({
		clients: s.clients,
		properties: s.properties,
		team: s.team,
		bookings: s.bookings,
		invoices: s.invoices,
		quotes: s.quotes,
		payments: s.payments,
		tasks: s.tasks,
		budget: s.budget,
		documents: s.documents,
		scripts: s.scripts,
		equipment: s.equipment,
		feed: s.feed,
		session: s.session,
		theme: s.theme,
		lang: s.lang,
		lastSync: s.lastSync
	})
}));
function liveSession(session) {
	if (!session) return null;
	if (session.expires < Date.now()) return null;
	return session;
}
function unreadCount(feed) {
	return feed.filter((f) => !f.read).length;
}
function openBookings(bookings) {
	return active(bookings).filter((b) => ![
		"Completed",
		"Cancelled",
		"No Show"
	].includes(b.status));
}
function Mark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: "/brand-mark.png",
		alt: "",
		className: `w-auto object-contain ${className ?? ""}`
	});
}
function Wordmark({ onNavy = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: `text-sm font-extrabold tracking-wide ${onNavy ? "text-on-navy" : "text-ink"}`,
		children: "TERRA CELEST"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs font-bold tracking-brand text-teal",
		children: "FACILITIES"
	})] });
}
function StatusPill({ status }) {
	const key = status.toLowerCase();
	const solid = [
		"paid",
		"completed",
		"active",
		"accepted",
		"done",
		"in fleet",
		"received"
	].includes(key);
	const strong = [
		"cancelled",
		"declined",
		"overdue",
		"unpaid",
		"no show",
		"terminated",
		"suspended"
	].includes(key);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `inline-flex items-center rounded-full px-2.5 py-1 text-xs font-bold ${solid ? "bg-teal text-on-teal" : strong ? "bg-navy text-on-navy" : "border border-line bg-paper text-ink"}`,
		children: status
	});
}
function Sheet({ title, onClose, children, footer }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 z-40 flex flex-col justify-end bg-navy/45",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": title,
			className: "tc-rise flex max-h-[92%] flex-col rounded-t-3xl bg-paper shadow-xl",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-2 h-1 w-10 rounded-full bg-line" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-extrabold tracking-tight text-ink",
						children: title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClose,
						"aria-label": "Close",
						className: "grid size-11 place-items-center rounded-full text-ink",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-h-0 flex-1 overflow-y-auto px-4 pb-4",
					children
				}),
				footer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-t border-line p-4 pb-nav",
					children: footer
				}) : null
			]
		})
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "mb-3 block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-xs font-bold tracking-wide text-muted uppercase",
			children: label
		}), children]
	});
}
var inputClass = "h-12 w-full rounded-2xl border border-line bg-canvas px-3 text-sm font-semibold text-ink outline-none focus:border-teal";
function PrimaryButton({ children, onClick, type = "button" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		onClick,
		className: "h-12 w-full rounded-2xl bg-teal text-base font-extrabold text-on-teal active:scale-[0.98]",
		children
	});
}
function GhostButton({ children, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: "h-12 w-full rounded-2xl border border-line bg-paper text-sm font-bold text-ink",
		children
	});
}
function RowCard({ title, meta, status, trailing, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "mb-2 flex w-full items-center gap-3 rounded-2xl border border-line bg-paper px-3 py-3 text-left active:bg-wash",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block truncate text-sm font-extrabold text-ink",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-0.5 block truncate text-xs font-medium text-muted",
				children: meta
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex shrink-0 flex-col items-end gap-1",
			children: [trailing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-extrabold text-ink tabular-nums",
				children: trailing
			}) : null, status ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status }) : null]
		})]
	});
}
function Empty({ title, action, onAction }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-3xl border border-dashed border-line bg-paper px-4 py-8 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-semibold text-muted",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: onAction,
			className: "mt-4 h-11 rounded-2xl bg-teal px-4 text-sm font-extrabold text-on-teal",
			children: action
		})]
	});
}
function SectionLabel({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		className: "mt-4 mb-2 text-xs font-extrabold tracking-widest text-teal uppercase",
		children
	});
}
function MoneyRow({ label, value, strong = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex items-center justify-between gap-3 border-b border-line py-2 text-sm ${strong ? "font-extrabold text-ink" : "font-semibold text-muted"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "shrink-0 tabular-nums",
			children: value
		})]
	});
}
var TABLE_META = {
	bookings: {
		label: "Bookings",
		group: "Operations",
		hint: "Jobs on the board"
	},
	tasks: {
		label: "Tasks",
		group: "Operations",
		hint: "What still needs a person"
	},
	quotes: {
		label: "Quotes",
		group: "Operations",
		hint: "Proposals and packages"
	},
	clients: {
		label: "Clients",
		group: "People",
		hint: "People and organisations"
	},
	properties: {
		label: "Properties",
		group: "People",
		hint: "Addresses we clean"
	},
	team: {
		label: "Team",
		group: "People",
		hint: "Cleaners and supervisors"
	},
	invoices: {
		label: "Internal invoices",
		group: "Finance",
		hint: "Costing, not the customer bill"
	},
	payments: {
		label: "Payments",
		group: "Finance",
		hint: "Deposits and balances"
	},
	budget: {
		label: "Budget",
		group: "Finance",
		hint: "Supplies and fuel"
	},
	documents: {
		label: "Documents",
		group: "Knowledge",
		hint: "Contracts and profiles"
	},
	scripts: {
		label: "Scripts",
		group: "Knowledge",
		hint: "WhatsApp, call, email"
	},
	equipment: {
		label: "Equipment",
		group: "Knowledge",
		hint: "Tools in the fleet"
	}
};
var GROUPS = [
	"Operations",
	"People",
	"Finance",
	"Knowledge"
];
var GROUP_ICON = {
	Operations: Calendar,
	People: Users,
	Finance: Wallet,
	Knowledge: FileText
};
function qhit(q, parts) {
	const n = q.trim().toLowerCase();
	if (!n) return true;
	return parts.join(" ").toLowerCase().includes(n);
}
function HomeScreen({ lang, query, onOpen, onDetail }) {
	const bookings = useTc((s) => s.bookings);
	const clients = useTc((s) => s.clients);
	const quotes = useTc((s) => s.quotes);
	const payments = useTc((s) => s.payments);
	const team = useTc((s) => s.team);
	const feed = useTc((s) => s.feed);
	const today = todayISO();
	const live = active(bookings);
	const open = openBookings(bookings);
	const collect = live.filter((b) => b.status !== "Cancelled").reduce((sum, b) => sum + costBooking(b, depositFor(b.id, payments)).balanceDue, 0);
	const onDuty = active(team).filter((m) => m.status === "Active").length;
	const todays = live.filter((b) => b.serviceDate === today);
	const clientName = (id) => clients.find((c) => c.id === id)?.name ?? "Client";
	const searching = query.trim().length > 0;
	const foundBookings = live.filter((b) => qhit(query, [
		b.name,
		b.ref,
		b.status,
		clientName(b.clientId)
	]));
	const foundClients = active(clients).filter((c) => qhit(query, [
		c.name,
		c.ref,
		c.area,
		c.phone
	]));
	const foundQuotes = active(quotes).filter((q) => qhit(query, [
		q.name,
		q.ref,
		q.venue,
		q.status
	]));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pb-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						n: String(open.length),
						label: "Open jobs"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						n: money(collect).replace(".00", ""),
						label: "Still to collect"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						n: String(onDuty),
						label: "On duty"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-3xl bg-navy px-4 py-4 text-on-navy",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-extrabold tracking-brand text-aqua",
						children: "SPRING SPECIAL"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xl font-extrabold",
						children: "R750 · up to 4 rooms"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-on-navy/80",
						children: "Kitchen, lounge, bathroom and bedroom. We bring the products."
					})
				]
			}),
			searching ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "Matches" }),
					foundBookings.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowCard, {
						title: clientName(b.clientId),
						meta: `${b.ref} · ${formatDay(b.serviceDate)}`,
						status: b.status,
						trailing: money(costBooking(b, depositFor(b.id, payments)).revenue),
						onClick: () => onDetail("bookings", b.id)
					}, b.id)),
					foundClients.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowCard, {
						title: c.name,
						meta: `${c.ref} · ${c.area}`,
						status: c.status,
						onClick: () => onDetail("clients", c.id)
					}, c.id)),
					foundQuotes.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowCard, {
						title: q.name,
						meta: q.ref,
						status: q.status,
						trailing: money(vatOf(q.exclVat).total),
						onClick: () => onDetail("quotes", q.id)
					}, q.id)),
					foundBookings.length + foundClients.length + foundQuotes.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-muted",
						children: "Nothing matches that search."
					}) : null
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex items-end justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-extrabold text-ink",
						children: lang === "af" ? "Vandag se rondte" : lang === "zu" ? "Umsebenzi wanamuhla" : "Today’s run"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-xs font-bold text-teal",
						onClick: () => onOpen("bookings"),
						children: "All bookings"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2",
					children: todays.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
						title: "No job is dated for today.",
						action: "Open bookings",
						onAction: () => onOpen("bookings")
					}) : todays.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingRow, {
						booking: b,
						onClick: () => onDetail("bookings", b.id)
					}, b.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "Contribution on the board" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-3xl border border-line bg-paper p-3",
					children: [open.slice(0, 4).map((b) => {
						const cost = costBooking(b, depositFor(b.id, payments));
						const width = Math.min(100, Math.max(8, Math.abs(cost.margin) * 100 * 4));
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onDetail("bookings", b.id),
							className: "mb-3 block w-full text-left last:mb-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center justify-between gap-2 text-xs font-bold text-ink",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate",
									children: clientName(b.clientId)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums",
									children: money(cost.contribution)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block h-2 overflow-hidden rounded-full bg-wash",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block h-full rounded-full bg-teal",
									style: { width: `${width}%` }
								})
							})]
						}, b.id);
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium text-muted",
						children: "Spring special at R750 with two cleaners for 4 hours lands near a 9.5% contribution after labour, products, transport and overhead."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: lang === "zu" ? "Okusanda kwenzeka" : lang === "af" ? "Onlangse aktiwiteit" : "Recent activity" }),
				feed.slice(0, 4).map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onOpen("bookings"),
					className: "mb-2 flex w-full gap-3 rounded-2xl border border-line bg-paper px-3 py-3 text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm font-extrabold text-ink",
							children: f.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-0.5 block text-xs font-medium text-muted",
							children: f.body
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 text-xs font-bold text-teal",
						children: timeAgo(f.at)
					})]
				}, f.id))
			] })
		]
	});
}
function Stat({ n, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl bg-navy px-2 py-3 text-on-navy",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "truncate text-sm font-extrabold tabular-nums",
			children: n
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 text-[11px] font-semibold text-aqua",
			children: label
		})]
	});
}
function BookingRow({ booking, onClick }) {
	const clients = useTc((s) => s.clients);
	const properties = useTc((s) => s.properties);
	const payments = useTc((s) => s.payments);
	const client = clients.find((c) => c.id === booking.clientId);
	const property = properties.find((p) => p.id === booking.propertyId);
	const cost = costBooking(booking, depositFor(booking.id, payments));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowCard, {
		title: client?.name ?? booking.name,
		meta: `${formatDay(booking.serviceDate)} · ${property?.area ?? ""} · ${serviceById(booking.serviceId).name}`,
		status: booking.status,
		trailing: money(cost.revenue),
		onClick
	});
}
function OfficeScreen({ lastTable, onOpen }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pb-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-3 text-sm font-medium text-muted",
			children: "Tables grouped the way the floor uses them. Last opened stays marked."
		}), GROUPS.map((group) => {
			const Icon = GROUP_ICON[group];
			const tables = Object.keys(TABLE_META).filter((id) => TABLE_META[id].group === group);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center gap-2 text-ink",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 text-teal" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-extrabold",
						children: group
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-2",
					children: tables.map((id) => {
						const meta = TABLE_META[id];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onOpen(id),
							className: `rounded-2xl border px-3 py-3 text-left ${lastTable === id ? "border-teal bg-wash" : "border-line bg-paper"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm font-extrabold text-ink",
								children: meta.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-xs font-medium text-muted",
								children: meta.hint
							})]
						}, id);
					})
				})]
			}, group);
		})]
	});
}
function UpdatesScreen() {
	const feed = useTc((s) => s.feed);
	if (feed.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
			title: "Activity will show as the team works.",
			action: "Back to home",
			onAction: () => void 0
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "px-4 pb-6",
		children: feed.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "mb-2 rounded-2xl border border-line bg-paper px-3 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-extrabold text-ink",
					children: f.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "shrink-0 text-xs font-bold text-teal",
					children: timeAgo(f.at)
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs font-medium leading-relaxed text-muted",
				children: f.body
			})]
		}, f.id))
	});
}
function TableScreen({ table, query, onDetail, onCreate }) {
	const [budgetMode, setBudgetMode] = (0, import_react.useState)("open");
	const [jobFilter, setJobFilter] = (0, import_react.useState)("all");
	const data = useTc();
	const meta = TABLE_META[table];
	const rows = (0, import_react.useMemo)(() => {
		if (table === "bookings") return active(data.bookings).filter((b) => {
			const cost = costBooking(b, depositFor(b.id, data.payments));
			if (jobFilter === "today") return b.serviceDate === todayISO();
			if (jobFilter === "open") return ![
				"Completed",
				"Cancelled",
				"No Show"
			].includes(b.status);
			if (jobFilter === "unpaid") return cost.balanceDue > 0 && b.status !== "Cancelled";
			return true;
		}).filter((b) => qhit(query, [
			b.name,
			b.ref,
			b.status,
			data.clients.find((c) => c.id === b.clientId)?.name
		])).sort((a, b) => b.serviceDate.localeCompare(a.serviceDate));
		if (table === "clients") return active(data.clients).filter((r) => qhit(query, [
			r.name,
			r.ref,
			r.area,
			r.phone,
			r.type
		]));
		if (table === "properties") return active(data.properties).filter((r) => qhit(query, [
			r.name,
			r.address,
			r.area,
			r.base
		]));
		if (table === "team") return active(data.team).filter((r) => qhit(query, [
			r.name,
			r.role,
			r.base,
			r.status
		]));
		if (table === "quotes") return active(data.quotes).filter((r) => qhit(query, [
			r.name,
			r.ref,
			r.venue,
			r.status
		]));
		if (table === "invoices") return active(data.invoices).filter((r) => qhit(query, [
			r.ref,
			r.status,
			r.notes
		]));
		if (table === "payments") return active(data.payments).filter((r) => qhit(query, [
			r.name,
			r.ref,
			r.method
		]));
		if (table === "tasks") return active(data.tasks).filter((r) => qhit(query, [
			r.name,
			r.status,
			r.owner
		]));
		if (table === "documents") return active(data.documents).filter((r) => qhit(query, [
			r.name,
			r.category,
			r.summary
		]));
		if (table === "scripts") return active(data.scripts).filter((r) => qhit(query, [
			r.name,
			r.type,
			r.body
		]));
		if (table === "equipment") return active(data.equipment).filter((r) => qhit(query, [
			r.name,
			r.spec,
			r.base
		]));
		return active(data.budget).filter((r) => (budgetMode === "archived" ? r.archived : !r.archived) && qhit(query, [
			r.name,
			r.category,
			r.store
		]));
	}, [
		table,
		query,
		data,
		budgetMode,
		jobFilter
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pb-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm font-medium text-muted",
				children: meta.hint
			}),
			table === "bookings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-3 flex gap-2 overflow-x-auto",
				children: [
					"all",
					"today",
					"open",
					"unpaid"
				].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setJobFilter(f),
					className: `h-9 shrink-0 rounded-full px-3 text-xs font-extrabold capitalize ${jobFilter === f ? "bg-teal text-on-teal" : "bg-paper text-ink border border-line"}`,
					children: f
				}, f))
			}) : null,
			table === "budget" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setBudgetMode("open"),
					className: `h-9 rounded-full px-3 text-xs font-extrabold ${budgetMode === "open" ? "bg-teal text-on-teal" : "border border-line bg-paper text-ink"}`,
					children: "Open"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setBudgetMode("archived"),
					className: `h-9 rounded-full px-3 text-xs font-extrabold ${budgetMode === "archived" ? "bg-teal text-on-teal" : "border border-line bg-paper text-ink"}`,
					children: "Archived"
				})]
			}) : null,
			rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				title: table === "budget" && budgetMode === "archived" ? "Nothing is archived." : `No ${meta.label.toLowerCase()} yet.`,
				action: `Add ${meta.label.replace(/s$/, "").toLowerCase()}`,
				onAction: onCreate
			}) : rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, {
				table,
				id: row.id,
				onClick: () => onDetail(row.id)
			}, row.id))
		]
	});
}
function TableRow({ table, id, onClick }) {
	const s = useTc();
	if (table === "bookings") {
		const b = s.bookings.find((r) => r.id === id);
		if (!b) return null;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingRow, {
			booking: b,
			onClick
		});
	}
	if (table === "clients") {
		const r = s.clients.find((x) => x.id === id);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowCard, {
			title: r.name,
			meta: `${r.type} · ${r.area} · ${r.phone}`,
			status: r.status,
			onClick
		});
	}
	if (table === "properties") {
		const r = s.properties.find((x) => x.id === id);
		const client = s.clients.find((c) => c.id === r.clientId);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowCard, {
			title: r.name,
			meta: `${client?.name ?? "Client"} · ${r.base} base · ${r.zone}`,
			onClick
		});
	}
	if (table === "team") {
		const r = s.team.find((x) => x.id === id);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowCard, {
			title: r.name,
			meta: `${r.role} · ${r.base}`,
			status: r.status,
			onClick
		});
	}
	if (table === "quotes") {
		const r = s.quotes.find((x) => x.id === id);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowCard, {
			title: r.name,
			meta: `${r.ref} · ${r.venue}`,
			status: r.status,
			trailing: money(vatOf(r.exclVat).total),
			onClick
		});
	}
	if (table === "invoices") {
		const r = s.invoices.find((x) => x.id === id);
		const b = s.bookings.find((x) => x.id === r.bookingId);
		const cost = b ? costBooking(b, depositFor(b.id, s.payments)) : null;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowCard, {
			title: r.ref,
			meta: b?.name ?? "Booking",
			status: cost && cost.balanceDue > 0 && r.status !== "Paid" ? r.status : r.status,
			trailing: cost ? money(cost.balanceDue) : "",
			onClick
		});
	}
	if (table === "payments") {
		const r = s.payments.find((x) => x.id === id);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowCard, {
			title: r.name,
			meta: `${r.method} · ${formatWhen(r.paidAt)}`,
			trailing: money(r.amount),
			status: "Received",
			onClick
		});
	}
	if (table === "tasks") {
		const r = s.tasks.find((x) => x.id === id);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowCard, {
			title: r.name,
			meta: `${r.owner} · due ${formatDay(r.due)}`,
			status: r.status,
			onClick
		});
	}
	if (table === "documents") {
		const r = s.documents.find((x) => x.id === id);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowCard, {
			title: r.name,
			meta: `${r.category} · ${r.version}`,
			status: r.status,
			onClick
		});
	}
	if (table === "scripts") {
		const r = s.scripts.find((x) => x.id === id);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowCard, {
			title: r.name,
			meta: `${r.type} · ${r.audience}`,
			status: r.status,
			onClick
		});
	}
	if (table === "equipment") {
		const r = s.equipment.find((x) => x.id === id);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowCard, {
			title: r.name,
			meta: `${r.spec} · ${r.base}`,
			status: r.status,
			onClick
		});
	}
	const r = s.budget.find((x) => x.id === id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowCard, {
		title: r.name,
		meta: `${r.category} · ${r.store} · qty ${r.qty}`,
		trailing: money(r.price * r.qty),
		status: r.purchased ? "Paid" : "Pending",
		onClick
	});
}
var BOOKING_FLOW = [
	"Draft",
	"Pending",
	"Confirmed",
	"Assigned",
	"In Progress",
	"Completed",
	"Cancelled",
	"No Show"
];
function DetailBody({ table, id, onEdit, onDelete, onPay }) {
	const s = useTc();
	if (table === "bookings") {
		const b = s.bookings.find((r) => r.id === id);
		if (!b) return null;
		const client = s.clients.find((c) => c.id === b.clientId);
		const property = s.properties.find((p) => p.id === b.propertyId);
		costBooking(b, depositFor(b.id, s.payments));
		const invoice = s.invoices.find((i) => i.bookingId === b.id && !i.deleted);
		const crew = s.team.filter((m) => b.teamIds.includes(m.id));
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-bold text-teal",
						children: b.ref
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-xl font-extrabold text-ink",
						children: client?.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-muted",
						children: serviceById(b.serviceId).name
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: b.status })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm font-semibold text-ink",
				children: property?.address
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs font-medium text-muted",
				children: [
					formatDay(b.serviceDate),
					" · ",
					property?.base,
					" base · ",
					property?.zone,
					" zone · ",
					b.cleaners,
					" cleaners · ",
					b.hours,
					" hrs"
				]
			}),
			client?.phone ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: `tel:${client.phone.replace(/\s/g, "")}`,
				className: "mt-3 inline-flex h-11 items-center gap-2 rounded-2xl bg-wash px-3 text-sm font-extrabold text-teal",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" }),
					" Call ",
					client.phone
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					onClick: onPay,
					children: "Log payment"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
					onClick: onEdit,
					children: "Edit job"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "Team" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold text-ink",
				children: crew.length ? crew.map((m) => m.name).join(", ") : "Not assigned yet"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CostBlock, { booking: b }),
			invoice ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-xs font-bold text-muted",
				children: [
					"Internal record ",
					invoice.ref,
					" · ",
					invoice.status
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "Move the job" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: BOOKING_FLOW.map((st) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => s.setBookingStatus(b.id, st),
					className: `h-9 rounded-full px-3 text-xs font-extrabold ${b.status === st ? "bg-navy text-on-navy" : "border border-line bg-paper text-ink"}`,
					children: st
				}, st))
			}),
			b.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed text-muted",
				children: b.notes
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "mt-3 h-11 w-full text-sm font-bold text-muted",
				onClick: () => onDelete(client?.name ?? b.ref),
				children: ["Delete ", client?.name]
			})
		] });
	}
	if (table === "invoices") {
		const inv = s.invoices.find((r) => r.id === id);
		const b = inv ? s.bookings.find((x) => x.id === inv.bookingId) : void 0;
		if (!inv || !b) return null;
		const client = s.clients.find((c) => c.id === b.clientId);
		const property = s.properties.find((p) => p.id === b.propertyId);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-extrabold tracking-widest text-teal",
				children: "INTERNAL INVOICE"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-xl font-extrabold text-ink",
				children: inv.ref
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-muted",
				children: "Costing record · not the customer invoice"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
						k: "Customer",
						v: client?.name ?? "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
						k: "Booking",
						v: b.ref
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
						k: "Service date",
						v: formatDay(b.serviceDate)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
						k: "Area",
						v: property?.area ?? "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
						k: "Address",
						v: property?.address ?? "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
						k: "Base",
						v: property?.base ?? "—"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CostBlock, { booking: b }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs leading-relaxed text-muted",
				children: inv.notes
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: [
					"Draft",
					"Sent",
					"Partially Paid",
					"Paid",
					"Overdue",
					"Cancelled"
				].map((st) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => s.setInvoiceStatus(inv.id, st),
					className: `h-9 rounded-full px-3 text-xs font-extrabold ${inv.status === st ? "bg-teal text-on-teal" : "border border-line"}`,
					children: st
				}, st))
			})
		] });
	}
	if (table === "quotes") {
		const q = s.quotes.find((r) => r.id === id);
		if (!q) return null;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteDetail, {
			quote: q,
			onEdit,
			onDelete: () => onDelete(q.name)
		});
	}
	if (table === "scripts") {
		const r = s.scripts.find((x) => x.id === id);
		if (!r) return null;
		const sample = fillScript(r.body);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: r.type }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-2 text-xl font-extrabold text-ink",
				children: r.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: r.audience
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "mt-3 whitespace-pre-wrap rounded-2xl bg-wash p-3 font-sans text-sm leading-relaxed text-ink",
				children: sample
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					onClick: () => {
						navigator.clipboard.writeText(sample).then(() => toast.success("Script copied"));
					},
					children: "Copy"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
					onClick: onEdit,
					children: "Edit"
				})]
			})
		] });
	}
	const simple = simpleDetail(table, id, s);
	if (!simple) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-xl font-extrabold text-ink",
				children: simple.title
			}), simple.status ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: simple.status }) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-bold text-teal",
			children: simple.ref
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3",
			children: simple.lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-b border-line py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs font-bold tracking-wide text-muted uppercase",
					children: line.k
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-sm font-semibold text-ink",
					children: line.v
				})]
			}, line.k))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid grid-cols-2 gap-2",
			children: [table === "budget" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
				onClick: () => {
					const row = s.budget.find((b) => b.id === id);
					if (!row) return;
					s.archiveBudget(id, !row.archived);
					toast(row.archived ? "Restored to the open list" : "Archived", { action: {
						label: "Undo",
						onClick: () => s.archiveBudget(id, row.archived)
					} });
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center justify-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { className: "size-4" }),
						" ",
						s.budget.find((b) => b.id === id)?.archived ? "Restore" : "Archive"
					]
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
				onClick: onEdit,
				children: "Edit"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
				onClick: () => onDelete(simple.title),
				children: "Delete"
			})]
		}),
		table === "budget" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
				onClick: onEdit,
				children: "Edit line"
			})
		}) : null
	] });
}
function Info({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl bg-canvas px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[11px] font-bold tracking-wide text-muted uppercase",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm font-bold text-ink",
			children: v
		})]
	});
}
function CostBlock({ booking }) {
	const payments = useTc((s) => s.payments);
	const c = costBooking(booking, depositFor(booking.id, payments));
	const below = c.contribution < 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 rounded-3xl border border-line bg-canvas p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "Revenue" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyRow, {
				label: serviceById(booking.serviceId).name,
				value: money(booking.serviceAmount)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyRow, {
				label: `Additional rooms (${booking.extraRooms} × R80)`,
				value: money(booking.extraRooms * 80)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyRow, {
				label: "Additional services",
				value: money(booking.extraServices)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyRow, {
				label: "Logistics / travel",
				value: money(booking.travelCharge)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyRow, {
				label: "Discounts",
				value: money(-booking.discount)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyRow, {
				label: "Customer invoice total",
				value: money(c.revenue),
				strong: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "Payment position" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyRow, {
				label: "Required deposit — 40%",
				value: money(c.depositRequired)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyRow, {
				label: "Deposit received",
				value: money(c.depositReceived)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyRow, {
				label: "Balance due",
				value: money(c.balanceDue),
				strong: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyRow, {
				label: "Balance before cleaning",
				value: money(c.balanceBeforeCleaning)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "Internal delivery cost" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyRow, {
				label: `Labour · ${c.labourHours} hrs × R45`,
				value: money(c.labour)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyRow, {
				label: "Cleaning products",
				value: money(c.products)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyRow, {
				label: "Equipment",
				value: money(c.equipment)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyRow, {
				label: "Transport",
				value: money(c.transport)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyRow, {
				label: "Payment processing · 2.5%",
				value: money(c.processing)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyRow, {
				label: "Customer acquisition",
				value: money(c.acquisition)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyRow, {
				label: "Administration",
				value: money(c.admin)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyRow, {
				label: "Risk / contingency",
				value: money(c.risk)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyRow, {
				label: "Total delivery cost",
				value: money(c.delivery),
				strong: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `mt-2 rounded-2xl px-3 py-2 ${below ? "bg-paper" : "bg-wash"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyRow, {
						label: "Estimated contribution",
						value: money(c.contribution),
						strong: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyRow, {
						label: "Contribution margin",
						value: `${(c.margin * 100).toFixed(2)}%`,
						strong: true
					}),
					below ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pb-2 text-xs font-bold text-ink",
						children: "Below cost. Reprice or cut the overhead before you confirm."
					}) : null
				]
			})
		]
	});
}
function QuoteDetail({ quote, onEdit, onDelete }) {
	const setQuoteStatus = useTc((s) => s.setQuoteStatus);
	const client = useTc((s) => s.clients.find((c) => c.id === quote.clientId));
	const totals = vatOf(quote.exclVat);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-extrabold tracking-widest text-teal",
			children: quote.ref
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "text-xl font-extrabold text-ink",
			children: quote.name
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm text-muted",
			children: [
				"Prepared for ",
				client?.name,
				" · ",
				formatDay(quote.proposalDate)
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 rounded-3xl bg-navy p-4 text-on-navy",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-bold text-aqua",
					children: "Your event"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm font-semibold",
					children: formatDay(quote.eventDate)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-lg font-extrabold",
					children: quote.venue
				}),
				quote.people ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-3xl font-extrabold text-aqua",
					children: [quote.people, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-2 text-sm font-bold text-on-navy",
						children: "people"
					})]
				}) : null,
				quote.dayShift ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-xs font-semibold",
					children: ["Day · ", quote.dayShift]
				}) : null,
				quote.eveningShift ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs font-semibold",
					children: ["Evening · ", quote.eveningShift]
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 rounded-3xl bg-teal px-4 py-3 text-on-teal",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between text-sm font-semibold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Excl. VAT" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: money(quote.exclVat) })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between text-sm font-semibold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "VAT 15%" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: money(totals.vat) })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1 flex justify-between text-base font-extrabold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total quotation" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: money(totals.total) })]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 space-y-1",
			children: quote.scope.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "text-sm font-medium text-ink",
				children: ["• ", item]
			}, item))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm leading-relaxed text-muted",
			children: quote.notes
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 flex flex-wrap gap-2",
			children: [
				"Draft",
				"Sent",
				"Accepted",
				"Declined",
				"Expired"
			].map((st) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setQuoteStatus(quote.id, st),
				className: `h-9 rounded-full px-3 text-xs font-extrabold ${quote.status === st ? "bg-navy text-on-navy" : "border border-line"}`,
				children: st
			}, st))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid grid-cols-2 gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
				onClick: onEdit,
				children: "Edit"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
				onClick: onDelete,
				children: "Delete"
			})]
		})
	] });
}
function fillScript(body) {
	return body.replaceAll("{name}", "Jabulani").replaceAll("{service}", "Spring Cleaning Special").replaceAll("{date}", "16 August 2026").replaceAll("{address}", "1159 Sindane Street, Vosloorus").replaceAll("{deposit}", "R300.00").replaceAll("{before}", "R450.00").replaceAll("{leader}", "Thandi").replaceAll("{hours}", "4").replaceAll("{cleaners}", "2").replaceAll("{event}", "Cafe69 All White Affair");
}
function simpleDetail(table, id, s) {
	if (table === "clients") {
		const r = s.clients.find((x) => x.id === id);
		if (!r) return null;
		return {
			title: r.name,
			ref: r.ref,
			status: r.status,
			lines: [
				{
					k: "Phone",
					v: r.phone || "—"
				},
				{
					k: "Email",
					v: r.email || "—"
				},
				{
					k: "Area",
					v: r.area
				},
				{
					k: "Type",
					v: r.type
				},
				{
					k: "Notes",
					v: r.notes || "—"
				}
			]
		};
	}
	if (table === "properties") {
		const r = s.properties.find((x) => x.id === id);
		if (!r) return null;
		const client = s.clients.find((c) => c.id === r.clientId);
		return {
			title: r.name,
			ref: r.ref,
			status: r.zone,
			lines: [
				{
					k: "Client",
					v: client?.name ?? "—"
				},
				{
					k: "Address",
					v: r.address
				},
				{
					k: "Area",
					v: r.area
				},
				{
					k: "Operational base",
					v: r.base
				},
				{
					k: "Notes",
					v: r.notes || "—"
				}
			]
		};
	}
	if (table === "team") {
		const r = s.team.find((x) => x.id === id);
		if (!r) return null;
		return {
			title: r.name,
			ref: r.ref,
			status: r.status,
			lines: [
				{
					k: "Role",
					v: r.role
				},
				{
					k: "Phone",
					v: r.phone
				},
				{
					k: "Base",
					v: r.base
				},
				{
					k: "Notes",
					v: r.notes || "—"
				}
			]
		};
	}
	if (table === "payments") {
		const r = s.payments.find((x) => x.id === id);
		if (!r) return null;
		const b = s.bookings.find((x) => x.id === r.bookingId);
		return {
			title: r.name,
			ref: r.ref,
			status: "Received",
			lines: [
				{
					k: "Booking",
					v: b?.ref ?? "—"
				},
				{
					k: "Amount",
					v: money(r.amount)
				},
				{
					k: "Method",
					v: r.method
				},
				{
					k: "When",
					v: formatWhen(r.paidAt)
				}
			]
		};
	}
	if (table === "tasks") {
		const r = s.tasks.find((x) => x.id === id);
		if (!r) return null;
		return {
			title: r.name,
			ref: r.ref,
			status: r.status,
			lines: [
				{
					k: "Owner",
					v: r.owner
				},
				{
					k: "Due",
					v: formatDay(r.due)
				},
				{
					k: "Notes",
					v: r.notes || "—"
				}
			]
		};
	}
	if (table === "documents") {
		const r = s.documents.find((x) => x.id === id);
		if (!r) return null;
		return {
			title: r.name,
			ref: r.ref,
			status: r.status,
			lines: [
				{
					k: "Category",
					v: r.category
				},
				{
					k: "Version",
					v: r.version
				},
				{
					k: "Summary",
					v: r.summary
				}
			]
		};
	}
	if (table === "equipment") {
		const r = s.equipment.find((x) => x.id === id);
		if (!r) return null;
		return {
			title: r.name,
			ref: r.ref,
			status: r.status,
			lines: [
				{
					k: "Spec",
					v: r.spec
				},
				{
					k: "Base",
					v: r.base
				},
				{
					k: "Notes",
					v: r.notes || "—"
				}
			]
		};
	}
	if (table === "budget") {
		const r = s.budget.find((x) => x.id === id);
		if (!r) return null;
		return {
			title: r.name,
			ref: r.ref,
			status: r.purchased ? "Paid" : "Pending",
			lines: [
				{
					k: "Category",
					v: r.category
				},
				{
					k: "Store",
					v: r.store
				},
				{
					k: "Price",
					v: money(r.price)
				},
				{
					k: "Qty",
					v: String(r.qty)
				},
				{
					k: "Line total",
					v: money(r.price * r.qty)
				},
				{
					k: "Notes",
					v: r.notes || "—"
				}
			]
		};
	}
	return null;
}
function FormBody({ table, id, onDone }) {
	if (table === "bookings") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingForm, {
		id,
		onDone
	});
	if (table === "clients") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClientForm, {
		id,
		onDone
	});
	if (table === "properties") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PropertyForm, {
		id,
		onDone
	});
	if (table === "team") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamForm, {
		id,
		onDone
	});
	if (table === "quotes") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteForm, {
		id,
		onDone
	});
	if (table === "tasks") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskForm, {
		id,
		onDone
	});
	if (table === "budget") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BudgetForm, {
		id,
		onDone
	});
	if (table === "documents") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocForm, {
		id,
		onDone
	});
	if (table === "scripts") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScriptForm, {
		id,
		onDone
	});
	if (table === "equipment") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EquipForm, {
		id,
		onDone
	});
	if (table === "payments" || table === "invoices") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm font-semibold leading-relaxed text-muted",
		children: "Payments and internal invoices follow the booking. Open a job and log the deposit there — the costing record updates itself."
	});
}
function BookingForm({ id, onDone }) {
	const existing = useTc((s) => s.bookings.find((b) => b.id === id));
	const clients = useTc((s) => active(s.clients));
	const properties = useTc((s) => active(s.properties));
	const team = useTc((s) => active(s.team));
	const saveBooking = useTc((s) => s.saveBooking);
	const saveClient = useTc((s) => s.saveClient);
	const saveProperty = useTc((s) => s.saveProperty);
	const svc = serviceById(existing?.serviceId ?? "spring");
	const [clientId, setClientId] = (0, import_react.useState)(existing?.clientId ?? clients[0]?.id ?? "");
	const [fresh, setFresh] = (0, import_react.useState)(false);
	const [freshName, setFreshName] = (0, import_react.useState)("");
	const [freshPhone, setFreshPhone] = (0, import_react.useState)("");
	const [freshArea, setFreshArea] = (0, import_react.useState)("");
	const [propertyId, setPropertyId] = (0, import_react.useState)(existing?.propertyId ?? "");
	const [address, setAddress] = (0, import_react.useState)("");
	const [base, setBase] = (0, import_react.useState)("Tsakane");
	const [serviceId, setServiceId] = (0, import_react.useState)(existing?.serviceId ?? "spring");
	const [serviceDate, setServiceDate] = (0, import_react.useState)(existing?.serviceDate ?? todayISO());
	const [cleaners, setCleaners] = (0, import_react.useState)(existing?.cleaners ?? svc.cleaners);
	const [hours, setHours] = (0, import_react.useState)(existing?.hours ?? svc.hours);
	const [serviceAmount, setServiceAmount] = (0, import_react.useState)(existing?.serviceAmount ?? svc.price);
	const [extraRooms, setExtraRooms] = (0, import_react.useState)(existing?.extraRooms ?? 0);
	const [extraServices, setExtraServices] = (0, import_react.useState)(existing?.extraServices ?? 0);
	const [travelCharge, setTravelCharge] = (0, import_react.useState)(existing?.travelCharge ?? 0);
	const [discount, setDiscount] = (0, import_react.useState)(existing?.discount ?? 0);
	const [teamIds, setTeamIds] = (0, import_react.useState)(existing?.teamIds ?? []);
	const [notes, setNotes] = (0, import_react.useState)(existing?.notes ?? "");
	const draftPreview = {
		clientId: clientId || "pending",
		propertyId: propertyId || "pending",
		serviceId,
		serviceDate,
		status: existing?.status ?? "Pending",
		cleaners,
		hours,
		serviceAmount,
		extraRooms,
		extraServices,
		travelCharge,
		discount,
		products: existing?.products ?? 85,
		equipment: existing?.equipment ?? 25,
		transport: existing?.transport ?? 90,
		acquisition: existing?.acquisition ?? 50,
		admin: existing?.admin ?? 25,
		risk: existing?.risk ?? 25,
		teamIds,
		notes
	};
	const preview = costBooking(draftPreview, 0);
	const props = properties.filter((p) => p.clientId === clientId);
	function applyService(nextId) {
		const next = serviceById(nextId);
		setServiceId(nextId);
		setCleaners(next.cleaners);
		setHours(next.hours);
		setServiceAmount(next.price);
	}
	function save() {
		let cid = clientId;
		let pid = propertyId;
		if (fresh) {
			if (!freshName.trim() || !freshPhone.trim()) {
				toast.error("Add the client name and phone.");
				return;
			}
			cid = saveClient({
				name: freshName,
				phone: freshPhone,
				email: "",
				area: freshArea || "Ekurhuleni",
				type: "Residential",
				status: "Active",
				notes: ""
			});
			pid = saveProperty({
				name: address.trim() || freshName,
				clientId: cid,
				address: address.trim() || freshArea || "Address to confirm",
				area: freshArea || "Ekurhuleni",
				base,
				zone: "Inner",
				notes: ""
			});
		} else if (!cid) {
			toast.error("Choose a client.");
			return;
		} else if (!pid) {
			if (!address.trim()) {
				toast.error("Choose a property or type the address.");
				return;
			}
			const client = clients.find((c) => c.id === cid);
			pid = saveProperty({
				name: address.trim(),
				clientId: cid,
				address: address.trim(),
				area: client?.area ?? freshArea,
				base,
				zone: "Inner",
				notes: ""
			});
		}
		saveBooking({
			...draftPreview,
			clientId: cid,
			propertyId: pid
		}, existing?.id);
		toast.success(existing ? "Booking updated" : "Booking saved to the board");
		onDone();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setFresh(false),
				className: `h-10 flex-1 rounded-2xl text-xs font-extrabold ${!fresh ? "bg-navy text-on-navy" : "border border-line"}`,
				children: "Existing client"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setFresh(true),
				className: `h-10 flex-1 rounded-2xl text-xs font-extrabold ${fresh ? "bg-navy text-on-navy" : "border border-line"}`,
				children: "New client"
			})]
		}),
		fresh ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Client name",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: freshName,
					onChange: (e) => setFreshName(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Phone",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: freshPhone,
					onChange: (e) => setFreshPhone(e.target.value),
					inputMode: "tel"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Area",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: freshArea,
					onChange: (e) => setFreshArea(e.target.value),
					placeholder: "KwaThema, Tsakane, Vosloorus…"
				})
			})
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Client",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-2",
				children: clients.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						setClientId(c.id);
						setPropertyId("");
					},
					className: `h-11 rounded-2xl px-3 text-left text-sm font-bold ${clientId === c.id ? "bg-wash text-ink ring-1 ring-teal" : "border border-line"}`,
					children: [
						c.name,
						" · ",
						c.area
					]
				}, c.id))
			})
		}),
		!fresh && props.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Property",
			children: props.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setPropertyId(p.id),
				className: `mb-2 h-11 w-full rounded-2xl px-3 text-left text-sm font-bold ${propertyId === p.id ? "bg-wash ring-1 ring-teal" : "border border-line"}`,
				children: p.address
			}, p.id))
		}) : null,
		fresh || !propertyId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Service address",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: inputClass,
				value: address,
				onChange: (e) => setAddress(e.target.value)
			})
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Operational base",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [
					"Tsakane",
					"Benoni",
					"Daveyton"
				].map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setBase(b),
					className: `h-11 rounded-2xl text-xs font-extrabold ${base === b ? "bg-teal text-on-teal" : "border border-line"}`,
					children: b
				}, b))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Service",
			children: SERVICES.map((sv) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => applyService(sv.id),
				className: `mb-2 flex w-full items-center justify-between rounded-2xl px-3 py-3 text-left ${serviceId === sv.id ? "bg-wash ring-1 ring-teal" : "border border-line"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-extrabold",
					children: sv.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-extrabold tabular-nums",
					children: money(sv.price)
				})]
			}, sv.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Service date",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "date",
				className: inputClass,
				value: serviceDate,
				onChange: (e) => setServiceDate(e.target.value)
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Cleaners",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						min: 1,
						className: inputClass,
						value: cleaners,
						onChange: (e) => setCleaners(Number(e.target.value) || 1)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Hours each",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						min: 1,
						className: inputClass,
						value: hours,
						onChange: (e) => setHours(Number(e.target.value) || 1)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Service amount",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						className: inputClass,
						value: serviceAmount,
						onChange: (e) => setServiceAmount(Number(e.target.value) || 0)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Extra rooms",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						min: 0,
						className: inputClass,
						value: extraRooms,
						onChange: (e) => setExtraRooms(Number(e.target.value) || 0)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Extra services",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						className: inputClass,
						value: extraServices,
						onChange: (e) => setExtraServices(Number(e.target.value) || 0)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Travel charge",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						className: inputClass,
						value: travelCharge,
						onChange: (e) => setTravelCharge(Number(e.target.value) || 0)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Discount",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						className: inputClass,
						value: discount,
						onChange: (e) => setDiscount(Number(e.target.value) || 0)
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Assign team",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: team.map((m) => {
					const on = teamIds.includes(m.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setTeamIds(on ? teamIds.filter((x) => x !== m.id) : [...teamIds, m.id]),
						className: `h-10 rounded-full px-3 text-xs font-extrabold ${on ? "bg-navy text-on-navy" : "border border-line"} ${m.status !== "Active" ? "opacity-50" : ""}`,
						children: m.name.split(" ")[0]
					}, m.id);
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Notes",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				className: `${inputClass} h-24 py-3`,
				value: notes,
				onChange: (e) => setNotes(e.target.value)
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 rounded-2xl bg-navy px-3 py-3 text-on-navy",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between text-sm font-bold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Invoice total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: money(preview.revenue) })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Delivery cost" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: money(preview.delivery) })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between text-sm font-extrabold text-aqua",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Contribution" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						money(preview.contribution),
						" · ",
						(preview.margin * 100).toFixed(1),
						"%"
					] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-xs",
					children: [
						"Deposit to lock the team: ",
						money(preview.depositRequired),
						". Balance before cleaning: ",
						money(preview.balanceBeforeCleaning),
						"."
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
			onClick: save,
			children: existing ? "Save booking" : "Commit booking"
		})
	] });
}
function ClientForm({ id, onDone }) {
	const existing = useTc((s) => s.clients.find((c) => c.id === id));
	const save = useTc((s) => s.saveClient);
	const [name, setName] = (0, import_react.useState)(existing?.name ?? "");
	const [phone, setPhone] = (0, import_react.useState)(existing?.phone ?? "");
	const [email, setEmail] = (0, import_react.useState)(existing?.email ?? "");
	const [area, setArea] = (0, import_react.useState)(existing?.area ?? "");
	const [type, setType] = (0, import_react.useState)(existing?.type ?? "Residential");
	const [status, setStatus] = (0, import_react.useState)(existing?.status ?? "Active");
	const [notes, setNotes] = (0, import_react.useState)(existing?.notes ?? "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			if (!name.trim()) return toast.error("Name is required.");
			save({
				id,
				name,
				phone,
				email,
				area,
				type,
				status,
				notes
			});
			toast.success("Client saved");
			onDone();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Name",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: name,
					onChange: (e) => setName(e.target.value),
					required: true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Phone",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: phone,
					onChange: (e) => setPhone(e.target.value),
					inputMode: "tel"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Email",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: email,
					onChange: (e) => setEmail(e.target.value),
					inputMode: "email"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Area",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: area,
					onChange: (e) => setArea(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "Type",
				value: type,
				options: [
					"Residential",
					"Corporate",
					"Event"
				],
				onChange: (v) => setType(v)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "Status",
				value: status,
				options: [
					"Active",
					"Lead",
					"Inactive",
					"Archived"
				],
				onChange: (v) => setStatus(v)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Notes",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: `${inputClass} h-24 py-3`,
					value: notes,
					onChange: (e) => setNotes(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
				type: "submit",
				children: "Save client"
			})
		]
	});
}
function PropertyForm({ id, onDone }) {
	const existing = useTc((s) => s.properties.find((p) => p.id === id));
	const clients = useTc((s) => active(s.clients));
	const save = useTc((s) => s.saveProperty);
	const [name, setName] = (0, import_react.useState)(existing?.name ?? "");
	const [clientId, setClientId] = (0, import_react.useState)(existing?.clientId ?? clients[0]?.id ?? "");
	const [address, setAddress] = (0, import_react.useState)(existing?.address ?? "");
	const [area, setArea] = (0, import_react.useState)(existing?.area ?? "");
	const [base, setBase] = (0, import_react.useState)(existing?.base ?? "Tsakane");
	const [zone, setZone] = (0, import_react.useState)(existing?.zone ?? "Inner");
	const [notes, setNotes] = (0, import_react.useState)(existing?.notes ?? "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			if (!name.trim() || !clientId) return toast.error("Name and client are required.");
			save({
				id,
				name,
				clientId,
				address,
				area,
				base,
				zone,
				notes
			});
			toast.success("Property saved");
			onDone();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Name",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: name,
					onChange: (e) => setName(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Client",
				children: clients.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setClientId(c.id),
					className: `mb-2 h-11 w-full rounded-2xl px-3 text-left text-sm font-bold ${clientId === c.id ? "bg-wash ring-1 ring-teal" : "border border-line"}`,
					children: c.name
				}, c.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Address",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: address,
					onChange: (e) => setAddress(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Area",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: area,
					onChange: (e) => setArea(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "Base",
				value: base,
				options: [
					"Tsakane",
					"Benoni",
					"Daveyton"
				],
				onChange: setBase
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Coverage zone",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: zone,
					onChange: (e) => setZone(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Notes",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: `${inputClass} h-20 py-3`,
					value: notes,
					onChange: (e) => setNotes(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
				type: "submit",
				children: "Save property"
			})
		]
	});
}
function TeamForm({ id, onDone }) {
	const existing = useTc((s) => s.team.find((t) => t.id === id));
	const save = useTc((s) => s.saveTeam);
	const [name, setName] = (0, import_react.useState)(existing?.name ?? "");
	const [role, setRole] = (0, import_react.useState)(existing?.role ?? "Professional Residential Cleaner");
	const [phone, setPhone] = (0, import_react.useState)(existing?.phone ?? "");
	const [base, setBase] = (0, import_react.useState)(existing?.base ?? "Tsakane");
	const [status, setStatus] = (0, import_react.useState)(existing?.status ?? "Probation");
	const [notes, setNotes] = (0, import_react.useState)(existing?.notes ?? "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			if (!name.trim()) return toast.error("Name is required.");
			save({
				id,
				name,
				role,
				phone,
				base,
				status,
				notes
			});
			toast.success("Team member saved");
			onDone();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Full name",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: name,
					onChange: (e) => setName(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Role",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: role,
					onChange: (e) => setRole(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Phone",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: phone,
					onChange: (e) => setPhone(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "Base",
				value: base,
				options: [
					"Tsakane",
					"Benoni",
					"Daveyton"
				],
				onChange: setBase
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "Status",
				value: status,
				options: [
					"Active",
					"On Leave",
					"Probation",
					"Suspended"
				],
				onChange: (v) => setStatus(v)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Notes",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: `${inputClass} h-20 py-3`,
					value: notes,
					onChange: (e) => setNotes(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
				type: "submit",
				children: "Save team member"
			})
		]
	});
}
function QuoteForm({ id, onDone }) {
	const existing = useTc((s) => s.quotes.find((q) => q.id === id));
	const clients = useTc((s) => active(s.clients));
	const save = useTc((s) => s.saveQuote);
	const [name, setName] = (0, import_react.useState)(existing?.name ?? "");
	const [clientId, setClientId] = (0, import_react.useState)(existing?.clientId ?? clients[0]?.id ?? "");
	const [venue, setVenue] = (0, import_react.useState)(existing?.venue ?? "");
	const [eventDate, setEventDate] = (0, import_react.useState)(existing?.eventDate ?? todayISO());
	const [exclVat, setExclVat] = (0, import_react.useState)(existing?.exclVat ?? 0);
	const [people, setPeople] = (0, import_react.useState)(existing?.people ?? 2);
	const [notes, setNotes] = (0, import_react.useState)(existing?.notes ?? "");
	const [scopeText, setScopeText] = (0, import_react.useState)((existing?.scope ?? [
		"Pre-clean",
		"Service delivery",
		"Handover"
	]).join("\n"));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			if (!name.trim() || !clientId) return toast.error("Name and client are required.");
			save({
				id,
				name,
				clientId,
				status: existing?.status ?? "Draft",
				venue,
				eventDate,
				proposalDate: existing?.proposalDate ?? todayISO(),
				exclVat: Number(exclVat) || 0,
				people: Number(people) || 0,
				dayShift: existing?.dayShift ?? "",
				eveningShift: existing?.eveningShift ?? "",
				scope: scopeText.split("\n").map((l) => l.trim()).filter(Boolean),
				notes
			});
			toast.success("Quote saved");
			onDone();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Quote name",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: name,
					onChange: (e) => setName(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Client",
				children: clients.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setClientId(c.id),
					className: `mb-2 h-11 w-full rounded-2xl px-3 text-left text-sm font-bold ${clientId === c.id ? "bg-wash ring-1 ring-teal" : "border border-line"}`,
					children: c.name
				}, c.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Venue",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: venue,
					onChange: (e) => setVenue(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Event or start date",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "date",
					className: inputClass,
					value: eventDate,
					onChange: (e) => setEventDate(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Amount excl. VAT",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "number",
					className: inputClass,
					value: exclVat,
					onChange: (e) => setExclVat(Number(e.target.value))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-3 text-sm font-bold text-ink",
				children: ["Incl. VAT ", money(vatOf(Number(exclVat) || 0).total)]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "People",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "number",
					className: inputClass,
					value: people,
					onChange: (e) => setPeople(Number(e.target.value))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Scope (one line each)",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: `${inputClass} h-28 py-3`,
					value: scopeText,
					onChange: (e) => setScopeText(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Notes",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: `${inputClass} h-20 py-3`,
					value: notes,
					onChange: (e) => setNotes(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
				type: "submit",
				children: "Save quote"
			})
		]
	});
}
function TaskForm({ id, onDone }) {
	const existing = useTc((s) => s.tasks.find((t) => t.id === id));
	const save = useTc((s) => s.saveTask);
	const session = liveSession(useTc((s) => s.session));
	const user = USERS.find((u) => u.id === session?.userId);
	const [name, setName] = (0, import_react.useState)(existing?.name ?? "");
	const [status, setStatus] = (0, import_react.useState)(existing?.status ?? "To Do");
	const [due, setDue] = (0, import_react.useState)(existing?.due ?? todayISO());
	const [owner, setOwner] = (0, import_react.useState)(existing?.owner ?? user?.name ?? "Miss Phindi");
	const [notes, setNotes] = (0, import_react.useState)(existing?.notes ?? "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			if (!name.trim()) return toast.error("Task name is required.");
			save({
				id,
				name,
				status,
				due,
				owner,
				notes
			});
			toast.success("Task saved");
			onDone();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Task",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: name,
					onChange: (e) => setName(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "Status",
				value: status,
				options: [
					"To Do",
					"In Progress",
					"Blocked",
					"Done",
					"Cancelled"
				],
				onChange: (v) => setStatus(v)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Due",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "date",
					className: inputClass,
					value: due,
					onChange: (e) => setDue(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Owner",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: owner,
					onChange: (e) => setOwner(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Notes",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: `${inputClass} h-20 py-3`,
					value: notes,
					onChange: (e) => setNotes(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
				type: "submit",
				children: "Save task"
			})
		]
	});
}
function BudgetForm({ id, onDone }) {
	const existing = useTc((s) => s.budget.find((b) => b.id === id));
	const save = useTc((s) => s.saveBudget);
	const [name, setName] = (0, import_react.useState)(existing?.name ?? "");
	const [category, setCategory] = (0, import_react.useState)(existing?.category ?? "Consumables");
	const [store, setStore] = (0, import_react.useState)(existing?.store ?? "");
	const [price, setPrice] = (0, import_react.useState)(existing?.price ?? 0);
	const [qty, setQty] = (0, import_react.useState)(existing?.qty ?? 1);
	const [purchased, setPurchased] = (0, import_react.useState)(existing?.purchased ?? false);
	const [notes, setNotes] = (0, import_react.useState)(existing?.notes ?? "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			if (!name.trim()) return toast.error("Name the line.");
			save({
				id,
				name,
				category,
				store,
				price: Number(price) || 0,
				qty: Number(qty) || 1,
				purchased,
				notes
			});
			toast.success("Budget line saved");
			onDone();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Item",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: name,
					onChange: (e) => setName(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "Category",
				value: category,
				options: [
					"Consumables",
					"Chemicals",
					"PPE",
					"Transport",
					"Equipment",
					"Other"
				],
				onChange: setCategory
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Store",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: store,
					onChange: (e) => setStore(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Price (R)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						className: inputClass,
						value: price,
						onChange: (e) => setPrice(Number(e.target.value))
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Qty",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						className: inputClass,
						value: qty,
						onChange: (e) => setQty(Number(e.target.value))
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-3 text-sm font-extrabold",
				children: ["Line total ", money((Number(price) || 0) * (Number(qty) || 0))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setPurchased((v) => !v),
				className: `mb-3 h-11 w-full rounded-2xl text-sm font-extrabold ${purchased ? "bg-teal text-on-teal" : "border border-line"}`,
				children: purchased ? "Marked purchased" : "Not purchased yet"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Notes",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: `${inputClass} h-20 py-3`,
					value: notes,
					onChange: (e) => setNotes(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
				type: "submit",
				children: "Save line"
			})
		]
	});
}
function DocForm({ id, onDone }) {
	const existing = useTc((s) => s.documents.find((d) => d.id === id));
	const save = useTc((s) => s.saveDoc);
	const [name, setName] = (0, import_react.useState)(existing?.name ?? "");
	const [category, setCategory] = (0, import_react.useState)(existing?.category ?? "Business Documents");
	const [status, setStatus] = (0, import_react.useState)(existing?.status ?? "Draft");
	const [version, setVersion] = (0, import_react.useState)(existing?.version ?? "1.0");
	const [summary, setSummary] = (0, import_react.useState)(existing?.summary ?? "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			if (!name.trim()) return toast.error("Document needs a name.");
			save({
				id,
				name,
				category,
				status,
				version,
				summary
			});
			toast.success("Document registered");
			onDone();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Name",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: name,
					onChange: (e) => setName(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "Category",
				value: category,
				options: [
					"Business Documents",
					"Contracts",
					"Invoices",
					"Brand",
					"Certificates"
				],
				onChange: setCategory
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Version",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: version,
					onChange: (e) => setVersion(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "Status",
				value: status,
				options: [
					"Draft",
					"Active",
					"Archived"
				],
				onChange: setStatus
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Summary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: `${inputClass} h-28 py-3`,
					value: summary,
					onChange: (e) => setSummary(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
				type: "submit",
				children: "Register document"
			})
		]
	});
}
function ScriptForm({ id, onDone }) {
	const existing = useTc((s) => s.scripts.find((d) => d.id === id));
	const save = useTc((s) => s.saveScript);
	const [name, setName] = (0, import_react.useState)(existing?.name ?? "");
	const [type, setType] = (0, import_react.useState)(existing?.type ?? "WhatsApp");
	const [audience, setAudience] = (0, import_react.useState)(existing?.audience ?? "Residential customer");
	const [body, setBody] = (0, import_react.useState)(existing?.body ?? "");
	const [status, setStatus] = (0, import_react.useState)(existing?.status ?? "Active");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			if (!name.trim() || !body.trim()) return toast.error("Name and script body are required.");
			save({
				id,
				name,
				type,
				audience,
				body,
				status
			});
			toast.success("Script saved");
			onDone();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Name",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: name,
					onChange: (e) => setName(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "Type",
				value: type,
				options: [
					"WhatsApp",
					"Call",
					"Email"
				],
				onChange: (v) => setType(v)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Audience",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: audience,
					onChange: (e) => setAudience(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Script body",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: `${inputClass} h-36 py-3`,
					value: body,
					onChange: (e) => setBody(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "Status",
				value: status,
				options: ["Active", "Draft"],
				onChange: setStatus
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
				type: "submit",
				children: "Save script"
			})
		]
	});
}
function EquipForm({ id, onDone }) {
	const existing = useTc((s) => s.equipment.find((d) => d.id === id));
	const save = useTc((s) => s.saveEquipment);
	const [name, setName] = (0, import_react.useState)(existing?.name ?? "");
	const [spec, setSpec] = (0, import_react.useState)(existing?.spec ?? "");
	const [status, setStatus] = (0, import_react.useState)(existing?.status ?? "In Fleet");
	const [base, setBase] = (0, import_react.useState)(existing?.base ?? "Benoni");
	const [notes, setNotes] = (0, import_react.useState)(existing?.notes ?? "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			if (!name.trim()) return toast.error("Name the equipment.");
			save({
				id,
				name,
				spec,
				status,
				base,
				notes
			});
			toast.success("Equipment logged");
			onDone();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Name",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: name,
					onChange: (e) => setName(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Spec",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: spec,
					onChange: (e) => setSpec(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "Status",
				value: status,
				options: [
					"In Fleet",
					"In Repair",
					"Retired"
				],
				onChange: (v) => setStatus(v)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "Base",
				value: base,
				options: [
					"Tsakane",
					"Benoni",
					"Daveyton"
				],
				onChange: setBase
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Notes",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: `${inputClass} h-20 py-3`,
					value: notes,
					onChange: (e) => setNotes(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
				type: "submit",
				children: "Save equipment"
			})
		]
	});
}
function Choice({ label, value, options, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
		label,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-2",
			children: options.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onChange(opt),
				className: `h-10 rounded-full px-3 text-xs font-extrabold ${value === opt ? "bg-teal text-on-teal" : "border border-line bg-paper text-ink"}`,
				children: opt
			}, opt))
		})
	});
}
function PayBody({ bookingId, onDone }) {
	const booking = useTc((s) => s.bookings.find((b) => b.id === bookingId));
	const payments = useTc((s) => s.payments);
	const logPayment = useTc((s) => s.logPayment);
	const cost = booking ? costBooking(booking, depositFor(booking.id, payments)) : null;
	const [amount, setAmount] = (0, import_react.useState)(cost?.depositRequired && cost.depositReceived < cost.depositRequired ? cost.depositRequired - cost.depositReceived : cost?.balanceDue ?? 0);
	const [method, setMethod] = (0, import_react.useState)("EFT");
	if (!booking || !cost) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm font-semibold text-muted",
			children: [
				"Balance due ",
				money(cost.balanceDue),
				". Required deposit ",
				money(cost.depositRequired),
				"."
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Amount",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "number",
				className: inputClass,
				value: amount,
				onChange: (e) => setAmount(Number(e.target.value))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
			label: "Method",
			value: method,
			options: [
				"EFT",
				"Cash",
				"Card"
			],
			onChange: (v) => setMethod(v)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
			onClick: () => {
				if (amount <= 0) return toast.error("Enter an amount.");
				logPayment(booking.id, amount, method);
				toast.success("Payment logged");
				onDone();
			},
			children: ["Record ", money(Number(amount) || 0)]
		})
	] });
}
function CreateMenu({ onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-2",
		children: [
			{
				id: "bookings",
				label: "Booking",
				icon: Calendar
			},
			{
				id: "quotes",
				label: "Quote",
				icon: Receipt
			},
			{
				id: "clients",
				label: "Client",
				icon: Users
			},
			{
				id: "tasks",
				label: "Task",
				icon: ClipboardList
			},
			{
				id: "budget",
				label: "Budget line",
				icon: Wallet
			},
			{
				id: "equipment",
				label: "Equipment",
				icon: Wrench
			},
			{
				id: "scripts",
				label: "Script",
				icon: MessageSquare
			},
			{
				id: "properties",
				label: "Property",
				icon: Building2
			}
		].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => onPick(item.id),
			className: "flex h-20 flex-col items-start justify-center rounded-2xl border border-line bg-canvas px-3 text-left",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-4 text-teal" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1 text-sm font-extrabold text-ink",
				children: item.label
			})]
		}, item.id))
	});
}
function MenuBody({ name, role, onOpen, onSettings, onLogout }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col bg-paper",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-navy px-4 pt-6 pb-5 text-on-navy",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-bold tracking-widest text-aqua",
						children: "SIGNED IN"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 text-xl font-extrabold",
						children: name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-aqua",
						children: role
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 overflow-y-auto px-3 py-3",
				children: GROUPS.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-2 text-xs font-extrabold tracking-widest text-muted",
						children: group
					}), Object.keys(TABLE_META).filter((id) => TABLE_META[id].group === group).map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onOpen(id),
						className: "flex h-11 w-full items-center rounded-xl px-2 text-left text-sm font-bold text-ink active:bg-wash",
						children: TABLE_META[id].label
					}, id))]
				}, group))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-line p-3 pb-nav",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onSettings,
					className: "mb-2 h-11 w-full rounded-2xl bg-wash text-sm font-extrabold text-ink",
					children: "Settings"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onLogout,
					className: "h-11 w-full rounded-2xl text-sm font-extrabold text-muted",
					children: "Log out"
				})]
			})
		]
	});
}
function SettingsBody({ onClose }) {
	const theme = useTc((s) => s.theme);
	const lang = useTc((s) => s.lang);
	const setTheme = useTc((s) => s.setTheme);
	const setLang = useTc((s) => s.setLang);
	const lastSync = useTc((s) => s.lastSync);
	const resetDemo = useTc((s) => s.resetDemo);
	const [about, setAbout] = (0, import_react.useState)(false);
	const [help, setHelp] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs font-bold text-muted",
			children: ["Version 1.3 · Last sync ", formatWhen(new Date(lastSync).toISOString())]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "Theme" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-3 gap-2",
			children: [
				["default", "Default"],
				["dark", "Dark"],
				["ios", "iOS"]
			].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setTheme(id),
				className: `h-16 rounded-2xl text-sm font-extrabold ${theme === id ? "bg-teal text-on-teal" : "border border-line"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `mx-auto mb-1 block size-4 rounded-full ${id === "dark" ? "bg-navy" : id === "ios" ? "bg-canvas ring-1 ring-line" : "bg-teal"}` }), label]
			}, id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "Language" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-3 gap-2",
			children: [
				["en", "English"],
				["zu", "isiZulu"],
				["af", "Afrikaans"]
			].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setLang(id),
				className: `h-11 rounded-2xl text-xs font-extrabold ${lang === id ? "bg-navy text-on-navy" : "border border-line"}`,
				children: label
			}, id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-xs font-medium text-muted",
			children: "Currency stays Rand. TerraCelest bills in ZAR only."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
					onClick: () => setAbout(true),
					children: "About TerraCelest"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
					onClick: () => setHelp(true),
					children: "Get help"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
					onClick: () => {
						resetDemo();
						toast.success("Training data reset");
						onClose();
					},
					children: "Reset training data"
				})
			]
		}),
		about ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 rounded-3xl bg-navy p-4 text-on-navy",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-bold tracking-brand text-aqua",
					children: "CLEAN SPACES. BETTER PLACES."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed",
					children: "TerraCelest Group of Companies (PTY) LTD · 2026/665752/07. 6690 Mala Street, Daveyton, Benoni, 1520. Also at Unit 5, Greenstone Office Park, Modderfontein. Empower · Innovate · Elevate."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-3 text-sm font-bold text-aqua",
					onClick: () => setAbout(false),
					children: "Close"
				})
			]
		}) : null,
		help ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 rounded-3xl border border-line p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-ink",
					children: "Desk: 061 467 9207"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "inline-flex h-11 items-center rounded-2xl bg-teal px-3 text-sm font-extrabold text-on-teal",
						href: "tel:0614679207",
						children: "Call"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "inline-flex h-11 items-center rounded-2xl bg-navy px-3 text-sm font-extrabold text-on-navy",
						href: "https://wa.me/27614679207",
						target: "_blank",
						rel: "noreferrer",
						children: "WhatsApp"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-muted",
					children: "info@terracelest.co.za · team@terracelest.com"
				})
			]
		}) : null
	] });
}
var STEPS = [
	"Opening your workspace",
	"Checking your session",
	"Loading today’s jobs",
	"Ready"
];
function TerraApp() {
	const theme = useTc((s) => s.theme);
	const lang = useTc((s) => s.lang);
	const session = useTc((s) => s.session);
	const login = useTc((s) => s.login);
	const logout = useTc((s) => s.logout);
	const sync = useTc((s) => s.sync);
	const markFeedRead = useTc((s) => s.markFeedRead);
	const feed = useTc((s) => s.feed);
	const softDelete = useTc((s) => s.softDelete);
	const restore = useTc((s) => s.restore);
	const [phase, setPhase] = (0, import_react.useState)("splash");
	const [ready, setReady] = (0, import_react.useState)(false);
	const [waited, setWaited] = (0, import_react.useState)(false);
	const [page, setPage] = (0, import_react.useState)({ name: "home" });
	const [overlay, setOverlay] = (0, import_react.useState)(null);
	const [query, setQuery] = (0, import_react.useState)("");
	const [lastTable, setLastTable] = (0, import_react.useState)(null);
	const [confirm, setConfirm] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		document.documentElement.dataset.theme = theme === "default" ? "" : theme;
	}, [theme]);
	(0, import_react.useEffect)(() => {
		let settled = false;
		const finish = () => {
			if (!settled) {
				settled = true;
				setReady(true);
			}
		};
		const unsub = useTc.persist.onFinishHydration(finish);
		if (useTc.persist.hasHydrated()) finish();
		const timer = window.setTimeout(() => setWaited(true), 1500);
		return () => {
			unsub();
			window.clearTimeout(timer);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready || !waited || phase !== "splash") return;
		const live = liveSession(useTc.getState().session);
		if (useTc.getState().session && !live) useTc.getState().logout();
		setPhase(live ? "app" : "login");
	}, [
		ready,
		waited,
		phase
	]);
	(0, import_react.useEffect)(() => {
		function onKey(e) {
			if (e.key === "Escape") {
				setConfirm(null);
				setOverlay(null);
			}
			if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
				e.preventDefault();
				document.getElementById("tc-search")?.focus();
			}
			if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "n") {
				e.preventDefault();
				openCreate();
			}
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	});
	const user = USERS.find((u) => u.id === liveSession(session)?.userId);
	const unread = unreadCount(feed);
	const helloKey = greeting();
	function openTable(table) {
		setLastTable(table);
		setPage({
			name: "table",
			table
		});
		setOverlay(null);
		setQuery("");
	}
	function openCreate() {
		if (page.name === "table" && page.table !== "invoices" && page.table !== "payments") {
			setOverlay({
				kind: "form",
				table: page.table
			});
			return;
		}
		setOverlay({ kind: "create" });
	}
	function askDelete(table, id, name) {
		setConfirm({
			title: `Delete “${name}”?`,
			message: "It leaves the active lists. Undo is available for a few seconds. Records are not wiped forever.",
			onYes: () => {
				softDelete(table, id);
				setOverlay(null);
				setConfirm(null);
				toast(`${name} removed`, { action: {
					label: "Undo",
					onClick: () => restore(table, id)
				} });
			}
		});
	}
	const shortName = user ? user.name.replace(/^Miss\s+/, "").split(" ")[0] : "";
	const title = page.name === "home" ? user ? `${t(lang, helloKey)}, ${shortName}` : "Command" : page.name === "office" ? t(lang, "office") : page.name === "updates" ? t(lang, "updates") : TABLE_META[page.table].label;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-navy text-ink lg:grid lg:grid-cols-[minmax(0,1fr)_430px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "hidden flex-col justify-between px-10 py-12 text-on-navy lg:flex",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-24 place-items-center rounded-3xl bg-paper shadow-lg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "h-16" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-3xl font-extrabold tracking-wide text-on-navy",
						children: "TERRA CELEST"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm font-bold tracking-brand text-teal",
						children: "FACILITIES"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 text-xs font-bold tracking-brand text-aqua",
					children: "CLEAN SPACES. BETTER PLACES."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 max-w-md text-4xl font-extrabold leading-tight text-balance",
					children: "The floor, from quote to the last room."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 max-w-sm text-sm leading-relaxed text-pretty text-on-navy/80",
					children: "Bookings, deposits, internal costing and the team that shows up across Ekurhuleni."
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-6 text-xs font-extrabold tracking-brand text-aqua",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "EMPOWER" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "INNOVATE" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "ELEVATE" })
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto flex h-dvh w-full max-w-[430px] flex-col overflow-hidden bg-canvas shadow-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, { position: "top-center" }),
				phase === "splash" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {}) : null,
				phase === "login" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Login, { onLogin: (id) => {
					login(id);
					setPhase("app");
				} }) : null,
				phase === "app" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "shrink-0 px-4 pt-4 pb-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [
								page.name === "table" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "text-xs font-extrabold text-teal",
									onClick: () => setPage({ name: "office" }),
									children: "Office"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "h-10" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-extrabold tracking-brand text-teal",
										children: "TERRA CELEST"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "truncate text-lg font-extrabold text-ink",
										children: title
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "h-11 rounded-full px-3 text-xs font-extrabold text-teal",
									onClick: () => {
										sync();
										toast.success("Workspace synced");
									},
									children: "Sync"
								})
							]
						}), page.name === "home" || page.name === "table" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-3 flex h-12 items-center gap-2 rounded-2xl border border-line bg-paper px-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-teal" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "tc-search",
								value: query,
								onChange: (e) => setQuery(e.target.value),
								placeholder: t(lang, "search"),
								className: "h-full w-full bg-transparent text-sm font-semibold text-ink outline-none placeholder:text-muted"
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs font-medium text-muted",
							children: page.name === "updates" ? "Creates, payments, quotes and fleet notes." : "Department tables. Tap one to work the list."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
						className: "min-h-0 flex-1 overflow-y-auto",
						children: [
							page.name === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeScreen, {
								lang,
								query,
								onOpen: openTable,
								onDetail: (table, id) => setOverlay({
									kind: "detail",
									table,
									id
								})
							}) : null,
							page.name === "office" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OfficeScreen, {
								lastTable,
								onOpen: openTable
							}) : null,
							page.name === "updates" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UpdatesScreen, {}) : null,
							page.name === "table" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableScreen, {
								table: page.table,
								query,
								onDetail: (id) => setOverlay({
									kind: "detail",
									table: page.table,
									id
								}),
								onCreate: () => setOverlay({
									kind: "form",
									table: page.table
								})
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "relative grid h-[4.5rem] shrink-0 grid-cols-5 border-t border-line bg-paper pb-nav",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
								label: t(lang, "home"),
								active: page.name === "home",
								onClick: () => {
									setPage({ name: "home" });
									setQuery("");
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
								label: t(lang, "office"),
								active: page.name === "office" || page.name === "table",
								onClick: () => {
									setPage({ name: "office" });
									setQuery("");
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "relative",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "Create",
									onClick: openCreate,
									className: "absolute -top-5 left-1/2 grid size-14 -translate-x-1/2 place-items-center rounded-full bg-teal text-on-teal shadow-lg active:scale-95",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-6" })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
								label: t(lang, "updates"),
								active: page.name === "updates",
								badge: unread,
								onClick: () => {
									setPage({ name: "updates" });
									markFeedRead();
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
								label: t(lang, "menu"),
								active: overlay?.kind === "menu",
								onClick: () => setOverlay({ kind: "menu" }),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
							})
						]
					}),
					overlay?.kind === "menu" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-0 z-40 flex bg-navy/45",
						onClick: () => setOverlay(null),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full w-[84%] max-w-xs shadow-xl",
							onClick: (e) => e.stopPropagation(),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuBody, {
								name: user?.name ?? "Team",
								role: user?.role ?? "",
								onOpen: openTable,
								onSettings: () => setOverlay({ kind: "settings" }),
								onLogout: () => {
									setConfirm({
										title: "Log out?",
										message: "You will need a PIN to come back in. Today’s jobs stay on this phone.",
										onYes: () => {
											logout();
											setConfirm(null);
											setOverlay(null);
											setPhase("login");
										}
									});
								}
							})
						})
					}) : null,
					overlay?.kind === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
						title: "Settings",
						onClose: () => setOverlay(null),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsBody, { onClose: () => setOverlay(null) })
					}) : null,
					overlay?.kind === "create" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
						title: "Create",
						onClose: () => setOverlay(null),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateMenu, { onPick: (table) => {
							setLastTable(table);
							setPage({
								name: "table",
								table
							});
							setOverlay({
								kind: "form",
								table
							});
						} })
					}) : null,
					overlay?.kind === "detail" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
						title: TABLE_META[overlay.table].label,
						onClose: () => setOverlay(null),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailBody, {
							table: overlay.table,
							id: overlay.id,
							onEdit: () => setOverlay({
								kind: "form",
								table: overlay.table,
								id: overlay.id
							}),
							onDelete: (name) => askDelete(overlay.table, overlay.id, name),
							onPay: () => setOverlay({
								kind: "pay",
								bookingId: overlay.id
							})
						})
					}) : null,
					overlay?.kind === "form" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
						title: overlay.id ? `Edit ${TABLE_META[overlay.table].label}` : `New ${TABLE_META[overlay.table].label.replace(/s$/, "")}`,
						onClose: () => setOverlay(null),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormBody, {
							table: overlay.table,
							id: overlay.id,
							onDone: () => setOverlay(null)
						})
					}) : null,
					overlay?.kind === "pay" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
						title: "Log payment",
						onClose: () => setOverlay(null),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PayBody, {
							bookingId: overlay.bookingId,
							onDone: () => setOverlay(null)
						})
					}) : null,
					confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-0 z-50 grid place-items-center bg-navy/50 px-6",
						role: "dialog",
						"aria-modal": "true",
						"aria-label": confirm.title,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "w-full rounded-3xl bg-paper p-5 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-lg font-extrabold text-ink",
									children: confirm.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-muted",
									children: confirm.message
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "h-12 rounded-2xl border border-line text-sm font-extrabold",
										onClick: () => setConfirm(null),
										children: "Cancel"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "h-12 rounded-2xl bg-navy text-sm font-extrabold text-on-navy",
										onClick: confirm.onYes,
										children: "Yes, proceed"
									})]
								})
							]
						})
					}) : null
				] }) : null
			]
		})]
	});
}
function NavButton({ label, active, onClick, children, badge = 0 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: `flex flex-col items-center justify-center gap-0.5 text-xs font-extrabold ${active ? "text-teal" : "text-muted"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "relative",
			children: [children, badge > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute -top-1 -right-2 grid min-w-4 place-items-center rounded-full bg-teal px-1 text-[10px] text-on-teal",
				children: badge
			}) : null]
		}), label]
	});
}
function Splash() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "tc-splash flex h-full flex-col justify-between px-6 py-10 text-on-navy",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid size-24 place-items-center rounded-3xl bg-paper shadow-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "h-16" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-2xl font-extrabold tracking-wide",
				children: "TERRA CELEST"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs font-bold tracking-brand text-on-navy/90",
				children: "FACILITIES"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs font-semibold tracking-widest",
				children: "CLEAN SPACES. BETTER PLACES."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-3",
			children: STEPS.map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center gap-3 text-sm font-semibold",
				style: { animation: `tc-rise 0.4s ease ${i * .28}s both` },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-6 place-items-center rounded-full bg-paper text-xs font-extrabold text-teal",
					children: i + 1
				}), step]
			}, step))
		})]
	});
}
function Login({ onLogin }) {
	const [userId, setUserId] = (0, import_react.useState)("phindi");
	const [pin, setPin] = (0, import_react.useState)("");
	const [shake, setShake] = (0, import_react.useState)(false);
	const pinRef = (0, import_react.useRef)("");
	const user = USERS.find((u) => u.id === userId);
	function setDigits(next) {
		pinRef.current = next;
		setPin(next);
	}
	function push(digit) {
		const next = (pinRef.current + digit).slice(0, 4);
		setDigits(next);
		if (next.length < 4) return;
		if (next === user.pin) onLogin(user.id);
		else {
			setShake(true);
			setDigits("");
			toast.error("That PIN does not match this profile.");
			window.setTimeout(() => setShake(false), 400);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col bg-canvas px-5 pt-8 pb-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "h-14" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-4 text-2xl font-extrabold text-ink",
				children: "Sign in"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-bold tracking-brand text-teal",
				children: "CLEAN SPACES. BETTER PLACES."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm font-medium text-muted",
				children: "Choose your profile, then the 4-digit training PIN."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid grid-cols-2 gap-2",
				children: USERS.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						setUserId(u.id);
						setDigits("");
					},
					className: `rounded-2xl border px-3 py-3 text-left ${userId === u.id ? "border-teal bg-wash" : "border-line bg-paper"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm font-extrabold text-ink",
							children: u.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs font-semibold text-muted",
							children: u.role
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-1 block text-xs font-extrabold text-teal",
							children: ["PIN ", u.pin]
						})
					]
				}, u.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-center text-sm font-extrabold text-ink",
				children: user.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `mt-2 flex justify-center gap-3 ${shake ? "tc-shake" : ""}`,
				children: [
					0,
					1,
					2,
					3
				].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-3 rounded-full ${pin.length > i ? "bg-teal" : "bg-line"}` }, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-auto grid grid-cols-3 gap-2",
				children: [
					"1",
					"2",
					"3",
					"4",
					"5",
					"6",
					"7",
					"8",
					"9",
					"C",
					"0",
					"⌫"
				].map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-14 rounded-2xl bg-paper text-lg font-extrabold text-ink shadow-sm active:bg-wash",
					onClick: () => {
						if (key === "C") setDigits("");
						else if (key === "⌫") setDigits(pinRef.current.slice(0, -1));
						else push(key);
					},
					children: key
				}, key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-center text-xs font-semibold text-muted",
				children: ["Forgot PIN? Call ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "text-teal",
					href: "tel:0614679207",
					children: "061 467 9207"
				})]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TerraApp, {});
}
//#endregion
export { Home as component };

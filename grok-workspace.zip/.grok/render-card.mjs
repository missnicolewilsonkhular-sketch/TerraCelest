import { chromium } from "playwright";

const browser = await chromium.launch({ args: ["--no-sandbox"] });
const card = await browser.newPage({
  viewport: { width: 1200, height: 630 },
  deviceScaleFactor: 1,
});
await card.goto("file:///workspace/.grok/og-card.html", { waitUntil: "load" });
await card.evaluate(() => document.fonts.ready);
const metrics = await card.evaluate(() => {
  const box = (sel) => {
    const r = document.querySelector(sel).getBoundingClientRect();
    return {
      x: Math.round(r.x),
      y: Math.round(r.y),
      w: Math.round(r.width),
      h: Math.round(r.height),
      r: Math.round(r.right),
      b: Math.round(r.bottom),
    };
  };
  return {
    mark: box(".mark"),
    h: box("h1"),
    s: box(".sub"),
    t: box(".tag"),
    text: document.body.innerText.replace(/\s+/g, " ").trim(),
  };
});
console.log(JSON.stringify(metrics, null, 2));
await card.screenshot({ path: "/workspace/.grok/og-raw.png" });
await browser.close();

/**
 * TerraCelest Booking — State & profile helpers
 */
(function (w) {
  'use strict';
  var TC = w.TCBooking = w.TCBooking || {};

  TC.activeSteps = TC.STEPS.slice();
  TC.stepIndex = 0;
  TC.lastPriceTotal = null;

  TC.data = {
    accountMode: 'guest',
    accountEmail: '', accountPassword: '',
    name: '', phone: '', email: '', address: '', addressObj: null, lat: null, lng: null,
    commMethod: 'WhatsApp',
    service: '', propertyType: '', bedrooms: 2, bathrooms: 1,
    rooms: [], condition: 'Normal Cleaning',
    products: { chemicals: true, equipment: true, cloths: true, accessories: false },
    addons: [], pets: { has: false, types: [], notes: '' },
    access: { gateCode: '', estate: '', aptNumber: '', floor: '', parking: '', keyInstr: '', someonePresent: true, contactOnSite: '' },
    booking: { date: '', time: '', flexible: false, period: 'Morning' },
    instructions: '',
    paymentMethod: '',
    bookingNumber: '',
    _intent: null
  };

TC.getActiveBookings = function() {
  try {
    const list = JSON.parse(localStorage.getItem('tc_bookings') || '[]');
    const today = new Date(); today.setHours(0,0,0,0);
    return list.filter(b => {
      const st = String(b.status || '').toLowerCase().replace(/\s+/g, '_');
      if (st === 'cancelled' || st === 'canceled' || st === 'completed') return false;
      if (!b.date) return true; // undated draft still counts as active
      return new Date(b.date + 'T12:00:00') >= today;
    });
  } catch { return []; }
}

TC.getSavedProfile = function() {
  try { return JSON.parse(localStorage.getItem('tc_profile') || '{}'); }
  catch { return {}; }
}

TC.applyProfileToData = function(profile) {
  if (!profile || !profile.name) return false;
  TC.data.name = profile.name || TC.data.name;
  TC.data.phone = profile.phone || TC.data.phone;
  TC.data.email = profile.email || TC.data.email;
  TC.data.address = profile.address || TC.data.address;
  TC.data.commMethod = profile.commMethod || TC.data.commMethod;
  return true;
}

TC.getAccounts = function() {
  try { return JSON.parse(localStorage.getItem('tc_accounts') || '[]'); }
  catch { return []; }
}

TC.saveAccount = function(acc) {
  const list = TC.getAccounts();
  const email = (acc.email || '').toLowerCase();
  const idx = list.findIndex(a => (a.email || '').toLowerCase() === email);
  if (idx >= 0) list[idx] = { ...list[idx], ...acc, email };
  else list.push({ ...acc, email });
  localStorage.setItem('tc_accounts', JSON.stringify(list));
}

TC.findAccount = function(email, password) {
  const e = (email || '').toLowerCase().trim();
  return TC.getAccounts().find(a => (a.email || '').toLowerCase() === e && a.password === password) || null;
}

TC.formatSlotDate = function(offset) {
  const d = new Date();
  d.setDate(d.getDate() + offset);
  return d.toISOString().slice(0, 10);
}

TC.isSlotAvailable = function(dateStr, timeStr) {
  // Demo: weekends and times outside 08:00–17:00 treated as unavailable
  if (!dateStr) return false;
  const d = new Date(dateStr + 'T12:00:00');
  const day = d.getDay();
  if (day === 0) return false; // Sunday closed
  if (timeStr) {
    const [h] = timeStr.split(':').map(Number);
    if (h < 8 || h >= 17) return false;
  }
  return true;
}

TC.canPayOnArrival = function() {
  try {
    const profile = TC.getSavedProfile();
    if (profile && (profile.subscriber === true || profile.isSubscriber === true)) return true;
    const list = JSON.parse(localStorage.getItem('tc_bookings') || '[]');
    if (Array.isArray(list) && list.length > 3) return true;
  } catch (_) {}
  return false;
}

TC.defaultRoomsFromProperty = function() {
  const rooms = ['Kitchen', 'Lounge'];
  for (let i = 0; i < TC.data.bedrooms; i++) rooms.push(i === 0 ? 'Main Bedroom' : 'Guest Bedroom');
  for (let i = 0; i < TC.data.bathrooms; i++) rooms.push(i === 0 ? 'Bathroom' : 'En-suite Bathroom');
  return rooms;
}

TC.esc = function(s) {
  return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

TC.generateBookingNumber = function() {
  const d = new Date();
  const y = d.getFullYear().toString().slice(2);
  const m = String(d.getMonth()+1).padStart(2,'0');
  const day = String(d.getDate()).padStart(2,'0');
  const r = Math.floor(Math.random()*9000)+1000;
  return `TC-${y}${m}${day}-${r}`;
}


  // Apply mode from ?mode=quote|book
  TC.applyMode = function () {
    try {
      var mode = new URLSearchParams(location.search).get('mode');
      if (mode !== 'quote' && mode !== 'book') return;
      TC.data.accountMode = 'guest';
      TC.data._intent = mode;
      var profile = TC.getSavedProfile();
      if (profile && profile.name) {
        TC.applyProfileToData(profile);
        TC.activeSteps = TC.RETURNING_STEPS.slice();
      } else {
        TC.activeSteps = TC.STEPS.filter(function (s) { return s !== 'welcome'; });
      }
    } catch (e) { console.warn(e); }
  };

  // $ helper
  TC.$ = function (id) { return document.getElementById(id); };

})(window);

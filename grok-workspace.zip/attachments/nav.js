// TerraCelest navigation — works with app.js
(function () {
  const role = (window.tcRole && tcRole()) || localStorage.getItem('tc_role') || 'guest';

  const path = (location.pathname.split('/').pop() || 'index.html').replace(/^\//, '');
  document.querySelectorAll('.bottom-nav a').forEach(a => {
    const href = (a.getAttribute('href') || '').split('?')[0];
    if (!href || href === '#') return;
    const base = href.replace('.html', '');
    if (path === href || path.includes(base)) a.classList.add('active');
  });

  const overlay = document.getElementById('drawerOverlay');
  const drawer = document.getElementById('drawer');
  const openBtn = document.getElementById('btnDrawer');
  const closeBtn = document.getElementById('btnDrawerClose');

  function openDrawer() {
    if (overlay) overlay.classList.add('open');
    if (drawer) drawer.classList.add('open');
  }
  function closeDrawer() {
    if (overlay) overlay.classList.remove('open');
    if (drawer) drawer.classList.remove('open');
  }

  if (openBtn) openBtn.addEventListener('click', openDrawer);
  if (closeBtn) closeBtn.addEventListener('click', closeDrawer);
  if (overlay) overlay.addEventListener('click', closeDrawer);

  window.tcRequireRole = function (allowed) {
    if (!allowed.includes(role) && role !== 'admin') {
      console.warn('Role restricted:', role);
    }
  };

  if (!window.tcHome) {
    window.tcHome = function () {
      if (role === 'worker') return 'worker-dashboard.html';
      if (role === 'admin') return 'admin.html';
      if (role === 'guest') return 'index.html';
      return 'dashboard.html';
    };
  }
  if (!window.tcNotify) {
    window.tcNotify = function (title, body) {
      try {
        const list = JSON.parse(localStorage.getItem('tc_notifications') || '[]');
        list.unshift({ id: Date.now(), title, body, time: 'Just now', unread: true });
        localStorage.setItem('tc_notifications', JSON.stringify(list.slice(0, 30)));
      } catch (e) {}
    };
  }
})();

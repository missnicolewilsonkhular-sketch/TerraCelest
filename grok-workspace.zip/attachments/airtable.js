/**
 * TerraCelest Airtable client — full field mapping
 * Base: appgzWiwsyL0qAisg
 * Fixes: client upsert, user update, GPS numbers, access mapping,
 *        promo date checks, exported catalog helpers, stable IDs
 */
(function (w) {
  'use strict';

  const AT_TOKEN = 'patYoMBcrqk1xCC9G.123b09512a984a1c522f58e864b531dc9b8e8f9244772166ecf540a8fde7cfc8';
  const AT_BASE = 'appgzWiwsyL0qAisg';
  const AT_URL = 'https://api.airtable.com/v0/' + AT_BASE;
  const AT_HEADERS = {
    Authorization: 'Bearer ' + AT_TOKEN,
    'Content-Type': 'application/json'
  };

  async function atRequest(method, path, body) {
    const opts = { method, headers: AT_HEADERS };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(AT_URL + path, opts);
    const text = await res.text();
    let json = null;
    try { json = text ? JSON.parse(text) : null; } catch { json = { raw: text }; }
    if (!res.ok) {
      const msg = (json && json.error && json.error.message) || text.slice(0, 240);
      throw new Error((path || method) + ' failed: ' + res.status + ' ' + msg);
    }
    return json;
  }

  function atPost(table, fields) {
    return atRequest('POST', '/' + encodeURIComponent(table), { fields, typecast: true });
  }
  function atPatch(table, id, fields) {
    return atRequest('PATCH', '/' + encodeURIComponent(table) + '/' + id, { fields, typecast: true });
  }
  function atGet(table, params) {
    const q = params ? '?' + new URLSearchParams(params).toString() : '';
    return atRequest('GET', '/' + encodeURIComponent(table) + q);
  }

  function escFormula(s) {
    return String(s || '').replace(/'/g, "\\'");
  }

  function money(n) {
    const v = Number(n);
    return isFinite(v) ? v : 0;
  }

  function gpsValue(n) {
    const v = Number(n);
    return isFinite(v) ? v : undefined;
  }

  function mapJobType(service) {
    const s = (service || '').toLowerCase();
    if (s.includes('deep') || s.includes('spring')) return 'Deep Clean';
    if (s.includes('window')) return 'Window';
    if (s.includes('carpet')) return 'Carpet';
    if (s.includes('laundry')) return 'Laundry';
    if (s.includes('standard') || s.includes('recurring') || s.includes('once') || s.includes('clean')) return 'Standard Clean';
    return 'Other';
  }

  function mapPropertyType(t) {
    const m = {
      House: 'House', Apartment: 'Apartment', Townhouse: 'Duplex',
      Duplex: 'Duplex', Cottage: 'Other', Estate: 'Estate', Commercial: 'Commercial'
    };
    return m[t] || 'House';
  }

  function mapPaymentMethod(m) {
    const s = (m || '').toLowerCase();
    if (s.includes('card') || s.includes('visa') || s.includes('yoco')) return 'Card';
    if (s.includes('eft') || s.includes('instant') || s.includes('ozow') || s.includes('payfast')) return 'EFT';
    if (s.includes('cash') || s.includes('arrival')) return 'Cash';
    return 'Other';
  }

  function mapCommMethod(m) {
    const s = (m || '').toLowerCase();
    if (s.includes('whats')) return 'WhatsApp';
    if (s.includes('email') || s.includes('mail')) return 'Email';
    if (s.includes('sms')) return 'SMS';
    return 'Phone';
  }

  function mapPaymentStatus(s) {
    const v = (s || '').toLowerCase();
    if (v === 'paid' || v === 'completed') return 'Paid';
    if (v === 'refunded') return 'Refunded';
    if (v === 'failed') return 'Failed';
    return 'Unpaid';
  }

  function parseAddress(addr) {
    if (addr && typeof addr === 'object') {
      return {
        street: addr.street || addr.street_number || '',
        number: addr.number || addr.street_number || '',
        suburb: addr.suburb || '',
        city: addr.city || '',
        postal: addr.postal || addr.postal_code || '',
        province: addr.province || 'Gauteng',
        full: addr.full || [addr.street, addr.suburb, addr.city, addr.postal].filter(Boolean).join(', ')
      };
    }
    const parts = String(addr || '').split(',').map(p => p.trim()).filter(Boolean);
    return {
      street: parts[0] || String(addr || ''),
      number: '',
      suburb: parts[1] || '',
      city: parts[2] || parts[1] || '',
      postal: parts[3] || '',
      province: 'Gauteng',
      full: String(addr || '')
    };
  }

  function googleMapsLink(lat, lng, addressText) {
    if (lat && lng) {
      return 'https://www.google.com/maps?q=' + encodeURIComponent(lat + ',' + lng);
    }
    if (addressText) {
      return 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(addressText);
    }
    return '';
  }

  function toStartTimeISO(date, time, period) {
    if (!date) return null;
    let hhmm = '09:00';
    if (time && /^\d{1,2}:\d{2}/.test(String(time))) hhmm = String(time).slice(0, 5);
    else if ((period || '').toLowerCase().includes('after')) hhmm = '13:00';
    else if ((period || '').toLowerCase().includes('morn')) hhmm = '09:00';
    return date + 'T' + hhmm + ':00.000Z';
  }

  function splitName(name) {
    const parts = String(name || '').trim().split(/\s+/);
    return { first: parts[0] || '', last: parts.slice(1).join(' ') || '' };
  }

  /** Look up existing Client by email or phone (P0: avoid duplicates) */
  async function findClientByContact(email, phone) {
    const clauses = [];
    if (email) {
      clauses.push("LOWER({Email})=LOWER('" + escFormula(email) + "')");
    }
    if (phone) {
      const p = String(phone).replace(/\s+/g, '');
      clauses.push("OR(SUBSTITUTE({Phone},' ','')='" + escFormula(p) + "',SUBSTITUTE({WhatsApp Number},' ','')='" + escFormula(p) + "')");
    }
    if (!clauses.length) return null;
    const formula = clauses.length === 1 ? clauses[0] : 'OR(' + clauses.join(',') + ')';
    try {
      const res = await atGet('Clients', { filterByFormula: formula, maxRecords: '1' });
      return (res.records && res.records[0]) || null;
    } catch (e) {
      console.warn('findClientByContact', e);
      return null;
    }
  }

  /**
   * Create or update Clients record. Returns { id, created }.
   * Prefer existing airtableClientId when provided.
   */
  async function upsertClient(fields, existingId) {
    Object.keys(fields).forEach(k => fields[k] === undefined && delete fields[k]);
    if (existingId) {
      try {
        const rec = await atPatch('Clients', existingId, fields);
        return { id: rec.id, created: false };
      } catch (e) {
        console.warn('Client patch failed, will try find/create', e);
      }
    }
    const found = await findClientByContact(fields.Email, fields.Phone || fields['WhatsApp Number']);
    if (found) {
      const rec = await atPatch('Clients', found.id, fields);
      return { id: rec.id, created: false };
    }
    const rec = await atPost('Clients', fields);
    return { id: rec.id, created: true };
  }

  /* ---------- Auth: Users table is the sign-in code database ---------- */
  async function registerUser(profile) {
    const names = splitName(profile.name);
    const pin = String(profile.pin || profile.password || '').slice(0, 32);
    const email = profile.email || (String(profile.contact || '').includes('@') ? profile.contact : '');
    const phone = profile.phone || (!String(profile.contact || '').includes('@') ? profile.contact : '');

    const userFields = {
      Email: email || undefined,
      PIN: pin || undefined,
      'Phone Number': phone || undefined,
      'First Name': names.first || profile.name || '',
      'Last Name': names.last,
      'Account Type': profile.role === 'worker' ? 'Team Member' : (profile.role === 'admin' ? 'Admin' : 'Client'),
      'Account Status': 'Active',
      Active: true,
      'Email Verified': false,
      'Login Count': 0,
      Notes: 'Registered via TerraCelest app'
    };
    Object.keys(userFields).forEach(k => userFields[k] === undefined && delete userFields[k]);
    const user = await atPost('Users', userFields);

    let clientId = null;
    if ((profile.role || 'client') === 'client') {
      try {
        const addr = parseAddress(profile.address || {});
        const clientFields = {
          Name: profile.name || names.first || 'New client',
          Email: email || undefined,
          Phone: phone || undefined,
          'WhatsApp Number': phone || undefined,
          Status: 'New Lead',
          'Lead Source': 'Website',
          'Customer Type': 'Residential',
          Active: true,
          'Preferred Contact Method': mapCommMethod(profile.commMethod)
        };
        if (addr.street) clientFields.Address = addr.street;
        if (addr.suburb) clientFields.Suburb = addr.suburb;
        if (addr.city) clientFields.City = addr.city;
        if (addr.postal) clientFields['Postal Code'] = addr.postal;
        if (addr.province) clientFields.Province = addr.province;
        const lat = gpsValue(profile.lat);
        const lng = gpsValue(profile.lng);
        if (lat != null) clientFields['GPS Latitude'] = lat;
        if (lng != null) clientFields['GPS Longitude'] = lng;
        const maps = googleMapsLink(profile.lat, profile.lng, addr.full || addr.street);
        if (maps) clientFields['Google Maps Link'] = maps;
        const up = await upsertClient(clientFields, profile.airtableClientId || null);
        clientId = up.id;
      } catch (e) {
        console.warn('Client create on register', e);
      }
    }

    return { userId: user.id, clientId, email, phone, pin };
  }

  /** Update existing User by id (P0: settings must not create duplicates) */
  async function updateUser(userId, profile) {
    if (!userId) throw new Error('userId required for update');
    const names = splitName(profile.name);
    const fields = {};
    if (profile.name) {
      fields['First Name'] = names.first || profile.name || '';
      fields['Last Name'] = names.last;
    }
    if (profile.email) fields.Email = profile.email;
    if (profile.phone) fields['Phone Number'] = profile.phone;
    if (profile.pin || profile.password) fields.PIN = String(profile.pin || profile.password).slice(0, 32);
    if (profile.role) {
      fields['Account Type'] = profile.role === 'worker' ? 'Team Member' : (profile.role === 'admin' ? 'Admin' : 'Client');
    }
    Object.keys(fields).forEach(k => fields[k] === undefined && delete fields[k]);
    if (!Object.keys(fields).length) return { userId };
    await atPatch('Users', userId, fields);

    let clientId = profile.airtableClientId || null;
    if ((profile.role || 'client') === 'client' && (profile.name || profile.email || profile.phone)) {
      try {
        const clientFields = {
          Name: profile.name || undefined,
          Email: profile.email || undefined,
          Phone: profile.phone || undefined,
          'WhatsApp Number': profile.phone || undefined,
          Active: true
        };
        if (profile.commMethod) clientFields['Preferred Contact Method'] = mapCommMethod(profile.commMethod);
        const up = await upsertClient(clientFields, clientId);
        clientId = up.id;
      } catch (e) {
        console.warn('Client upsert on updateUser', e);
      }
    }
    return { userId, clientId };
  }

  async function loginUser(identifier, pin) {
    const id = String(identifier || '').trim();
    const code = String(pin || '').trim();
    if (!id || !code) throw new Error('Email/phone and sign-in code required');

    let formula;
    if (id.includes('@')) {
      formula = "AND(LOWER({Email})=LOWER('" + escFormula(id) + "'),{PIN}='" + escFormula(code) + "',{Active}=TRUE())";
    } else {
      formula = "AND(OR(SUBSTITUTE({Phone Number},' ','')=SUBSTITUTE('" + escFormula(id) + "',' ',''),{Phone Number}='" + escFormula(id) + "'),{PIN}='" + escFormula(code) + "',{Active}=TRUE())";
    }

    const res = await atGet('Users', { filterByFormula: formula, maxRecords: '1' });
    const rec = res.records && res.records[0];
    if (!rec) throw new Error('Invalid email/phone or sign-in code');

    const count = Number(rec.fields['Login Count'] || 0) + 1;
    try {
      await atPatch('Users', rec.id, { 'Login Count': count, 'Account Status': 'Active' });
    } catch (e) { console.warn(e); }

    const f = rec.fields;
    const roleMap = { Client: 'client', 'Team Member': 'worker', Admin: 'admin', Investor: 'client' };
    return {
      userId: rec.id,
      email: f.Email || '',
      phone: f['Phone Number'] || '',
      name: [f['First Name'], f['Last Name']].filter(Boolean).join(' ') || f['First Name'] || '',
      role: roleMap[f['Account Type']] || 'client',
      loginCount: count
    };
  }

  /**
   * submitUser: update if userId present, else register (create).
   * Prevents duplicate Users from settings save.
   */
  async function submitUser(profile) {
    if (profile && profile.userId) {
      return updateUser(profile.userId, profile);
    }
    return registerUser(profile);
  }

  /** Device geolocation → structured address via Nominatim (OpenStreetMap) */
  function captureLocation() {
    return new Promise(function (resolve, reject) {
      if (!navigator.geolocation) {
        reject(new Error('Geolocation not supported'));
        return;
      }
      navigator.geolocation.getCurrentPosition(async function (pos) {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        let address = {
          lat: lat,
          lng: lng,
          street: '',
          number: '',
          suburb: '',
          city: '',
          postal: '',
          province: 'Gauteng',
          full: '',
          maps: googleMapsLink(lat, lng)
        };
        try {
          const url = 'https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=' +
            encodeURIComponent(lat) + '&lon=' + encodeURIComponent(lng) + '&addressdetails=1';
          const r = await fetch(url, { headers: { 'Accept': 'application/json' } });
          const j = await r.json();
          const a = j.address || {};
          address.number = a.house_number || '';
          address.street = [a.house_number, a.road].filter(Boolean).join(' ') || a.road || '';
          address.suburb = a.suburb || a.neighbourhood || a.township || a.village || '';
          address.city = a.city || a.town || a.municipality || a.county || '';
          address.postal = a.postcode || '';
          address.province = a.state || 'Gauteng';
          address.full = j.display_name || [address.street, address.suburb, address.city, address.postal].filter(Boolean).join(', ');
          address.maps = googleMapsLink(lat, lng, address.full);
        } catch (e) {
          console.warn('Reverse geocode failed', e);
          address.full = lat + ', ' + lng;
        }
        resolve(address);
      }, function (err) {
        reject(err);
      }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 60000 });
    });
  }

  async function submitQuoteOnly(data) {
    const total = money(data.price != null ? data.price : data.total);
    const appRef = String(data.bookingNumber || data.id || ('Q-' + Date.now()));
    const rooms = Array.isArray(data.rooms) ? data.rooms : [];
    const addr = parseAddress(data.address);
    const lat = gpsValue(data.lat);
    const lng = gpsValue(data.lng);

    const clientFields = {
      Name: data.name || 'Website quote',
      Phone: data.phone || undefined,
      Status: 'Quote Sent',
      'Lead Source': 'Website',
      'Customer Type': 'Residential',
      Active: true
    };
    if (data.email) clientFields.Email = data.email;
    if (data.phone) clientFields['WhatsApp Number'] = data.phone;
    if (addr.street) clientFields.Address = addr.street;
    if (addr.suburb) clientFields.Suburb = addr.suburb;
    if (addr.city) clientFields.City = addr.city;
    if (addr.postal) clientFields['Postal Code'] = addr.postal;
    if (lat != null) clientFields['GPS Latitude'] = lat;
    if (lng != null) clientFields['GPS Longitude'] = lng;
    const maps = googleMapsLink(data.lat, data.lng, addr.full || data.address);
    if (maps) clientFields['Google Maps Link'] = maps;

    const up = await upsertClient(clientFields, data.airtableClientId || null);
    const clientId = up.id;

    const expiry = new Date();
    expiry.setDate(expiry.getDate() + 14);

    const quote = await atPost('Quotes', {
      Client: [clientId],
      'Issue Date': new Date().toISOString().slice(0, 10),
      'Expiry Date': expiry.toISOString().slice(0, 10),
      Status: 'Sent',
      Amount: total,
      Description: [
        data.service || 'Cleaning quote',
        rooms.length ? 'Rooms: ' + rooms.join(', ') : '',
        data.date ? 'Preferred date: ' + data.date : '',
        addr.full || data.address ? 'Address: ' + (addr.full || data.address) : ''
      ].filter(Boolean).join('\n'),
      Active: true,
      Notes: 'App quote ref: ' + appRef + (data.notes ? '\n' + data.notes : '')
    });

    return { clientId, quoteId: quote.id, bookingNumber: appRef };
  }

  async function submitBooking(data) {
    const q = data._quote || {};
    const total = money(data.price != null ? data.price : (data.total != null ? data.total : (q.total || 0)));
    const addr = parseAddress(data.address);
    const rooms = Array.isArray(data.rooms) ? data.rooms : (data.rooms ? [data.rooms] : []);
    const addons = data.extras || data.addons || [];
    const appRef = String(data.bookingNumber || data.id || ('TC' + Date.now()));
    const payStatus = mapPaymentStatus(data.payment_status || data.paymentStatus || 'unpaid');
    const lat = gpsValue(data.lat || (data.location && data.location.lat));
    const lng = gpsValue(data.lng || (data.location && data.location.lng));

    // Normalize access: keyInstr / instructions → Access Instructions
    const access = data.access || {};
    const accessInstructions = access.instructions || access.keyInstr || data.accessInstructions || '';

    const notes = [
      data.notes || data.instructions || '',
      rooms.length ? 'Rooms: ' + rooms.join(', ') : '',
      data.condition ? 'Condition: ' + data.condition : '',
      addons.length ? 'Add-ons: ' + (Array.isArray(addons) ? addons.join(', ') : addons) : '',
      total ? 'Quote total: R' + total.toLocaleString() : '',
      data.payment_method || data.paymentMethod ? 'Payment preference: ' + (data.payment_method || data.paymentMethod) : '',
      'App ref: ' + appRef
    ].filter(Boolean).join('\n');

    const clientFields = {
      Name: data.name || 'Website client',
      Phone: data.phone || undefined,
      'Preferred Contact Method': mapCommMethod(data.commMethod || data.preferredContact),
      Status: 'Booked',
      'Lead Source': 'Website',
      'Customer Type': 'Residential',
      Active: true
    };
    if (data.email) clientFields.Email = data.email;
    if (data.phone) clientFields['WhatsApp Number'] = data.phone;
    if (addr.street) clientFields.Address = addr.street;
    if (addr.suburb) clientFields.Suburb = addr.suburb;
    if (addr.city) clientFields.City = addr.city;
    if (addr.postal) clientFields['Postal Code'] = addr.postal;
    if (addr.province) clientFields.Province = addr.province;
    if (lat != null) clientFields['GPS Latitude'] = lat;
    if (lng != null) clientFields['GPS Longitude'] = lng;
    const clientMaps = googleMapsLink(lat, lng, addr.full || data.address);
    if (clientMaps) clientFields['Google Maps Link'] = clientMaps;

    const up = await upsertClient(clientFields, data.airtableClientId || null);
    const clientId = up.id;

    let propertyId = null;
    try {
      const propFields = {
        Name: addr.street || addr.full || (data.name ? data.name + ' property' : 'Property'),
        'Property Type': mapPropertyType(data.propertyType),
        'Number of Bedrooms': data.bedrooms || rooms.filter(r => /bedroom/i.test(String(r))).length || 1,
        'Number of Bathrooms': data.bathrooms || rooms.filter(r => /bath/i.test(String(r))).length || 1,
        'Street Address': addr.street || addr.full,
        Client: [clientId],
        Pets: !!(data.pets && (data.pets.has || data.pets === true)),
        Active: true
      };
      if (addr.suburb) propFields.Suburb = addr.suburb;
      if (addr.city) propFields.City = addr.city;
      if (addr.postal) propFields['Postal Code'] = addr.postal;
      if (addr.province) propFields.Province = addr.province;
      if (access.gateCode) propFields['Gate Code'] = access.gateCode;
      if (access.parking) propFields['Parking Instructions'] = access.parking;
      if (access.estate) propFields['Security Estate'] = true;
      if (accessInstructions) propFields['Access Instructions'] = accessInstructions;
      if (data.notes || data.instructions) propFields['Special Cleaning Instructions'] = data.notes || data.instructions;
      if (lat != null) propFields['GPS Latitude'] = lat;
      if (lng != null) propFields['GPS Longitude'] = lng;
      const maps = googleMapsLink(lat, lng, addr.full || addr.street);
      if (maps) propFields['Google Maps Link'] = maps;
      const prop = await atPost('Properties', propFields);
      propertyId = prop.id;
    } catch (e) {
      console.warn('Property create failed', e);
    }

    let quoteId = null;
    try {
      const quote = await atPost('Quotes', {
        Client: [clientId],
        'Issue Date': new Date().toISOString().slice(0, 10),
        Status: payStatus === 'Paid' ? 'Converted' : 'Accepted',
        Amount: total,
        Description: (data.service || 'Cleaning') + (rooms.length ? ' · ' + rooms.join(', ') : ''),
        Active: true,
        Notes: 'Created from TerraCelest app · ' + appRef
      });
      quoteId = quote.id;
    } catch (e) {
      console.warn('Quote create failed', e);
    }

    const date = data.date || data.scheduled_date || (data.booking && data.booking.date) || '';
    const time = data.time || data.scheduled_time || (data.booking && (data.booking.time || data.booking.period)) || '';
    const period = (data.booking && data.booking.period) || data.period || '';
    const bookingFields = {
      'Client Name': data.name || 'Website client',
      Location: addr.full || (typeof data.address === 'string' ? data.address : addr.street) || '',
      'Job Type': mapJobType(data.service),
      Status: 'Scheduled',
      Notes: notes,
      Clients: [clientId],
      Active: true,
      Amount: total,
      'Payment Status': payStatus,
      'App Booking Ref': appRef
    };
    if (date) {
      bookingFields.Date = date;
      const start = toStartTimeISO(date, time, period);
      if (start) bookingFields['Start Time'] = start;
    }
    if (propertyId) bookingFields.Property = [propertyId];
    if (quoteId) bookingFields.Quotes = [quoteId];

    const booking = await atPost('Bookings', bookingFields);

    try {
      for (const room of rooms.slice(0, 12)) {
        const roomType = /bath/i.test(room) ? 'Bathroom'
          : /bed/i.test(room) ? 'Bedroom'
          : /kitchen/i.test(room) ? 'Kitchen'
          : /lounge|living/i.test(room) ? 'Living Room'
          : /office|study/i.test(room) ? 'Office'
          : 'Other';
        await atPost('Booking Rooms', {
          'Room Name': String(room),
          'Room Type': roomType,
          Booking: [booking.id],
          Active: true,
          Notes: 'From app booking ' + appRef
        }).catch(function () { return null; });
      }
    } catch (e) { /* non-blocking */ }

    return {
      clientId,
      propertyId,
      quoteId,
      airtableBookingId: booking.id,
      airtableClientId: clientId,
      airtablePropertyId: propertyId,
      bookingNumber: appRef
    };
  }

  async function submitPayment(booking, opts) {
    opts = opts || {};
    const amount = money(opts.amount != null ? opts.amount : (booking.price || booking.total || 0));
    const fields = {
      Amount: amount,
      'Payment Method': mapPaymentMethod(opts.method || booking.payment_method || booking.paymentMethod),
      Status: opts.status || 'Completed',
      'Payment Date': (opts.date || new Date().toISOString().slice(0, 10)),
      Active: true,
      Reference: booking.bookingNumber || booking.id || '',
      Notes: opts.notes || ('App payment for ' + (booking.service || 'cleaning'))
    };
    if (opts.clientRecordId) fields.Client = [opts.clientRecordId];
    else if (booking.airtableClientId) fields.Client = [booking.airtableClientId];
    if (opts.bookingRecordId) fields.Booking = [opts.bookingRecordId];
    else if (booking.airtableBookingId) fields.Booking = [booking.airtableBookingId];

    const payment = await atPost('Payments', fields);
    const bookingRecordId = opts.bookingRecordId || booking.airtableBookingId;
    if (bookingRecordId) {
      try {
        await atPatch('Bookings', bookingRecordId, {
          'Payment Status': opts.status === 'Failed' ? 'Failed' : 'Paid',
          Amount: amount,
          Status: 'Scheduled'
        });
      } catch (e) { console.warn(e); }
    }
    return payment;
  }

  async function submitReview(booking, rating, feedback, tip) {
    const fields = {
      Date: new Date().toISOString().slice(0, 10),
      Rating: Math.min(5, Math.max(1, Number(rating) || 5)),
      Feedback: feedback || '',
      Active: true,
      Notes: tip ? ('Tip: R' + tip) : ''
    };
    if (tip) fields['Tip Amount'] = money(tip);
    if (booking.airtableBookingId) fields.Booking = [booking.airtableBookingId];
    if (booking.airtableClientId) fields.Client = [booking.airtableClientId];
    return atPost('Reviews', fields);
  }

  async function updateBookingStatus(airtableBookingId, status, extraFields) {
    if (!airtableBookingId) return null;
    const map = {
      pending: 'Scheduled', confirmed: 'Scheduled', upcoming: 'Scheduled',
      in_progress: 'In Progress', completed: 'Completed', cancelled: 'Cancelled',
      Scheduled: 'Scheduled', 'In Progress': 'In Progress', Completed: 'Completed', Cancelled: 'Cancelled'
    };
    const fields = Object.assign({ Status: map[status] || status || 'Scheduled' }, extraFields || {});
    // Normalize Start Time if Date/time provided in extra
    if (fields.Date && !fields['Start Time'] && (extraFields && (extraFields.time || extraFields.period))) {
      const start = toStartTimeISO(fields.Date, extraFields.time, extraFields.period);
      if (start) fields['Start Time'] = start;
    }
    return atPatch('Bookings', airtableBookingId, fields);
  }

  async function cancelBooking(airtableBookingId, reason) {
    if (!airtableBookingId) return null;
    const fields = {
      Status: 'Cancelled',
      Active: false
    };
    if (reason) fields['Cancel Reason'] = reason;
    return atPatch('Bookings', airtableBookingId, fields);
  }

  /** Promo lookup with Active + date window + optional usage limit awareness */
  async function findPromo(code) {
    if (!code) return null;
    const formula = "AND({Active}=TRUE(),FIND('" + escFormula(String(code).toUpperCase()) + "',UPPER({Name}&''))>0)";
    try {
      const res = await atGet('Promotions & Discount Codes', { filterByFormula: formula, maxRecords: '5' });
      const recs = res.records || [];
      const today = new Date().toISOString().slice(0, 10);
      for (let i = 0; i < recs.length; i++) {
        const f = recs[i].fields || {};
        if (f['Start Date'] && String(f['Start Date']).slice(0, 10) > today) continue;
        if (f['End Date'] && String(f['End Date']).slice(0, 10) < today) continue;
        const limit = f['Usage Limit'];
        if (limit != null && Number(limit) <= 0) continue;
        return recs[i];
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  async function listServices() {
    const res = await atGet('Services', { filterByFormula: '{Active}=TRUE()', maxRecords: '50' });
    return (res.records || []).map(r => ({
      id: r.id,
      name: r.fields.Name,
      price: r.fields['Base Price'],
      code: r.fields['Service Code'],
      description: r.fields.Description,
      duration: r.fields['Duration (minutes)']
    }));
  }
  async function listAddons() {
    const res = await atGet('Add-on Services', { filterByFormula: '{Active}=TRUE()', maxRecords: '50' });
    return (res.records || []).map(r => ({
      id: r.id,
      name: r.fields.Name,
      price: r.fields.Price,
      description: r.fields.Description
    }));
  }
  async function getBusinessProfile() {
    const res = await atGet('Business Details', { maxRecords: '1' });
    return (res.records && res.records[0] && res.records[0].fields) || null;
  }

  w.TerraAirtable = {
    AT_BASE,
    atPost, atPatch, atGet,
    registerUser, loginUser, updateUser, captureLocation,
    submitBooking, submitQuoteOnly, submitPayment, submitReview, submitUser,
    updateBookingStatus, cancelBooking, findPromo,
    findClientByContact, upsertClient,
    listServices, listAddons, getBusinessProfile,
    mapJobType, mapPaymentMethod, mapPropertyType, mapPaymentStatus,
    parseAddress, googleMapsLink, toStartTimeISO
  };

  w.AT_TOKEN = AT_TOKEN;
  w.AT_BASE = AT_BASE;
  w.AT_HEADERS = AT_HEADERS;
  w.AT_URL = AT_URL;
  w.atPost = atPost;

  w.submitToAirtable = async function () {
    if (typeof data === 'undefined') throw new Error('No booking data');
    const q = typeof calcQuote === 'function' ? calcQuote() : {};
    const payload = Object.assign({}, data, {
      _quote: q,
      price: q.total,
      total: q.total,
      date: data.booking && data.booking.date,
      time: data.booking && (data.booking.time || data.booking.period),
      payment_method: data.paymentMethod,
      payment_status: 'unpaid',
      lat: data.lat,
      lng: data.lng,
      address: data.addressObj || data.address,
      airtableClientId: data.airtableClientId || (function () {
        try {
          const p = JSON.parse(localStorage.getItem('tc_profile') || '{}');
          return p.airtableClientId || null;
        } catch (e) { return null; }
      })()
    });
    const result = await submitBooking(payload);
    return {
      clientId: result.clientId,
      propertyId: result.propertyId,
      quoteId: result.quoteId,
      bookingId: result.airtableBookingId,
      airtableBookingId: result.airtableBookingId,
      airtableClientId: result.clientId,
      airtablePropertyId: result.propertyId,
      bookingNumber: result.bookingNumber || (typeof generateBookingNumber === 'function' ? generateBookingNumber() : ('TC' + Date.now()))
    };
  };
})(window);

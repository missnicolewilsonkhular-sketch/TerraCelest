/**
 * TerraCelest PWA bootstrap — register SW + install prompt
 */
(function () {
  if (!('serviceWorker' in navigator)) return;

  window.addEventListener('load', function () {
    navigator.serviceWorker.register('./sw.js').catch(function (err) {
      console.warn('SW register failed', err);
    });
  });

  let deferredPrompt = null;

  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault();
    deferredPrompt = e;
    document.querySelectorAll('[data-pwa-install]').forEach(function (btn) {
      btn.classList.remove('hide');
      btn.style.display = '';
    });
  });

  window.tcInstallApp = function () {
    if (!deferredPrompt) {
      // iOS does not fire beforeinstallprompt
      const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);
      if (isIOS && window.tcAlert) {
        tcAlert('On iPhone: tap Share → Add to Home Screen to install TerraCelest.', 'Install app');
      } else if (window.tcAlert) {
        tcAlert('Use your browser menu → Install app / Add to Home Screen.', 'Install app');
      }
      return;
    }
    deferredPrompt.prompt();
    deferredPrompt.userChoice.then(function () {
      deferredPrompt = null;
      document.querySelectorAll('[data-pwa-install]').forEach(function (btn) {
        btn.classList.add('hide');
      });
    });
  };

  window.addEventListener('appinstalled', function () {
    deferredPrompt = null;
    document.querySelectorAll('[data-pwa-install]').forEach(function (btn) {
      btn.classList.add('hide');
    });
    if (window.TerraNotifications) {
      TerraNotifications.event({
        type: 'app_installed',
        title: 'TerraCelest installed',
        body: 'You can open TerraCelest from your home screen.',
        role: 'client',
        entityId: 'pwa_install',
        force: true
      });
    }
  });
})();


  function isStandalone() {
    return window.matchMedia('(display-mode: standalone)').matches
      || window.navigator.standalone === true;
  }

  function tcShowInstallModal() {
    if (isStandalone()) return;
    if (localStorage.getItem('tc_install_prompt_dismissed') === '1') return;
    // delay so page settles
    setTimeout(function () {
      if (isStandalone()) return;
      if (document.getElementById('tcInstallModal')) return;
      var overlay = document.createElement('div');
      overlay.id = 'tcInstallModal';
      overlay.style.cssText = 'position:fixed;inset:0;z-index:300;background:rgba(11,29,58,0.5);display:flex;align-items:flex-end;justify-content:center;padding:16px;';
      overlay.innerHTML = '<div style="background:#fff;border-radius:20px 20px 16px 16px;width:min(420px,100%);padding:24px 20px 20px;box-shadow:0 -8px 40px rgba(0,0,0,.2)">' +
        '<div style="text-align:center;margin-bottom:12px"><img src="icons/icon-96.png" alt="" width="64" height="64" style="border-radius:16px"/></div>' +
        '<h3 style="margin:0 0 8px;font-size:1.15rem;color:#0B1D3A;text-align:center">Install TerraCelest</h3>' +
        '<p style="margin:0 0 18px;font-size:0.92rem;color:#3F4946;text-align:center;line-height:1.45">Add the app to your home screen for faster booking and live cleaner tracking.</p>' +
        '<button type="button" id="tcInstallNow" style="width:100%;min-height:48px;border:none;border-radius:999px;background:#00A69C;color:#fff;font-weight:700;font-size:1rem;margin-bottom:10px">Install app</button>' +
        '<button type="button" id="tcInstallLater" style="width:100%;min-height:44px;border:none;background:transparent;color:#6F7976;font-weight:600">Not now</button>' +
        '</div>';
      document.body.appendChild(overlay);
      document.getElementById('tcInstallNow').onclick = function () {
        overlay.remove();
        if (window.tcInstallApp) tcInstallApp();
      };
      document.getElementById('tcInstallLater').onclick = function () {
        localStorage.setItem('tc_install_prompt_dismissed', '1');
        overlay.remove();
      };
    }, 2500);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', tcShowInstallModal);
  } else {
    tcShowInstallModal();
  }
  window.tcShowInstallModal = tcShowInstallModal;

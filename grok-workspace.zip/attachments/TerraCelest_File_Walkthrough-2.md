# TerraCelest — File-by-File Walkthrough

**Version:** 1.3  
**Purpose:** Full list of features, customisation points, and upgrades to make the app more user-friendly, professional, and easy to use.

---

## Contents

1. [index.html](#indexhtml--shell--structure)
2. [login.js](#loginjs--auth--pin)
3. [settings.js](#settingsjs--settings-drawer)
4. [app.js](#appjs--core-application)
5. [css/tokens.css](#csstokenscss--design-system)
6. [css/splash.css](#csssplashcss)
7. [css/login.css](#csslogincss)
8. [css/shell.css](#cssshellcss)
9. [css/drawers.css](#cssdrawerscss)
10. [css/modal.css](#cssmodalcss)
11. [css/components.css](#csscomponentscss)
12. [css/interactions.css](#cssinteractionscss)
13. [css/polish.css](#csspolishcss)
14. [css/settings.css](#csssettingscss)
15. [assets/logo-tc.png](#assetslogo-tcpng)
16. [style.css (legacy)](#stylecss-legacy)
17. [Cross-cutting upgrades](#cross-cutting-upgrades-highest-roi)
18. [File map by goal](#what-each-file-is-for-when-you-customise)
19. [Definition of done](#professional-definition-of-done-checklist)
20. [Suggested order of work](#suggested-order-of-work)

---

## `index.html` — Shell & structure

### What it is

The single HTML shell: splash, login, app header, drawers, bottom nav, FAB, modals, snackbar, script/CSS load order.

### Features already here

- Splash checklist UI
- Login card + user dropdown + PIN keypad markup
- App header, side drawer, right drawer, bottom sheet
- Bottom nav: Home / Office / FAB / Updates / Menu
- Confirm modal + undo snackbar
- Theme applied before paint (inline script)

### Customisations you can apply

| Area | What to change | Why it helps |
|------|----------------|--------------|
| Page title / meta | App name, description, theme-color | Looks pro when bookmarked |
| Favicon + PWA manifest | Icons, `manifest.json`, “Add to Home Screen” | Feels like a real product |
| Bottom nav labels | Shorter or clearer labels | Faster recognition |
| FAB aria-label | Dynamic labels in HTML placeholders | Accessibility |
| Splash steps copy | “Airtable schema” → “Loading your tables” | Less technical for staff |
| Login foot text | Support phone / WhatsApp | Self-serve help |
| Drawer footer | Settings + Logout order, extra links | Clearer account area |

### Upgrade ideas

1. Add `<link rel="manifest">` and apple-touch-icon.
2. Soften splash step labels (user language, not engineer language).
3. Add a “Forgot PIN? Contact admin” line under the keypad.
4. Keep script order fixed: `login.js → settings.js → app.js`.

---

## `login.js` — Auth & PIN

### What it is

Users, PIN check, session TTL, logout, user dropdown, PIN keypad logic.

### Features

- Hardcoded users + PINs
- 10-minute session (`AUTH_TTL_MS`)
- In-app user list + PIN dots/keypad
- Auto-login at 4 digits
- Clears PIN on fail / logout

### Customisations

| Item | How | UX win |
|------|-----|--------|
| `USERS` map | Names, PINs, icons | Real staff accounts |
| `AUTH_TTL_MS` | e.g. 8 hours for field day | Fewer re-logins |
| Error copy | Friendlier messages | Less stress on fail |
| Auto-submit | On/off after 4 digits | Preference |

### Upgrade ideas

1. Show selected user’s **name** above the PIN dots.
2. Shake animation on wrong PIN (CSS class).
3. Lock after N failed attempts (simple counter).
4. Later: move users out of client code (proxy / Airtable Team table).
5. Don’t store long-lived secrets in the frontend for production.

---

## `settings.js` — Settings drawer

### What it is

Theme, language, currency, sync interval; About & Help modals; logout.

### Features

- In-app fuzzy dropdowns (no native selects)
- About / Get Help centred modals
- Writes to `localStorage` (`tc_theme`, `tc_lang`, etc.)

### Customisations

| Item | Change | Effect |
|------|--------|--------|
| Theme options | Labels, default | Match brand language |
| Language list | Add/remove locales | Regional rollout |
| Currency list | ZAR default, symbols | Finance clarity |
| Sync intervals | 5 / 10 / 30 / off | Data freshness vs battery |
| About body | Version + feature bullets | Trust / “what’s new” |
| Help contacts | Phone, email, WhatsApp | Support path |

### Upgrade ideas

1. Show **current version** (v1.3) and last sync time.
2. “Reset preferences” button.
3. Preview theme swatches (colour chips), not only names.
4. Help modal: direct `tel:` / `https://wa.me/` links.
5. Optional “Demo mode” toggle for training.

---

## `app.js` — Core application

Largest file: Airtable, pages, forms, uploads, budget, navigation, cache, UX helpers.

### A. Config & constants (top)

**Customise:** token/base (prefer env/proxy later), currency map, row heights, buffer sizes.

**Upgrade:** never ship long-lived PAT in public client; add a thin API proxy.

### B. Utilities (`$`, `icon`, `fmtR`, `esc`, status, skeleton, timeAgo, snackbar)

**Features:** status toasts, contextual skeletons, relative time, undo snackbar.

**Upgrade:**

- Toast variants: success / warning / error colours
- Skeleton copy per page (already partly done)
- Longer undo window for deletes (5–8s)

### C. Airtable layer (`atFetch`, `atPost`, `atPatch`, archive/restore)

**Features:** soft-delete for budget; hard-delete for tables.

**Upgrade:**

- Central error mapper → friendly messages
- Retry once on network fail
- “Last synced” timestamp in toolbar

### D. Schema & linked names (`loadSchema`, `loadTableNames`, `LinkedRecordPicker`)

**Features:** dynamic tables, fuzzy link pickers, name resolution.

**Customise:** preferred name fields list; secondary fields (Job Title, Email).

**Upgrade:**

- `TABLE_UI` map: list / detail / form fields per table
- Prefetch only tables user can open
- Empty linked-dropdown: “No matches — create new”

### E. Budget

**Features:** list/grid/group, search, archive/restore, bulk archive + progress + undo, CSV export, image upload.

**Upgrade:**

- Export column picker
- Clear “Archived” toggle visibility
- Chip filters (category / store / purchased)
- Empty state: “Add your first budget line” + button

### F. Dynamic forms (`isWritableField`, `fieldInputHtml`, `openDynamicForm`, save)

**Features:** schema-driven create/edit; attachments with compression; result modals.

**Customise:** skip-types list; required markers from Airtable.

**Upgrade:**

- Accordion sections for long tables (Team Members)
- Live validation (email / phone / required)
- Remember last Category/Status defaults
- Sticky Save/Cancel on the drawer
- Hide formula/lookup on form (already); show them read-only on detail

### G. Titles (`recordTitle`)

**Features:** Full Name, Name, First+Last; no bare “Record”.

**Customise:** preferred field order per industry (Invoice Number, Booking No.).

**Upgrade:** pass `tableName` everywhere status/delete/search is shown (mostly done).

### H. Table pages (`renderTablePage`, sheet, delete)

**Features:** cards, search, detail sheet, hard delete, soft-delete filter.

**Upgrade:**

- Card layout: title + one meta + status chip only
- Detail sheet: grouped sections + sticky actions
- Confirm delete with typed name for critical tables
- Preserve scroll position after edit

### I. Home / Office / Updates

**Features:** stats, recent activity, Office grid + last table highlight, updates badge.

**Upgrade:**

- Home: actionable shortcuts (“Open Documents”, “Today’s bookings”)
- Office: search tables, favourites pin
- Updates: filter by type, clear-all

### J. Navigation & FAB

**Features:** bottom nav, drawer groups including Knowledge (Documents, Scripts).

**Customise:** group names and table lists.

**Upgrade:**

- FAB label by context (“Add document”)
- Menu = profile/settings only; Office = all tables (reduce overlap)

### K. Keyboard shortcuts

**Features:** Esc, Ctrl/Cmd+K/N/S.

**Upgrade:** small “?” shortcuts cheatsheet in Settings.

### L. Splash sequence

**Features:** progress + steps; theme applied early.

**Upgrade:** user-friendly step labels; hide technical errors behind “Retry”.

---

## `css/tokens.css` — Design system

### What it is

Colours, themes (default/light/dark/iOS), radii, elevation, fonts (Montserrat).

### Customise

- Brand primary/secondary/aqua
- Surface greys for readability
- `--nav-h`, safe-area, radius scale

### Upgrade

1. One spacing scale (4/8/12/16/24).
2. Status semantic colours: success / warning / danger / info.
3. Focus ring token for keypad and buttons.
4. Keep iOS theme Apple blue; keep brand teal on Default.

---

## `css/splash.css`

### Features

Theme-aware splash backgrounds and checklist colours.

### Upgrade

- Subtle logo fade-in
- Reduce motion if `prefers-reduced-motion`

---

## `css/login.css`

### Features

Login card, user dropdown, PIN dots, keypad.

### Upgrade

- Key targets ≥ 48px (already ~52px)
- Keypad haptic-style active state
- Error shake on `.login-card`
- Light/iOS logo contrast (already partially handled)

---

## `css/shell.css`

### Features

Header, bottom nav, FAB, glass/nav treatment.

### Upgrade

- Active nav indicator (dot or bold + teal)
- FAB pulse only on first load (already considered)
- Safe-area padding audit on notched phones

---

## `css/drawers.css`

### Features

Side drawer, right form drawer.

### Upgrade

- Form drawer full-height on small phones with sticky footer actions
- Drawer section headers for long nav lists

---

## `css/modal.css`

### Upgrade

- Danger vs neutral button roles
- Prevent double-tap on Confirm

---

## `css/components.css`

### Features

Cards, chips, fields, lists, virtual rows.

### Upgrade

- Record card: less meta clutter
- Status chips
- Empty-state component class
- Consistent 44px hit areas

---

## `css/interactions.css`

### Features

Pull-to-refresh, selection, presses.

### Upgrade

- Clearer PTR threshold feedback
- Selection bar contrast

---

## `css/polish.css`

### Features

Gradients, FAB pulse, snackbar, skeletons, small motion.

### Upgrade

- Shared `.toast` / `.snackbar` styles
- Hover only on `@media (hover:hover)`

---

## `css/settings.css`

### Features

Settings groups and items.

### Upgrade

- Larger taps
- Theme preview swatches
- Version line styling

---

## `assets/logo-tc.png`

### Usage

Splash, login, drawer, PDFs.

### Upgrade

- SVG version for crispness
- Dark/light logo variants if needed

---

## `style.css` (legacy)

### What it is

Older monolithic stylesheet; modular CSS under `css/` is preferred.

### Upgrade

Stop adding new rules here; migrate leftovers into `components` / `shell` / `polish`, then remove if unused.

---

## Cross-cutting upgrades (highest ROI)

### Easy (days)

1. **Card redesign** — title + 1 line + status chip (`components.css` + `renderTablePage`).
2. **Empty states** with one CTA per list.
3. **Friendly splash/login copy** (`index.html`).
4. **Settings version + last sync**.
5. **TABLE_UI config** in `app.js` for list/detail/form fields.
6. **Sectioned Team Members form**.

### Medium

7. Sticky form actions + live validation.
8. Office table search + favourites.
9. Delete confirm with record name (done) + optional “Recently deleted”.
10. Export options for budget.

### Structural

11. Proxy for Airtable token.
12. PWA manifest + offline read cache.
13. Split `app.js` further (`tables.js`, `budget.js`, `uploads.js`).

---

## What each file is for when you customise

| Goal | Primary files |
|------|----------------|
| Look & brand | `tokens.css`, `polish.css`, `splash.css`, `login.css`, logo |
| Login feel | `login.js`, `login.css`, `index.html` |
| Settings / About | `settings.js`, `settings.css` |
| Which fields show | `app.js` (`recordTitle`, `renderTablePage`, form filters) → then `TABLE_UI` |
| Navigation | `index.html` nav, `app.js` groups + `navigateTo` |
| Uploads | `app.js` `uploadAttachment` + compress |
| Safety (delete/undo) | `app.js` delete/archive + snackbar |
| Performance feel | skeletons, cache TTL, PTR in `app.js` |

---

## Professional “definition of done” checklist

- [ ] Every list item has a **human title**
- [ ] Every empty screen has a **next action**
- [ ] Forms never show 40 fields at once
- [ ] Destructive actions name the record + allow undo or clear confirm
- [ ] Theme applies to splash **and** login
- [ ] PIN is keypad-first on mobile
- [ ] Status/sync visible without opening Settings
- [ ] No raw Airtable jargon in staff-facing copy
- [ ] Token not required in public repo for production

---

## Suggested order of work

1. **Visual clarity** — cards, empty states, status chips (`components.css` + table renderer).
2. **Field control** — `TABLE_UI` so Documents/Team/Clients show only useful fields.
3. **Long forms** — sections for Team Members.
4. **Copy** — splash, errors, About (`index.html`, `login.js`, `settings.js`).
5. **Trust** — last synced, undo, safer deletes.
6. **Architecture** — split `app.js`, proxy API, PWA.

---

## Record flow (all tables)

1. **List** — cards with real titles (Full Name, Name, etc.)
2. **Detail** — tap card → bottom sheet
3. **Edit** — form in the right drawer
4. **Save** — Airtable PATCH/POST → optional attachment upload → result modal
5. **Delete** — hard DELETE + cache clear (does not reappear on sync)

---

## Knowledge tables

| Table | Purpose |
|-------|---------|
| **Documents** | Name, Category, Description, File, Status, Version, Notes |
| **Scripts** | Name, Type, Audience, Script Body, Status, Attachments, Notes |

---

## Keyboard shortcuts (desktop)

| Shortcut | Action |
|----------|--------|
| `Esc` | Close modal, sheet, or drawer |
| `Ctrl/Cmd + K` | Focus search |
| `Ctrl/Cmd + N` | New record (FAB) |
| `Ctrl/Cmd + S` | Save open form |

---

## Brand palette

| Token | Hex |
|-------|-----|
| Teal | `#00A69C` |
| Navy | `#0B1D3A` |
| Aqua | `#35C1BC` |
| Slate | `#222B45` |

**Tagline:** Clean spaces. Better places.

---

*TerraCelest Facilities · Internal handbook · v1.3*

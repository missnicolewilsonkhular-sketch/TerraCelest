/**
 * TerraCelest Booking — Persistence (Airtable + local)
 * Note: Prefer window.TerraAirtable from airtable.js when available.
 */
(function (w) {
  'use strict';
  var TC = w.TCBooking = w.TCBooking || {};

  // Fallback direct AT config (same as original MVP — move to backend in production)
  TC.AT_TOKEN = (w.AT_TOKEN) || 'patYoMBcrqk1xCC9G.123b09512a984a1c522f58e864b531dc9b8e8f9244772166ecf540a8fde7cfc8';
  TC.AT_BASE = 'appgzWiwsyL0qAisg';
  TC.AT_HEADERS = { 'Authorization': 'Bearer ' + TC.AT_TOKEN, 'Content-Type': 'application/json' };
  TC.AT_URL = 'https://api.airtable.com/v0/' + TC.AT_BASE;

TC.atPost = async function(table, fields) {
  const res = await fetch(TC.AT_URL + '/' + encodeURIComponent(table), {
    method: 'POST',
    headers: TC.AT_HEADERS,
    body: JSON.stringify({ fields, typecast: true })
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(table + ' create failed: ' + res.status + ' ' + body.slice(0, 200));
  }
  return res.json();
}

TC.mapJobType = function(service) {
  const s = (service || '').toLowerCase();
  if (s.includes('deep')) return 'Deep Clean';
  if (s.includes('standard') || s.includes('recurring') || s.includes('once')) return 'Standard Clean';
  return 'Other';
}

TC.mapPropertyType = function(t) {
  const m = { 'House': 'House', 'Apartment': 'Apartment', 'Townhouse': 'Duplex', 'Cottage': 'Other' };
  return m[t] || 'House';
}

TC.parseAddress = function(addr) {
  // Best-effort split: "Street, Suburb, City"
  const parts = (addr || '').split(',').map(p => p.trim()).filter(Boolean);
  return {
    street: parts[0] || addr || '',
    suburb: parts[1] || '',
    city: parts[2] || parts[1] || ''
  };
}

TC.submitToAirtable = async function() {
  // Delegate to shared TerraAirtable client (airtable.js)
  if (window.TerraAirtable && typeof TerraAirtable.submitBooking === 'function') {
    const q = typeof calcQuote === 'function' ? TC.calcQuote() : {};
    let profileClientId = null;
    try {
      const profile = JSON.parse(localStorage.getItem('tc_profile') || '{}');
      profileClientId = profile.airtableClientId || null;
    } catch (_) {}
    const payload = Object.assign({}, TC.data, {
      _quote: q,
      price: q.total,
      total: q.total,
      date: TC.data.booking && TC.data.booking.date,
      time: TC.data.booking && (TC.data.booking.time || TC.data.booking.period),
      payment_method: TC.data.paymentMethod,
      notes: TC.data.instructions,
      airtableClientId: TC.data.airtableClientId || profileClientId
    });
    const result = await TerraAirtable.submitBooking(payload);
    return {
      clientId: result.clientId,
      propertyId: result.propertyId,
      bookingId: result.airtableBookingId,
      airtableBookingId: result.airtableBookingId,
      airtableClientId: result.clientId,
      airtablePropertyId: result.propertyId,
      bookingNumber: TC.data.bookingNumber || (typeof generateBookingNumber === 'function' ? TC.generateBookingNumber() : result.bookingNumber)
    };
  }
  // Fallback: use local atPost if airtable.js missing
  throw new Error('TerraAirtable not loaded');
}

TC.setSubmitting = function(on) {
  const next = TC.$('btnNext');
  const back = TC.$('btnBack');
  if (on) {
    next.disabled = true;
    back.disabled = true;
    next.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Saving to TerraCelest…';
  } else {
    next.disabled = false;
    back.disabled = false;
  }
}

TC.showSubmitError = function(msg) {
  let el = document.getElementById('submitError');
  if (!el) {
    el = document.createElement('div');
    el.id = 'submitError';
    el.style.cssText = 'background:#FEE2E2;color:#991B1B;padding:12px 14px;border-radius:12px;margin:12px 0;font-size:0.88rem;line-height:1.4';
    TC.$('content').prepend(el);
  }
  el.textContent = msg;
}

})(window);

/**
 * TerraCelest Booking — Step UI builders & events
 */
(function (w) {
  'use strict';
  var TC = w.TCBooking = w.TCBooking || {};

TC.buildStepHTML = function(key) {
  switch (key) {
    case 'welcome': return `
      <div class="step active">
        <div class="welcome-hero">
          <div class="welcome-logo"><img src="logo.png" alt="TerraCelest" style="width:56px;height:56px;object-fit:contain;"></div>
          <h1>Welcome to TerraCelest</h1>
          <p>We're happy to help you keep your home clean. I'll guide you through a few quick steps to prepare your quotation and booking.</p>
        </div>
        <div class="callout">
          <strong>Booking only takes a few minutes.</strong><br>
          Tell us about your home, choose your service, and we'll prepare a clear quote — no obligation.
        </div>
        <div class="section-label">How can we help?</div>
        <div class="choice-grid cols-1">
          <div class="choice selected" TC.data-help="quote"><i class="fa-solid fa-file-invoice"></i> Get a free quote</div>
          <div class="choice" TC.data-help="book"><i class="fa-solid fa-calendar-check"></i> Book a cleaning</div>
        </div>
      </div>`;

    case 'account': return `
      <div class="step active">
        <div class="step-icon"><i class="fa-solid fa-user-circle"></i></div>
        <h2>How would you like to continue?</h2>
        <p class="lead">Guest is the fast path. Sign in if you already have an account, or create one to save details.</p>
        <div class="account-grid" id="accountChoices">
          <div class="account-option${TC.data.accountMode==='guest'?' selected':''}" TC.data-val="guest">
            <i class="fa-solid fa-bolt main"></i>
            <div>
              <div class="acc-title">Continue as guest</div>
              <div class="acc-desc">Fastest — no password, book in minutes</div>
            </div>
          </div>
          <div class="account-option${TC.data.accountMode==='login'?' selected':''}" TC.data-val="login">
            <i class="fa-solid fa-right-to-bracket main"></i>
            <div>
              <div class="acc-title">Log in</div>
              <div class="acc-desc">Go straight to your dashboard</div>
            </div>
          </div>
          <div class="account-option${TC.data.accountMode==='create'?' selected':''}" TC.data-val="create">
            <i class="fa-solid fa-user-plus main"></i>
            <div>
              <div class="acc-title">Create an account</div>
              <div class="acc-desc">Save property, preferences &amp; history</div>
            </div>
          </div>
        </div>
        <div class="account-fields${(TC.data.accountMode==='create'||TC.data.accountMode==='login')?'':' hidden'}" id="accountFields">
          <div class="field">
            <label>Email</label>
            <input type="email" id="inpAccEmail" placeholder="you@email.com" value="${TC.esc(TC.data.accountEmail || TC.data.email)}"/>
          </div>
          <div class="field">
            <label>Password <span class="opt">${TC.data.accountMode==='create'?'(min 6 characters)':''}</span></label>
            <input type="password" id="inpAccPassword" placeholder="${TC.data.accountMode==='login'?'Your password':'Choose a password'}" value="${TC.esc(TC.data.accountPassword)}"/>
          </div>
          <div class="callout" id="accountHint">${
            TC.data.accountMode==='login'
              ? 'Enter the email and password you used when you signed up. You’ll go straight to your dashboard.'
              : 'Account creation is optional and never blocks checkout. You can also create one after booking.'
          }</div>
          <a href="#" id="resetPasswordLink" style="display:block;text-align:center;margin-top:12px;font-size:0.82rem;color:var(--text-3);font-weight:500">Reset my password</a>
        </div>
      </div>`;

    case 'details': return `
      <div class="step active">
        <div class="step-icon"><i class="fa-solid fa-user"></i></div>
        <h2>Your details</h2>
        <p class="lead">So we can prepare your quote and stay in touch.</p>
        <div class="field" id="fName">
          <label>Full Name *</label>
          <input type="text" id="inpName" placeholder="e.g. Sarah Mokoena" value="${TC.esc(TC.data.name)}"/>
          <div class="field-error">Please enter your full name</div>
        </div>
        <div class="field" id="fPhone">
          <label>Mobile Number *</label>
          <input type="tel" id="inpPhone" placeholder="e.g. 082 123 4567" value="${TC.esc(TC.data.phone)}"/>
          <div class="field-error">Please enter a valid mobile number</div>
        </div>
        <div class="field">
          <label>Email Address <span class="opt">(optional)</span></label>
          <input type="email" id="inpEmail" placeholder="you@email.com" value="${TC.esc(TC.data.email)}"/>
        </div>
        <div class="field" id="fAddress">
          <label>Property Address *</label>
          <button type="button" class="btn btn-secondary" id="btnUseLocation" onclick="TC.useMyLocation()" style="width:100%;margin-bottom:10px;min-height:44px"><i class="fa-solid fa-location-crosshairs"></i> Use my location</button>
          <input type="text" id="inpAddress" placeholder="Street number, Street, Suburb, City, Postal code" value="${TC.esc(TC.data.address)}"/>
          <div class="field-error">Please enter the property address</div>
        </div>
        <div class="section-label">Preferred communication</div>
        <div class="choice-grid cols-3" id="commChoices">
          ${['WhatsApp','Phone','Email'].map(c =>
            `<div class="choice${TC.data.commMethod===c?' selected':''}" TC.data-val="${c}"><i class="fa-solid fa-${c==='WhatsApp'?'brands fa-whatsapp':c==='Phone'?'phone':'envelope'}"></i>${c}</div>`
          ).join('')}
        </div>
      </div>`;

    case 'service': return `
      <div class="step active">
        <div class="step-icon"><i class="fa-solid fa-broom"></i></div>
        <h2>Which service do you need?</h2>
        <p class="lead">Select the type of cleaning. Pricing is calculated on your quote after you choose rooms and add-ons.</p>
        <div class="choice-grid" id="serviceChoices">
          ${Object.keys(TC.SERVICE_PRICES).map(s =>
            `<div class="choice${TC.data.service===s?' selected':''}" TC.data-val="${s}">
              <i class="fa-solid fa-${s.includes('Deep')||s.includes('Move')?'sparkles':'broom'}"></i>
              ${s}
              ${s==='Standard Cleaning'?'<span class="choice-badge">Popular</span>':''}
            </div>`
          ).join('')}
        </div>
        <div class="callout">No problem if you're unsure — continue and we'll ask a few questions to recommend the best service.</div>
      </div>`;

    case 'property': return `
      <div class="step active">
        <div class="step-icon"><i class="fa-solid fa-house"></i></div>
        <h2>Tell us about the property</h2>
        <p class="lead">This helps us estimate time and team size accurately.</p>
        <div class="section-label">Property type</div>
        <div class="choice-grid" id="propTypeChoices">
          ${['House','Apartment','Townhouse','Cottage'].map(t =>
            `<div class="choice${TC.data.propertyType===t?' selected':''}" TC.data-val="${t}"><i class="fa-solid fa-${t==='Apartment'?'building':'house'}"></i>${t}</div>`
          ).join('')}
        </div>
        <div class="field-row" style="margin-top:16px">
          <div class="field">
            <label>Bedrooms</label>
            <select id="inpBedrooms">${[1,2,3,4,5,6].map(n=>`<option value="${n}"${TC.data.bedrooms===n?' selected':''}>${n}</option>`).join('')}</select>
          </div>
          <div class="field">
            <label>Bathrooms</label>
            <select id="inpBathrooms">${[1,2,3,4,5].map(n=>`<option value="${n}"${TC.data.bathrooms===n?' selected':''}>${n}</option>`).join('')}</select>
          </div>
        </div>
        <div class="section-label" style="margin-top:20px">Are there any pets in the house?</div>
        <div class="choice-grid" id="petHas">
          <div class="choice${TC.data.pets.has===true?' selected':''}" TC.data-val="yes"><i class="fa-solid fa-paw"></i> Yes</div>
          <div class="choice${TC.data.pets.has===false?' selected':''}" TC.data-val="no"><i class="fa-solid fa-ban"></i> No pets</div>
        </div>
        <div id="petTypes" class="${TC.data.pets.has?'':'hidden'}" style="margin-top:16px">
          <div class="section-label">Which pets?</div>
          <div class="check-list" id="petTypeList">
            ${['Dogs','Cats','Birds','Other'].map(p =>
              `<div class="check-item${TC.data.pets.types.includes(p)?' selected':''}" TC.data-val="${p}">
                <div class="check-box"><i class="fa-solid fa-check"></i></div>
                <span class="check-label">${p}</span>
              </div>`
            ).join('')}
          </div>
          <div class="field" style="margin-top:12px">
            <label>Additional notes about pets</label>
            <textarea id="inpPetNotes" rows="3" placeholder="e.g. Friendly dog in the garden, please keep the bedroom door closed">${TC.esc(TC.data.pets.notes||'')}</textarea>
          </div>
        </div>
      </div>`;

    case 'rooms': return `
      <div class="step active">
        <div class="step-icon"><i class="fa-solid fa-door-open"></i></div>
        <h2>Which rooms need cleaning?</h2>
        <p class="lead">Select the rooms you'd like cleaned. Your base rate covers up to ${TC.INCLUDED_ROOMS} rooms; extra rooms are priced on the quote.</p>
        <div class="check-list" id="roomList">
          ${TC.ROOM_LIST.map(r =>
            `<div class="check-item${TC.data.rooms.includes(r)?' selected':''}" TC.data-val="${r}">
              <div class="check-box"><i class="fa-solid fa-check"></i></div>
              <span class="check-label">${r}</span>
            </div>`
          ).join('')}
        </div>
      </div>`;

    case 'condition': return `
      <div class="step active">
        <div class="step-icon"><i class="fa-solid fa-spray-can-sparkles"></i></div>
        <h2>Room condition</h2>
        <p class="lead">How would you describe the overall condition?</p>
        <div class="condition-options" id="condChoices">
          ${Object.keys(TC.CONDITION_MULT).map(c =>
            `<div class="check-item${TC.data.condition===c?' selected':''}" TC.data-val="${c}">
              <div class="check-box"><i class="fa-solid fa-check"></i></div>
              <span class="check-label">${c}</span>
              <span class="check-price">${TC.CONDITION_MULT[c]===1?'Standard':TC.CONDITION_MULT[c]<1?'−15%':'+'+Math.round((TC.CONDITION_MULT[c]-1)*100)+'%'}</span>
            </div>`
          ).join('')}
        </div>
      </div>`;

    case 'products': return `
      <div class="step active">
        <div class="step-icon"><i class="fa-solid fa-flask"></i></div>
        <h2>Cleaning products</h2>
        <p class="lead">We bring professional-grade supplies. You can adjust preferences below.</p>
        <div class="check-list" id="prodList">
          ${[
            {k:'chemicals', label:'Cleaning chemicals', desc:'Eco-friendly detergents & disinfectants'},
            {k:'equipment', label:'Equipment', desc:'Vacuum, mop, buckets, brushes'},
            {k:'cloths', label:'Cloths & microfibre', desc:'Colour-coded cloths per area'},
            {k:'accessories', label:'Extra accessories', desc:'Scrub pads, gloves, specialty tools'}
          ].map(p =>
            `<div class="check-item${TC.data.products[p.k]?' selected':''}" TC.data-val="${p.k}">
              <div class="check-box"><i class="fa-solid fa-check"></i></div>
              <div style="flex:1"><div class="check-label">${p.label}</div>
              <div style="font-size:0.78rem;color:var(--text-3);margin-top:2px">${p.desc}</div></div>
            </div>`
          ).join('')}
        </div>
        <div class="callout">Quantities are calculated automatically from room size and condition.</div>
      </div>`;

    case 'addons': {
      const suggestions = [];
      TC.data.rooms.forEach(r => {
        (TC.UPSELL_MAP[r] || []).forEach(a => {
          if (!suggestions.includes(a)) suggestions.push(a);
        });
      });
      const suggestedSet = new Set(suggestions);
      const upsellHtml = suggestions.filter(a => !TC.data.addons.includes(a)).length ? `
        <div class="upsell" id="upsellBox">
          <h4><i class="fa-solid fa-lightbulb"></i> Suggested for your rooms</h4>
          <p>Based on the rooms you selected — one tap to add:</p>
          <div class="upsell-actions">
            ${suggestions.filter(a => !TC.data.addons.includes(a)).slice(0, 4).map(a =>
              `<button type="button" class="upsell-chip" TC.data-addon="${a}">${a} · +R${TC.ADDON_PRICES[a]}</button>`
            ).join('')}
          </div>
        </div>` : '';
      return `
      <div class="step active">
        <div class="step-icon"><i class="fa-solid fa-plus-circle"></i></div>
        <h2>Add-on services</h2>
        <p class="lead">Optional extras to make your clean even more thorough.</p>
        ${upsellHtml}
        <div class="check-list" id="addonList">
          ${Object.keys(TC.ADDON_PRICES).map(a =>
            `<div class="check-item${TC.data.addons.includes(a)?' selected':''}" TC.data-val="${a}">
              <div class="check-box"><i class="fa-solid fa-check"></i></div>
              <span class="check-label">${a}${suggestedSet.has(a)?'<span class="tag-suggested">Suggested</span>':''}</span>
              <span class="check-price">+R${TC.ADDON_PRICES[a]}</span>
            </div>`
          ).join('')}
        </div>
      </div>`;
    }

    case 'pets': return `
      <div class="step active">
        <div class="step-icon"><i class="fa-solid fa-paw"></i></div>
        <h2>Any pets at home?</h2>
        <p class="lead">This helps our team prepare and take extra care.</p>
        <div class="choice-grid" id="petHas">
          <div class="choice${TC.data.pets.has===true?' selected':''}" TC.data-val="yes"><i class="fa-solid fa-paw"></i> Yes</div>
          <div class="choice${TC.data.pets.has===false?' selected':''}" TC.data-val="no"><i class="fa-solid fa-ban"></i> No pets</div>
        </div>
        <div id="petTypes" class="${TC.data.pets.has?'':'hidden'}" style="margin-top:16px">
          <div class="section-label">Which pets?</div>
          <div class="check-list" id="petTypeList">
            ${['Dogs','Cats','Birds','Other'].map(p =>
              `<div class="check-item${TC.data.pets.types.includes(p)?' selected':''}" TC.data-val="${p}">
                <div class="check-box"><i class="fa-solid fa-check"></i></div>
                <span class="check-label">${p}</span>
              </div>`
            ).join('')}
          </div>
        </div>
      </div>`;

    case 'access': return `
      <div class="step active">
        <div class="step-icon"><i class="fa-solid fa-key"></i></div>
        <h2>Access information</h2>
        <p class="lead">So our team can arrive smoothly and on time.</p>
        <div class="field"><label>Gate / Access Code</label>
          <input type="text" id="inpGate" placeholder="e.g. 1234#" value="${TC.esc(TC.data.access.gateCode)}"/></div>
        <div class="field"><label>Security Estate / Complex</label>
          <input type="text" id="inpEstate" placeholder="Estate name" value="${TC.esc(TC.data.access.estate)}"/></div>
        <div class="field-row">
          <div class="field"><label>Apartment / Unit No.</label>
            <input type="text" id="inpApt" placeholder="e.g. 12B" value="${TC.esc(TC.data.access.aptNumber)}"/></div>
          <div class="field"><label>Floor</label>
            <input type="text" id="inpFloor" placeholder="e.g. 3" value="${TC.esc(TC.data.access.floor)}"/></div>
        </div>
        <div class="field"><label>Parking instructions</label>
          <input type="text" id="inpParking" placeholder="Visitor bay, street parking…" value="${TC.esc(TC.data.access.parking)}"/></div>
        <div class="field"><label>Key collection instructions</label>
          <textarea id="inpKeys" placeholder="e.g. Keys under mat / collect from reception">${TC.esc(TC.data.access.keyInstr)}</textarea></div>
        <div class="section-label">Will someone be present?</div>
        <div class="choice-grid" id="someonePresent">
          <div class="choice${TC.data.access.someonePresent?' selected':''}" TC.data-val="yes"><i class="fa-solid fa-user-check"></i> Yes</div>
          <div class="choice${!TC.data.access.someonePresent?' selected':''}" TC.data-val="no"><i class="fa-solid fa-user-xmark"></i> No</div>
        </div>
        <div class="field" style="margin-top:12px"><label>Contact person on site</label>
          <input type="text" id="inpContactSite" placeholder="Name & number" value="${TC.esc(TC.data.access.contactOnSite)}"/></div>
      </div>`;

    case 'booking': {
      const flexOpen = !!TC.data.booking.flexible;
      const slotsHtml = TC.FLEXIBLE_SLOTS.map((s, i) => {
        const date = TC.formatSlotDate(s.dateOffset);
        const selected = TC.data.booking.flexible && TC.data.booking.date === date && TC.data.booking.time === s.time;
        return `<div class="check-item${selected?' selected':''}" TC.data-flex-slot="${i}">
          <div class="check-box"><i class="fa-solid fa-check"></i></div>
          <span class="check-label">${s.label}</span>
          <span class="check-price" style="color:var(--text-3);font-weight:500">${date} · ${s.time}</span>
        </div>`;
      }).join('');
      return `
      <div class="step active">
        <div class="step-icon"><i class="fa-solid fa-calendar-days"></i></div>
        <h2>Preferred booking</h2>
        <p class="lead">Choose a flexible slot or set your preferred date and time.</p>

        <div class="check-item${flexOpen?' selected':''}" id="flexCheck">
          <div class="check-box"><i class="fa-solid fa-check"></i></div>
          <span class="check-label">I'm flexible on date and time</span>
        </div>
        <div id="flexSlots" class="${flexOpen?'':'hidden'}" style="margin-top:12px">
          <div class="section-label">Available time slots</div>
          <div class="check-list" id="flexSlotList">${slotsHtml}</div>
        </div>

        <div class="section-label" style="margin-top:20px">Or choose your preferred date &amp; time</div>
        <div class="field" id="fDate">
          <label>Preferred Date *</label>
          <input type="date" id="inpDate" value="${TC.esc(TC.data.booking.date)}" min="${new Date().toISOString().slice(0,10)}"/>
          <div class="field-error">Please select a date</div>
        </div>
        <div class="field">
          <label>Preferred Time</label>
          <input type="time" id="inpTime" value="${TC.esc(TC.data.booking.time||'09:00')}"/>
        </div>
        <div class="section-label">Time of day</div>
        <div class="choice-grid" id="periodChoices">
          ${['Morning','Afternoon'].map(p =>
            `<div class="choice${TC.data.booking.period===p?' selected':''}" TC.data-val="${p}"><i class="fa-solid fa-${p==='Morning'?'sun':'cloud-sun'}"></i>${p}</div>`
          ).join('')}
        </div>
        <div id="bookingAvailHint" class="callout hidden" style="margin-top:12px"></div>
      </div>`;
    }

    case 'instructions': return `
      <div class="step active">
        <div class="step-icon"><i class="fa-solid fa-comment-dots"></i></div>
        <h2>Special instructions</h2>
        <p class="lead">Anything else our team should know?</p>
        <div class="field">
          <label>Notes for the cleaning team</label>
          <textarea id="inpInstr" rows="5" placeholder="e.g. Please avoid the baby's room. Use fragrance-free products. We have a nervous dog — call before arrival.">${TC.esc(TC.data.instructions)}</textarea>
        </div>
        <div class="callout">Examples: focus areas, product allergies, pets that need special care, areas to avoid.</div>
      </div>`;

    case 'quote': {
      const q = TC.calcQuote();
      const extraLine = q.extraRooms > 0
        ? `<div class="quote-row"><span class="q-label">Extra rooms (${q.extraRooms} × R${TC.EXTRA_ROOM_RATE})</span><span class="q-value">R${q.roomsTotal.toLocaleString()}</span></div>`
        : `<div class="quote-row"><span class="q-label">Rooms included</span><span class="q-value">Up to ${q.includedRooms} rooms</span></div>`;
      const notesLine = TC.data.instructions
        ? `<div class="quote-row"><span class="q-label">Special notes</span><span class="q-value">${TC.esc(TC.data.instructions)}</span></div>`
        : '';
      const petsLine = TC.data.pets.has
        ? `<div class="quote-row"><span class="q-label">Pets</span><span class="q-value">${TC.esc((TC.data.pets.types||[]).join(', ')||'Yes')}${TC.data.pets.notes?' — '+TC.esc(TC.data.pets.notes):''}</span></div>`
        : '';
      return `
      <div class="step active">
        <div class="step-icon"><i class="fa-solid fa-file-invoice-dollar"></i></div>
        <h2>Your quote</h2>
        <p class="lead">Here's a clear breakdown based on your selections.</p>
        <div class="quote-card">
          <h3>Service & property</h3>
          <div class="quote-row"><span class="q-label">Service</span><span class="q-value">${TC.esc(TC.data.service||'—')}</span></div>
          <div class="quote-row"><span class="q-label">Property</span><span class="q-value">${TC.esc(TC.data.propertyType)} · ${TC.data.bedrooms} bed · ${TC.data.bathrooms} bath</span></div>
          <div class="quote-row"><span class="q-label">Rooms (${TC.data.rooms.length})</span><span class="q-value">${TC.data.rooms.length ? TC.data.rooms.join(', ') : '—'}</span></div>
          ${TC.data.addons.length?`<div class="quote-row"><span class="q-label">Add-ons</span><span class="q-value">${TC.data.addons.join(', ')}</span></div>`:''}
          ${petsLine}
          ${notesLine}
        </div>
        <div class="quote-card">
          <h3>Estimate</h3>
          <div class="quote-row"><span class="q-label">Base service (up to ${q.includedRooms} rooms)</span><span class="q-value">R${q.base.toLocaleString()}</span></div>
          ${extraLine}
          ${q.addonsTotal?`<div class="quote-row"><span class="q-label">Add-ons</span><span class="q-value">R${q.addonsTotal.toLocaleString()}</span></div>`:''}
          <div class="quote-row"><span class="q-label">Subtotal</span><span class="q-value">R${q.subtotal.toLocaleString()}</span></div>
          <div class="quote-row"><span class="q-label">VAT (15%)</span><span class="q-value">R${q.vat.toLocaleString()}</span></div>
          <div class="quote-total"><span class="q-label">Total</span><span class="q-value">R${q.total.toLocaleString()}</span></div>
        </div>
        <div class="quote-card">
          <h3>Team & duration</h3>
          <div class="quote-row"><span class="q-label">Estimated duration</span><span class="q-value">~${q.hours} hrs</span></div>
          <div class="quote-row"><span class="q-label">Team size</span><span class="q-value">${q.teamSize} cleaner${q.teamSize>1?'s':''}</span></div>
        </div>
        <button type="button" class="btn btn-secondary" id="btnViewQuoteDoc" style="width:100%;margin-bottom:12px">
          <i class="fa-solid fa-file-invoice"></i> View quote document
        </button>
        <div class="callout">This is an estimate. Final price is confirmed before your booking is locked in.</div>
      </div>`;
    }

    case 'confirm': {
      const q = TC.calcQuote();
      return `
      <div class="step active">
        <div class="step-icon"><i class="fa-solid fa-clipboard-check"></i></div>
        <h2>Confirm your booking</h2>
        <p class="lead">Please review everything before we proceed to payment.</p>
        <div class="quote-card">
          <h3>Contact</h3>
          <div class="quote-row"><span class="q-label">Name</span><span class="q-value">${TC.esc(TC.data.name)}</span></div>
          <div class="quote-row"><span class="q-label">Mobile</span><span class="q-value">${TC.esc(TC.data.phone)}</span></div>
          ${TC.data.email?`<div class="quote-row"><span class="q-label">Email</span><span class="q-value">${TC.esc(TC.data.email)}</span></div>`:''}
          <div class="quote-row"><span class="q-label">Address</span><span class="q-value">${TC.esc(TC.data.address)}</span></div>
          <div class="quote-row"><span class="q-label">Contact via</span><span class="q-value">${TC.esc(TC.data.commMethod)}</span></div>
        </div>
        <div class="quote-card">
          <h3>Booking</h3>
          <div class="quote-row"><span class="q-label">Date</span><span class="q-value">${TC.esc(TC.data.booking.date||'—')}</span></div>
          <div class="quote-row"><span class="q-label">Time</span><span class="q-value">${TC.esc(TC.data.booking.time||TC.data.booking.period)}</span></div>
          <div class="quote-row"><span class="q-label">Service</span><span class="q-value">${TC.esc(TC.data.service)}</span></div>
          <div class="quote-row"><span class="q-label">Rooms</span><span class="q-value">${TC.data.rooms.length} selected</span></div>
          <div class="quote-total"><span class="q-label">Total</span><span class="q-value">R${q.total.toLocaleString()}</span></div>
        </div>
        <button type="button" class="btn btn-secondary" id="btnViewQuoteDoc" style="width:100%;margin-top:4px">
          <i class="fa-solid fa-file-invoice"></i> View quote document
        </button>
        <a href="#" onclick="TC.openWhatsAppBooking();return false;" class="btn btn-primary btn-block" style="margin-top:10px;background:#25D366">
          <i class="fa-brands fa-whatsapp"></i> Send details on WhatsApp
        </a>
      </div>`;
    }

    case 'payment': {
      const q = TC.calcQuote();
      const poaAllowed = TC.canPayOnArrival();
      if (TC.data.paymentMethod === 'Pay on Arrival' && !poaAllowed) TC.data.paymentMethod = '';
      const payOpts = [
        { val: 'Card', icon: 'fa-credit-card', name: 'Card', desc: 'Instant confirmation · Visa, Mastercard, Yoco', rec: true, disabled: false },
        { val: 'Instant EFT', icon: 'fa-bolt', name: 'Instant EFT', desc: 'Instant confirmation via Ozow or PayFast', disabled: false },
        { val: 'EFT', icon: 'fa-building-columns', name: 'Manual EFT', desc: 'Confirmed once received · usually 1–2 business days', disabled: false },
        { val: 'Pay on Arrival', icon: 'fa-hand-holding-dollar', name: 'Pay on Arrival', desc: poaAllowed ? 'Cash or card with the team on the day' : 'Available for subscribers & customers with 4+ past bookings', disabled: !poaAllowed }
      ];
      return `
      <div class="step active">
        <div class="step-icon"><i class="fa-solid fa-credit-card"></i></div>
        <h2>Payment</h2>
        <p class="lead">Amount due: <strong style="color:var(--primary)">R${q.total.toLocaleString()}</strong> <span style="font-size:0.85rem;color:var(--text-3)">(incl. VAT)</span></p>
        <div class="section-label">Payment method</div>
        <div class="pay-grid" id="payChoices">
          ${payOpts.map(p => `
            <div class="pay-option${TC.data.paymentMethod===p.val?' selected':''}${p.disabled?' disabled':''}" TC.data-val="${p.val}" ${p.disabled?'aria-disabled="true"':''}>
              ${p.rec?'<span class="pay-rec">Recommended</span>':''}
              <span class="pay-name"><i class="fa-solid ${p.icon}"></i>${p.name}</span>
              <span class="pay-desc">${p.desc}</span>
            </div>`).join('')}
        </div>
        <div class="pay-secure"><i class="fa-solid fa-lock"></i> Secure checkout · select a method to continue · invoice issued immediately</div>
        ${!poaAllowed ? '<div class="callout" style="margin-top:12px">Pay on Arrival is locked until you are a subscriber or have more than 3 previous bookings. Please pay upfront to confirm.</div>' : ''}
        ${!TC.data.paymentMethod ? '<div class="callout" style="margin-top:12px">Please select a payment method to continue.</div>' : ''}
      </div>`;
    }

    case 'done': {
      const q = TC.calcQuote();
      const bn = TC.data.bookingNumber || TC.generateBookingNumber();
      TC.data.bookingNumber = bn;
      // Persist for customer dashboard
      try {
        const summary = {
          bookingNumber: bn,
          name: TC.data.name,
          phone: TC.data.phone,
          email: TC.data.email,
          address: TC.data.address,
          service: TC.data.service,
          rooms: TC.data.rooms,
          condition: TC.data.condition,
          addons: TC.data.addons,
          date: TC.data.booking.date,
          time: TC.data.booking.time || TC.data.booking.period,
          paymentMethod: TC.data.paymentMethod,
          notes: TC.data.instructions || '',
          total: q.total,
          hours: q.hours,
          teamSize: q.teamSize,
          createdAt: new Date().toISOString()
        };
        const list = JSON.parse(localStorage.getItem('tc_bookings') || '[]');
        if (!list.find(b => b.bookingNumber === bn)) list.unshift(summary);
        localStorage.setItem('tc_bookings', JSON.stringify(list.slice(0, 20)));
        localStorage.setItem('tc_profile', JSON.stringify({
          name: TC.data.name, phone: TC.data.phone, email: TC.data.email, address: TC.data.address, commMethod: TC.data.commMethod
        }));
        // Persist login account if they chose create
        if (TC.data.accountMode === 'create' && TC.data.accountEmail && TC.data.accountPassword) {
          TC.saveAccount({
            email: TC.data.accountEmail.toLowerCase(),
            password: TC.data.accountPassword,
            name: TC.data.name,
            phone: TC.data.phone,
            address: TC.data.address,
            commMethod: TC.data.commMethod
          });
          localStorage.setItem('tc_session', JSON.stringify({ email: TC.data.accountEmail.toLowerCase(), loggedIn: true, at: Date.now() }));
        }
      } catch(_){}
      return `
      <div class="step active">
        <div class="success-hero">
          <div class="success-icon"><i class="fa-solid fa-check"></i></div>
          <h2 style="font-size:1.5rem;font-weight:800;color:var(--navy)">You're all set!</h2>
          <p style="color:var(--text-2);margin-top:8px">Send your booking details on WhatsApp to confirm.</p>
          <div class="booking-number">${bn}</div>
        </div>
        <a href="#" onclick="TC.openWhatsAppBooking();return false;" class="btn btn-primary btn-block" style="margin-bottom:16px;background:#25D366">
          <i class="fa-brands fa-whatsapp"></i> Send booking to WhatsApp
        </a>
        <div class="quote-card">
          <h3>Appointment</h3>
          <div class="quote-row"><span class="q-label">Date</span><span class="q-value">${TC.esc(TC.data.booking.date)}</span></div>
          <div class="quote-row"><span class="q-label">Arrival window</span><span class="q-value">${TC.esc(TC.data.booking.time||TC.data.booking.period)}</span></div>
          <div class="quote-row"><span class="q-label">Service</span><span class="q-value">${TC.esc(TC.data.service)}</span></div>
          <div class="quote-row"><span class="q-label">Team</span><span class="q-value">${q.teamSize} cleaner${q.teamSize>1?'s':''} · ~${q.hours} hrs</span></div>
          <div class="quote-row"><span class="q-label">Total</span><span class="q-value" style="color:var(--primary)">R${q.total.toLocaleString()}</span></div>
        </div>
        <div class="section-label">What happens next</div>
        <div class="timeline">
          <div class="tl-item"><h4>Confirmation sent</h4><p>We've sent details via ${TC.esc(TC.data.commMethod)} to ${TC.esc(TC.data.phone||TC.data.email)}</p></div>
          <div class="tl-item"><h4>Reminders</h4><p>Automatic reminders 48 hrs, 24 hrs and 2 hrs before your appointment</p></div>
          <div class="tl-item"><h4>Cleaning day</h4><p>Team arrives, checks in, cleans, completes checklist and photos</p></div>
          <div class="tl-item"><h4>Aftercare</h4><p>Thank-you message, receipt, care tips — and a chance to leave feedback</p></div>
        </div>
        <div class="section-label">Preparation checklist</div>
        <ul class="prep-list">
          <li><i class="fa-solid fa-check-circle"></i> Clear surfaces and floors of clutter where possible</li>
          <li><i class="fa-solid fa-check-circle"></i> Secure pets or note any special handling</li>
          <li><i class="fa-solid fa-check-circle"></i> Ensure access codes / keys are ready</li>
          <li><i class="fa-solid fa-check-circle"></i> Point out any focus areas or fragile items</li>
        </ul>
        <div class="callout" style="margin-top:20px">
          ${TC.data.accountMode === 'create'
            ? '<strong>Your account has been created.</strong> Property and booking preferences are saved for faster rebooking next time.'
            : '<strong>You booked as a guest.</strong> Create an account anytime from your dashboard to save details for next time.'}
          ${TC.data._airtable ? '<br><span style="font-size:0.78rem;opacity:0.8">Client · Property · Booking linked in Airtable</span>' : ''}
        </div>
        <button type="button" class="btn btn-secondary" id="btnViewInvoiceDoc" style="width:100%;margin-top:12px">
          <i class="fa-solid fa-file-invoice-dollar"></i> View invoice
        </button>
        <a href="confirmation.html" class="btn btn-primary" style="width:100%;margin-top:10px;text-decoration:none"><i class="fa-solid fa-check"></i> View confirmation</a>
        <a href="tracking.html" class="btn btn-secondary" style="width:100%;margin-top:10px;text-decoration:none">Track cleaner</a>
        <a href="dashboard.html" class="btn btn-ghost" style="width:100%;margin-top:8px;text-decoration:none">Open dashboard</a>
      </div>`;
    }

    default: return '<div class="step active"><p>Unknown step</p></div>';
  }
}

TC.bindStepEvents = function(key) {
  // Generic choice grids
  document.querySelectorAll('.choice[TC.data-val]').forEach(el => {
    el.onclick = () => {
      const parent = el.parentElement;
      parent.querySelectorAll('.choice').forEach(c => c.classList.remove('selected'));
      el.classList.add('selected');
    };
  });

  if (key === 'welcome') {
    document.querySelectorAll('[TC.data-help]').forEach(el => {
      el.onclick = () => {
        document.querySelectorAll('[TC.data-help]').forEach(c => c.classList.remove('selected'));
        el.classList.add('selected');
      };
    });
  }

  if (key === 'account') {
    TC.$('accountChoices')?.querySelectorAll('.account-option').forEach(el => {
      el.onclick = () => {
        TC.$('accountChoices').querySelectorAll('.account-option').forEach(c => c.classList.remove('selected'));
        el.classList.add('selected');
        TC.data.accountMode = el.dataset.val;
        const showFields = TC.data.accountMode === 'create' || TC.data.accountMode === 'login';
        TC.$('accountFields')?.classList.toggle('hidden', !showFields);
        const hint = TC.$('accountHint');
        if (hint) {
          hint.innerHTML = TC.data.accountMode === 'login'
            ? 'Enter the email and password you used when you signed up. You’ll go straight to your dashboard.'
            : 'Account creation is optional and never blocks checkout. You can also create one after booking.';
        }
        const pw = TC.$('inpAccPassword');
        if (pw) pw.placeholder = TC.data.accountMode === 'login' ? 'Your password' : 'Choose a password';
      };
    });
    TC.$('resetPasswordLink')?.addEventListener('click', (e) => {
      e.preventDefault();
      TC.showAppModal({
        title: 'Reset password?',
        message: 'This clears saved accounts, profile and bookings on this device so you can start fresh.',
        type: 'info',
        confirmLabel: 'Clear TC.data',
        cancelLabel: 'Cancel',
        onConfirm: () => {
          try {
            localStorage.removeItem('tc_accounts');
            localStorage.removeItem('tc_session');
            localStorage.removeItem('tc_profile');
            localStorage.removeItem('tc_bookings');
            localStorage.removeItem('tc_onboarding_draft');
          } catch {}
          TC.data.accountEmail = '';
          TC.data.accountPassword = '';
          TC.showAppModal({ title: 'Data cleared', message: 'You can create a new account on the next booking.', type: 'success' });
        }
      });
    });
  }

  if (key === 'quote') {
    TC.$('btnApplyRecurring')?.addEventListener('click', () => {
      TC.data.service = 'Recurring Cleaning';
      TC.renderStep();
    });
    TC.$('btnViewQuoteDoc')?.addEventListener('click', () => TC.openDocModal('quote'));
  }
  if (key === 'confirm') {
    TC.$('btnViewQuoteDoc')?.addEventListener('click', () => TC.openDocModal('quote'));
  }
  if (key === 'done') {
    TC.$('btnViewInvoiceDoc')?.addEventListener('click', () => TC.openDocModal('invoice'));
  }

  if (key === 'details') {
    TC.$('commChoices')?.querySelectorAll('.choice').forEach(el => {
      el.onclick = () => {
        TC.$('commChoices').querySelectorAll('.choice').forEach(c => c.classList.remove('selected'));
        el.classList.add('selected');
        TC.data.commMethod = el.dataset.val;
      };
    });
  }

  if (key === 'service') {
    TC.$('serviceChoices')?.querySelectorAll('.choice').forEach(el => {
      el.onclick = () => {
        TC.$('serviceChoices').querySelectorAll('.choice').forEach(c => c.classList.remove('selected'));
        el.classList.add('selected');
        TC.data.service = el.dataset.val;
        TC.updatePriceBar();
      };
    });
  }

  if (key === 'property') {
    TC.$('propTypeChoices')?.querySelectorAll('.choice').forEach(el => {
      el.onclick = () => {
        TC.$('propTypeChoices').querySelectorAll('.choice').forEach(c => c.classList.remove('selected'));
        el.classList.add('selected');
        TC.data.propertyType = el.dataset.val;
      };
    });
  }

  if (key === 'rooms') {
    TC.$('roomList')?.querySelectorAll('.check-item').forEach(el => {
      el.onclick = () => {
        el.classList.toggle('selected');
        const val = el.dataset.val;
        if (el.classList.contains('selected')) {
          if (!TC.data.rooms.includes(val)) TC.data.rooms.push(val);
        } else {
          TC.data.rooms = TC.data.rooms.filter(r => r !== val);
        }
        TC.updatePriceBar();
      };
    });
  }

  if (key === 'condition') {
    TC.$('condChoices')?.querySelectorAll('.check-item').forEach(el => {
      el.onclick = () => {
        TC.$('condChoices').querySelectorAll('.check-item').forEach(c => c.classList.remove('selected'));
        el.classList.add('selected');
        TC.data.condition = el.dataset.val;
        TC.updatePriceBar();
      };
    });
  }

  if (key === 'products') {
    TC.$('prodList')?.querySelectorAll('.check-item').forEach(el => {
      el.onclick = () => {
        el.classList.toggle('selected');
        TC.data.products[el.dataset.val] = el.classList.contains('selected');
      };
    });
  }

  if (key === 'addons') {
    TC.$('addonList')?.querySelectorAll('.check-item').forEach(el => {
      el.onclick = () => {
        el.classList.toggle('selected');
        const val = el.dataset.val;
        if (el.classList.contains('selected')) {
          if (!TC.data.addons.includes(val)) TC.data.addons.push(val);
        } else {
          TC.data.addons = TC.data.addons.filter(a => a !== val);
        }
        TC.updatePriceBar();
      };
    });
    document.querySelectorAll('.upsell-chip').forEach(btn => {
      btn.onclick = () => {
        const a = btn.dataset.addon;
        if (!TC.data.addons.includes(a)) {
          TC.data.addons.push(a);
          btn.classList.add('added');
          btn.textContent = a + ' · added';
          // Reflect in checklist
          const item = document.querySelector('#addonList .check-item[TC.data-val="' + a + '"]');
          if (item) item.classList.add('selected');
          TC.updatePriceBar();
        }
      };
    });
  }

  if (key === 'pets') {
    TC.$('petHas')?.querySelectorAll('.choice').forEach(el => {
      el.onclick = () => {
        TC.$('petHas').querySelectorAll('.choice').forEach(c => c.classList.remove('selected'));
        el.classList.add('selected');
        TC.data.pets.has = el.dataset.val === 'yes';
        TC.$('petTypes')?.classList.toggle('hidden', !TC.data.pets.has);
        if (!TC.data.pets.has) TC.data.pets.types = [];
      };
    });
    TC.$('petTypeList')?.querySelectorAll('.check-item').forEach(el => {
      el.onclick = () => {
        el.classList.toggle('selected');
        const val = el.dataset.val;
        if (el.classList.contains('selected')) {
          if (!TC.data.pets.types.includes(val)) TC.data.pets.types.push(val);
        } else {
          TC.data.pets.types = TC.data.pets.types.filter(t => t !== val);
        }
      };
    });
  }

  if (key === 'access') {
    TC.$('someonePresent')?.querySelectorAll('.choice').forEach(el => {
      el.onclick = () => {
        TC.$('someonePresent').querySelectorAll('.choice').forEach(c => c.classList.remove('selected'));
        el.classList.add('selected');
        TC.data.access.someonePresent = el.dataset.val === 'yes';
      };
    });
  }

  if (key === 'property') {
    TC.$('petHas')?.querySelectorAll('.choice').forEach(el => {
      el.onclick = () => {
        TC.$('petHas').querySelectorAll('.choice').forEach(c => c.classList.remove('selected'));
        el.classList.add('selected');
        TC.data.pets.has = el.dataset.val === 'yes';
        TC.$('petTypes')?.classList.toggle('hidden', !TC.data.pets.has);
        if (!TC.data.pets.has) { TC.data.pets.types = []; TC.data.pets.notes = ''; }
      };
    });
    TC.$('petTypeList')?.querySelectorAll('.check-item').forEach(el => {
      el.onclick = () => {
        el.classList.toggle('selected');
        const val = el.dataset.val;
        if (el.classList.contains('selected')) {
          if (!TC.data.pets.types.includes(val)) TC.data.pets.types.push(val);
        } else {
          TC.data.pets.types = TC.data.pets.types.filter(t => t !== val);
        }
      };
    });
  }

  if (key === 'booking') {
    TC.$('periodChoices')?.querySelectorAll('.choice').forEach(el => {
      el.onclick = () => {
        TC.$('periodChoices').querySelectorAll('.choice').forEach(c => c.classList.remove('selected'));
        el.classList.add('selected');
        TC.data.booking.period = el.dataset.val;
      };
    });
    const flexCheck = TC.$('flexCheck');
    const flexSlots = TC.$('flexSlots');
    flexCheck?.addEventListener('click', () => {
      flexCheck.classList.toggle('selected');
      TC.data.booking.flexible = flexCheck.classList.contains('selected');
      flexSlots?.classList.toggle('hidden', !TC.data.booking.flexible);
      if (!TC.data.booking.flexible) {
        document.querySelectorAll('#flexSlotList .check-item').forEach(c => c.classList.remove('selected'));
      }
    });
    document.querySelectorAll('#flexSlotList .check-item').forEach(el => {
      el.onclick = () => {
        document.querySelectorAll('#flexSlotList .check-item').forEach(c => c.classList.remove('selected'));
        el.classList.add('selected');
        const idx = parseInt(el.dataset.flexSlot, 10);
        const slot = TC.FLEXIBLE_SLOTS[idx];
        if (slot) {
          TC.data.booking.date = TC.formatSlotDate(slot.dateOffset);
          TC.data.booking.time = slot.time;
          TC.data.booking.flexible = true;
          TC.data.booking.period = parseInt(slot.time.split(':')[0], 10) < 12 ? 'Morning' : 'Afternoon';
          if (TC.$('inpDate')) TC.$('inpDate').value = TC.data.booking.date;
          if (TC.$('inpTime')) TC.$('inpTime').value = TC.data.booking.time;
          flexCheck?.classList.add('selected');
          flexSlots?.classList.remove('hidden');
        }
      };
    });
    // When preferred date/time changes, check availability
    const checkAvail = () => {
      const date = TC.$('inpDate')?.value || '';
      const time = TC.$('inpTime')?.value || '';
      const hint = TC.$('bookingAvailHint');
      if (!hint || !date) { if (hint) hint.classList.add('hidden'); return; }
      if (!TC.isSlotAvailable(date, time)) {
        hint.classList.remove('hidden');
        hint.innerHTML = '<i class="fa-solid fa-circle-info"></i> That preferred time is unavailable. Please pick one of the <strong>flexible slots</strong> above, or choose another date/time (weekdays 08:00–17:00).';
        // Auto-open flexible slots
        TC.data.booking.flexible = true;
        flexCheck?.classList.add('selected');
        flexSlots?.classList.remove('hidden');
      } else {
        hint.classList.add('hidden');
      }
    };
    TC.$('inpDate')?.addEventListener('change', checkAvail);
    TC.$('inpTime')?.addEventListener('change', checkAvail);
  }

  if (key === 'payment') {
    TC.$('payChoices')?.querySelectorAll('.pay-option').forEach(el => {
      el.onclick = () => {
        if (el.classList.contains('disabled')) return;
        TC.$('payChoices').querySelectorAll('.pay-option').forEach(c => c.classList.remove('selected'));
        el.classList.add('selected');
        TC.data.paymentMethod = el.dataset.val;
      };
    });
  }
}

TC.collectCurrent = function() {
  const key = TC.activeSteps[TC.stepIndex];
  if (key === 'account') {
    TC.data.accountEmail = TC.$('inpAccEmail')?.value.trim() || '';
    TC.data.accountPassword = TC.$('inpAccPassword')?.value || '';
    if (TC.data.accountMode === 'create' && TC.data.accountEmail && !TC.data.email) TC.data.email = TC.data.accountEmail;
  }
  if (key === 'details') {
    TC.data.name = TC.$('inpName')?.value.trim() || '';
    TC.data.phone = TC.$('inpPhone')?.value.trim() || '';
    TC.data.email = TC.$('inpEmail')?.value.trim() || '';
    TC.data.address = TC.$('inpAddress')?.value.trim() || '';
  }
  if (key === 'property') {
    TC.data.bedrooms = parseInt(TC.$('inpBedrooms')?.value || '2', 10);
    TC.data.bathrooms = parseInt(TC.$('inpBathrooms')?.value || '1', 10);
    TC.data.pets.notes = TC.$('inpPetNotes')?.value.trim() || '';
  }
  if (key === 'access') {
    TC.data.access.gateCode = TC.$('inpGate')?.value.trim() || '';
    TC.data.access.estate = TC.$('inpEstate')?.value.trim() || '';
    TC.data.access.aptNumber = TC.$('inpApt')?.value.trim() || '';
    TC.data.access.floor = TC.$('inpFloor')?.value.trim() || '';
    TC.data.access.parking = TC.$('inpParking')?.value.trim() || '';
    TC.data.access.keyInstr = TC.$('inpKeys')?.value.trim() || '';
    // Map key instructions into Access Instructions for Airtable
    TC.data.access.instructions = TC.data.access.keyInstr || TC.data.access.instructions || '';
    TC.data.access.contactOnSite = TC.$('inpContactSite')?.value.trim() || '';
  }
  if (key === 'booking') {
    TC.data.booking.date = TC.$('inpDate')?.value || '';
    TC.data.booking.time = TC.$('inpTime')?.value || '';
  }
  if (key === 'instructions') {
    TC.data.instructions = TC.$('inpInstr')?.value.trim() || '';
  }
}

TC.validateCurrent = function() {
  const key = TC.activeSteps[TC.stepIndex];
  // clear errors
  document.querySelectorAll('.field').forEach(f => f.classList.remove('has-error'));

  if (key === 'details') {
    let ok = true;
    if (!TC.data.name || TC.data.name.length < 2) { TC.$('fName')?.classList.add('has-error'); ok = false; }
    if (!TC.data.phone || TC.data.phone.replace(/\D/g,'').length < 10) { TC.$('fPhone')?.classList.add('has-error'); ok = false; }
    if (!TC.data.address || TC.data.address.length < 5) { TC.$('fAddress')?.classList.add('has-error'); ok = false; }
    return ok;
  }
  if (key === 'service') {
    if (!TC.data.service) {
      // auto-pick Standard if none
      TC.data.service = 'Standard Cleaning';
    }
    return true;
  }
  if (key === 'property') {
    if (!TC.data.propertyType) TC.data.propertyType = 'House';
    // Auto-pre-select rooms as soon as they leave Property
    TC.data.rooms = TC.defaultRoomsFromProperty();
    return true;
  }
  if (key === 'rooms') {
    if (!TC.data.rooms.length) TC.data.rooms = TC.defaultRoomsFromProperty();
    return true;
  }
  if (key === 'account') {
    TC.data.accountEmail = TC.$('inpAccEmail')?.value.trim() || '';
    TC.data.accountPassword = TC.$('inpAccPassword')?.value || '';
    if (TC.data.accountMode === 'create') {
      if (!TC.data.accountEmail || !TC.data.accountEmail.includes('@')) {
        TC.showAppModal({ title: 'Email required', message: 'Please enter a valid email to create an account, or continue as guest.', type: 'info' });
        return false;
      }
      if (!TC.data.accountPassword || TC.data.accountPassword.length < 6) {
        TC.showAppModal({ title: 'Password too short', message: 'Please choose a password with at least 6 characters, or continue as guest.', type: 'info' });
        return false;
      }
      if (TC.data.accountEmail && !TC.data.email) TC.data.email = TC.data.accountEmail;
      return true;
    }
    if (TC.data.accountMode === 'login') {
      if (!TC.data.accountEmail || !TC.data.accountPassword) {
        TC.showAppModal({ title: 'Sign in', message: 'Please enter your email and password.', type: 'info' });
        return false;
      }
      const acc = TC.findAccount(TC.data.accountEmail, TC.data.accountPassword);
      if (!acc) {
        TC.showAppModal({ title: 'Login failed', message: 'No account matches that email and password. Check your details or create an account.', type: 'error' });
        return false;
      }
      // Load profile + session — admins go to admin dashboard
      localStorage.setItem('tc_profile', JSON.stringify({
        name: acc.name || '', phone: acc.phone || '', email: acc.email,
        address: acc.address || '', commMethod: acc.commMethod || 'WhatsApp'
      }));
      localStorage.setItem('tc_session', JSON.stringify({ email: acc.email, loggedIn: true, at: Date.now() }));
      const ADMIN_EMAILS = ['admin@terracelest.com','nicole@terracelest.com','support@terracelest.com'];
      const isAdmin = ADMIN_EMAILS.includes(String(acc.email || '').toLowerCase());
      window.location.href = isAdmin ? 'admin.html' : 'dashboard.html?settings=1';
      return false; // stop wizard navigation
    }
    return true;
  }
  if (key === 'booking') {
    TC.data.booking.date = TC.$('inpDate')?.value || TC.data.booking.date || '';
    TC.data.booking.time = TC.$('inpTime')?.value || TC.data.booking.time || '';
    if (!TC.data.booking.date) {
      TC.$('fDate')?.classList.add('has-error');
      return false;
    }
    if (!TC.isSlotAvailable(TC.data.booking.date, TC.data.booking.time)) {
      const hint = TC.$('bookingAvailHint');
      if (hint) {
        hint.classList.remove('hidden');
        hint.innerHTML = '<i class="fa-solid fa-circle-info"></i> That preferred time is unavailable. Please select a flexible slot above or another weekday between 08:00 and 17:00.';
      }
      TC.data.booking.flexible = true;
      TC.$('flexCheck')?.classList.add('selected');
      TC.$('flexSlots')?.classList.remove('hidden');
      TC.showAppModal({
        title: 'Time unavailable',
        message: 'Your preferred date/time is not available. Please choose one of the flexible slots, or pick a weekday between 08:00 and 17:00.',
        type: 'info'
      });
      return false;
    }
    return true;
  }
  if (key === 'payment') {
    if (!TC.data.paymentMethod) {
      TC.showAppModal({
        title: 'Select a payment method',
        message: 'Please choose how you’d like to pay before continuing.',
        type: 'info'
      });
      return false;
    }
    if (TC.data.paymentMethod === 'Pay on Arrival' && !TC.canPayOnArrival()) {
      TC.data.paymentMethod = '';
      TC.showAppModal({
        title: 'Payment method unavailable',
        message: 'Pay on Arrival is only available for subscribers and customers with more than 3 previous bookings. Please choose an upfront payment method.',
        type: 'info'
      });
      return false;
    }
    return true;
  }
  return true;
}

TC.buildDocHTML = function(type) {
  const q = TC.calcQuote();
  const isInvoice = type === 'invoice';
  const title = isInvoice ? 'Tax Invoice' : 'Quotation';
  const ref = isInvoice
    ? (TC.data.bookingNumber || TC.generateBookingNumber())
    : ('Q-' + (TC.data.bookingNumber || TC.generateBookingNumber()).replace('TC-', ''));
  const today = new Date().toLocaleDateString('en-ZA', { day: 'numeric', month: 'short', year: 'numeric' });
  const lines = [];
  lines.push({ desc: (TC.data.service || 'Cleaning service') + ' (up to ' + TC.INCLUDED_ROOMS + ' rooms)', amt: q.base });
  if (q.extraRooms > 0) {
    lines.push({ desc: 'Extra rooms (' + q.extraRooms + ' × R' + TC.EXTRA_ROOM_RATE + '): ' + TC.data.rooms.join(', '), amt: q.roomsTotal });
  } else if (TC.data.rooms.length) {
    lines.push({ desc: 'Rooms included (' + TC.data.rooms.length + '): ' + TC.data.rooms.join(', '), amt: 0 });
  }
  TC.data.addons.forEach(a => {
    lines.push({ desc: 'Add-on: ' + a, amt: TC.ADDON_PRICES[a] || 0 });
  });

  return `
    <div class="doc-page">
      <div class="doc-page-head">
        <div class="doc-brand-block">
          <div class="doc-brand-icon"><img src="logo.png" alt="" style="width:28px;height:28px;object-fit:contain;"></div>
          <div>
            <strong>TerraCelest</strong>
            <span>Professional home cleaning · Gauteng</span>
          </div>
        </div>
        <div class="doc-meta">
          <div class="doc-type">${title}</div>
          <div>${ref}</div>
          <div>${today}</div>
        </div>
      </div>
      <div class="doc-parties">
        <div>
          <h4>From</h4>
          <p>TerraCelest<br>hello@terracelest.co.za<br>082 123 4567<br>Johannesburg &amp; Pretoria</p>
        </div>
        <div>
          <h4>${isInvoice ? 'Bill to' : 'Prepared for'}</h4>
          <p>${TC.esc(TC.data.name || '—')}<br>${TC.esc(TC.data.phone || '')}<br>${TC.esc(TC.data.email || '')}<br>${TC.esc(TC.data.address || '')}</p>
        </div>
      </div>
      ${TC.data.booking.date ? `<p style="font-size:0.82rem;color:var(--text-2);margin-bottom:12px"><strong>Service date:</strong> ${TC.esc(TC.data.booking.date)} · ${TC.esc(TC.data.booking.time || TC.data.booking.period)}</p>` : ''}
      <table class="doc-table">
        <thead><tr><th>Description</th><th style="text-align:right">Amount</th></tr></thead>
        <tbody>
          ${lines.map(l => `<tr><td>${TC.esc(l.desc)}</td><td class="amt">R${Number(l.amt).toLocaleString()}</td></tr>`).join('')}
        </tbody>
      </table>
      <div class="doc-totals">
        <div class="row"><span>Subtotal</span><span>R${q.subtotal.toLocaleString()}</span></div>
        <div class="row"><span>VAT (15%)</span><span>R${q.vat.toLocaleString()}</span></div>
        <div class="row grand"><span>Total</span><span>R${q.total.toLocaleString()}</span></div>
      </div>
      <div class="doc-notes">
        <strong>${isInvoice ? 'Payment' : 'Validity'}</strong><br>
        ${isInvoice
          ? 'Payment method: ' + TC.esc(TC.data.paymentMethod || '—') + '. Thank you for choosing TerraCelest. A receipt is issued once payment is confirmed.'
          : 'This quotation is valid for 14 days. Final price is confirmed before booking is locked in. Duration ~' + q.hours + ' hrs · ' + q.teamSize + ' cleaner' + (q.teamSize > 1 ? 's' : '') + '.'}
        ${TC.data.instructions ? '<br><br><strong>Notes</strong><br>' + TC.esc(TC.data.instructions) : ''}
      </div>
    </div>`;
}

TC.openDocModal = function(type) {
  const modal = TC.$('docModal');
  const body = TC.$('docBody');
  const title = TC.$('docModalTitle');
  if (!modal || !body) return;
  title.textContent = type === 'invoice' ? 'Invoice' : 'Quote document';
  body.innerHTML = TC.buildDocHTML(type);
  modal.classList.add('open');
  document.body.style.overflow = 'hidden';
}

TC.closeDocModal = function() {
  TC.$('docModal')?.classList.remove('open');
  document.body.style.overflow = '';
}

TC.buildWhatsAppMessage = function() {
  const q = TC.calcQuote();
  const bn = TC.data.bookingNumber || TC.generateBookingNumber();
  TC.data.bookingNumber = bn;
  const isQuoteOnly = TC.activeSteps[TC.stepIndex] === 'quote' || TC.data.accountMode === 'quote';
  const lines = [
    'Hi TerraCelest 👋',
    '',
    isQuoteOnly
      ? 'Please send me a *free quote* for the following:'
      : 'I would like to *confirm a booking* for the following:',
    '',
    '*Service:* ' + (TC.data.service || 'Spring Deep Clean'),
    '*Name:* ' + (TC.data.name || '—'),
    '*Phone:* ' + (TC.data.phone || '—'),
    TC.data.email ? ('*Email:* ' + TC.data.email) : null,
    '*Address:* ' + (TC.data.address || '—'),
    '',
    '*Preferred date:* ' + (TC.data.booking?.date || 'Flexible / TBC'),
    '*Time window:* ' + (TC.data.booking?.time || TC.data.booking?.period || 'Morning / flexible'),
    '*Rooms:* ' + ((TC.data.rooms && TC.data.rooms.length) ? TC.data.rooms.join(', ') : 'Up to 4 rooms'),
    TC.data.condition ? ('*Home condition:* ' + TC.data.condition) : null,
    (TC.data.addons && TC.data.addons.length) ? ('*Add-ons:* ' + TC.data.addons.join(', ')) : null,
    '*Pets:* ' + (TC.data.pets?.has ? (TC.data.pets.types?.join(', ') || 'Yes') : 'No'),
    '',
    '*Quoted total:* R' + (q.total ? q.total.toLocaleString() : '750') + ' (incl. estimate)',
    TC.data.paymentMethod ? ('*Payment:* ' + TC.data.paymentMethod) : null,
    TC.data.instructions ? ('*Notes:* ' + TC.data.instructions) : null,
    '',
    '*Ref:* ' + bn,
    '',
    isQuoteOnly
      ? 'Please reply with availability and a final quote. Thank you!'
      : 'Please confirm this booking and next steps. Thank you!'
  ].filter(function(x){ return x !== null && x !== undefined && x !== ''; });
  return lines.join('\n');
}

TC.openWhatsAppBooking = function() {
  const text = encodeURIComponent(TC.buildWhatsAppMessage());
  window.open('https://wa.me/27848642597?text=' + text, '_blank');
}

TC.useMyLocation = async function() {
  if (!window.TerraAirtable || !TerraAirtable.captureLocation) {
    tcAlert('Location capture not available');
    return;
  }
  try {
    const btn = document.getElementById('btnUseLocation');
    if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Locating…'; }
    const loc = await TerraAirtable.captureLocation();
    TC.data.lat = loc.lat;
    TC.data.lng = loc.lng;
    TC.data.addressObj = loc;
    TC.data.address = loc.full || [loc.street, loc.suburb, loc.city, loc.postal].filter(Boolean).join(', ');
    const inp = document.getElementById('inpAddress');
    if (inp) inp.value = TC.data.address;
    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-location-crosshairs"></i> Use my location'; }
    if (window.tcAlert) tcAlert('Location captured. Please confirm the address is correct.');
  } catch (e) {
    const btn = document.getElementById('btnUseLocation');
    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-location-crosshairs"></i> Use my location'; }
    tcAlert(e.message || 'Could not get location. Allow location permission and try again.');
  }
}

})(window);

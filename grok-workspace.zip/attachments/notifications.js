/**
 * TerraCelest Notification Engine
 * Pages trigger events; this module owns creation, dedupe, storage, and deep-links.
 *
 * Usage:
 *   TerraNotifications.bookingCreated(booking)
 *   TerraNotifications.paymentReceived(booking)
 *   TerraNotifications.event('custom_type', { title, body, action, bookingId, role })
 */
(function (w) {
  'use strict';

  const STORAGE_KEY = 'tc_notifications';
  const EVENT_KEY = 'tc_notification_events'; // set of "type:entityId" already fired
  const MAX = 50;

  function readList() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'); }
    catch { return []; }
  }
  function writeList(list) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list.slice(0, MAX)));
  }
  function readEvents() {
    try { return JSON.parse(localStorage.getItem(EVENT_KEY) || '{}'); }
    catch { return {}; }
  }
  function writeEvents(map) {
    localStorage.setItem(EVENT_KEY, JSON.stringify(map));
  }

  function hasEvent(type, entityId) {
    if (!entityId) return false;
    const map = readEvents();
    return !!map[type + ':' + String(entityId)];
  }
  function markEvent(type, entityId) {
    if (!entityId) return;
    const map = readEvents();
    map[type + ':' + String(entityId)] = Date.now();
    // prune old entries (> 90 days)
    const cutoff = Date.now() - 90 * 24 * 3600 * 1000;
    Object.keys(map).forEach(k => { if (map[k] < cutoff) delete map[k]; });
    writeEvents(map);
  }

  function fmtDate(b) {
    if (!b) return '';
    const d = b.date || b.scheduled_date || '';
    const t = b.time || b.scheduled_time || '';
    return [d, t].filter(Boolean).join(' at ') || 'your scheduled time';
  }

  function create(opts) {
    const {
      type,
      title,
      body,
      actionLabel,
      actionUrl,
      bookingId,
      role,          // 'client' | 'worker' | 'admin' | 'all'
      entityId,      // for dedupe; defaults to bookingId
      force          // skip dedupe
    } = opts;

    const eid = entityId || bookingId || type;
    if (!force && hasEvent(type, eid)) {
      return null; // anti-duplication
    }

    const item = {
      id: 'n_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
      type: type || 'general',
      title: title || 'Update',
      body: body || '',
      actionLabel: actionLabel || null,
      actionUrl: actionUrl || null,
      bookingId: bookingId || null,
      role: role || 'client',
      unread: true,
      createdAt: new Date().toISOString(),
      time: 'Just now'
    };

    const list = readList();
    list.unshift(item);
    writeList(list);
    markEvent(type, eid);
    updateBadges();
    return item;
  }

  /* ---------- Public event helpers ---------- */

  function accountCreated(profile) {
    const name = (profile && profile.name) || 'there';
    const role = (profile && profile.role) || (localStorage.getItem('tc_role') || 'client');
    const dest = role === 'worker' ? 'worker-dashboard.html'
      : role === 'admin' ? 'admin.html' : 'dashboard.html';
    return create({
      type: 'account_created',
      title: 'Your account is ready',
      body: 'Welcome to TerraCelest, ' + name + '.',
      actionLabel: 'Go to Dashboard',
      actionUrl: dest,
      role: role === 'worker' ? 'worker' : 'client',
      entityId: (profile && (profile.email || profile.phone || profile.contact)) || 'account'
    });
  }

  function bookingCreated(booking) {
    if (!booking) return null;
    const id = booking.id || booking.bookingNumber;
    return create({
      type: 'booking_created',
      title: 'Booking received',
      body: 'We\'ve received your TerraCelest cleaning request for ' + fmtDate(booking) + '.',
      actionLabel: 'View Booking',
      actionUrl: 'booking-details.html?id=' + encodeURIComponent(id),
      bookingId: id,
      role: 'client',
      entityId: id
    });
  }

  function paymentReceived(booking) {
    if (!booking) return null;
    const id = booking.id || booking.bookingNumber;
    create({
      type: 'payment_received',
      title: 'Payment received',
      body: 'Your payment has been received and your booking is being confirmed.',
      actionLabel: 'View Confirmation',
      actionUrl: 'confirmation.html?id=' + encodeURIComponent(id),
      bookingId: id,
      role: 'client',
      entityId: id
    });
    // Confirmed is a separate one-time event
    return create({
      type: 'booking_confirmed',
      title: 'Booking confirmed',
      body: 'Your TerraCelest cleaning is confirmed for ' + fmtDate(booking) + '.',
      actionLabel: 'Track My Booking',
      actionUrl: 'tracking.html?id=' + encodeURIComponent(id),
      bookingId: id,
      role: 'client',
      entityId: id
    });
  }

  function paymentFailed(booking) {
    if (!booking) return null;
    const id = booking.id || booking.bookingNumber;
    return create({
      type: 'payment_failed',
      title: 'Payment unsuccessful',
      body: 'We couldn\'t complete your payment. You can try again anytime.',
      actionLabel: 'Try Payment Again',
      actionUrl: 'checkout.html?id=' + encodeURIComponent(id),
      bookingId: id,
      role: 'client',
      entityId: id + '_fail_' + Date.now(), // allow retry notifications
      force: true
    });
  }

  function bookingRescheduled(booking) {
    if (!booking) return null;
    const id = booking.id || booking.bookingNumber;
    return create({
      type: 'booking_rescheduled',
      title: 'Booking updated',
      body: 'Your cleaning has been moved to ' + fmtDate(booking) + '.',
      actionLabel: 'View Booking',
      actionUrl: 'booking-details.html?id=' + encodeURIComponent(id),
      bookingId: id,
      role: 'client',
      entityId: id + '_reschedule_' + (booking.date || '') + '_' + (booking.time || ''),
      force: true
    });
  }

  function bookingCancelled(booking) {
    if (!booking) return null;
    const id = booking.id || booking.bookingNumber;
    return create({
      type: 'booking_cancelled',
      title: 'Booking cancelled',
      body: 'Your TerraCelest booking has been cancelled.',
      actionLabel: 'Book Again',
      actionUrl: 'booking.html',
      bookingId: id,
      role: 'client',
      entityId: id
    });
  }

  function cleanerAssigned(booking, cleanerName) {
    if (!booking) return null;
    const id = booking.id || booking.bookingNumber;
    const name = cleanerName || 'Your cleaner';
    return create({
      type: 'cleaner_assigned',
      title: 'Cleaner assigned',
      body: name + ' has been assigned to your booking.',
      actionLabel: 'View Booking',
      actionUrl: 'booking-details.html?id=' + encodeURIComponent(id),
      bookingId: id,
      role: 'client',
      entityId: id
    });
  }

  function cleanerOnWay(booking) {
    if (!booking) return null;
    const id = booking.id || booking.bookingNumber;
    return create({
      type: 'cleaner_on_way',
      title: 'Your cleaner is on the way',
      body: 'Your TerraCelest cleaner is travelling to your home.',
      actionLabel: 'Track Cleaner',
      actionUrl: 'tracking.html?id=' + encodeURIComponent(id),
      bookingId: id,
      role: 'client',
      entityId: id
    });
  }

  function cleanerArrived(booking) {
    if (!booking) return null;
    const id = booking.id || booking.bookingNumber;
    return create({
      type: 'cleaner_arrived',
      title: 'Your cleaner has arrived',
      body: 'Your cleaner is at the property.',
      actionLabel: 'Track',
      actionUrl: 'tracking.html?id=' + encodeURIComponent(id),
      bookingId: id,
      role: 'client',
      entityId: id
    });
  }

  function cleaningStarted(booking) {
    if (!booking) return null;
    const id = booking.id || booking.bookingNumber;
    return create({
      type: 'cleaning_started',
      title: 'Cleaning has started',
      body: 'Your TerraCelest clean is in progress.',
      bookingId: id,
      role: 'client',
      entityId: id
    });
  }

  function cleaningCompleted(booking) {
    if (!booking) return null;
    const id = booking.id || booking.bookingNumber;
    return create({
      type: 'cleaning_completed',
      title: 'Your clean is complete',
      body: 'We hope your home feels fresh. Tell us how we did.',
      actionLabel: 'Rate Your Cleaning',
      actionUrl: 'post-job.html?id=' + encodeURIComponent(id),
      bookingId: id,
      role: 'client',
      entityId: id
    });
  }

  function reviewRequested(booking) {
    if (!booking) return null;
    const id = booking.id || booking.bookingNumber;
    return create({
      type: 'review_requested',
      title: 'How was your clean?',
      body: 'Rate your experience and leave an optional tip.',
      actionLabel: 'Rate Your Cleaning',
      actionUrl: 'post-job.html?id=' + encodeURIComponent(id),
      bookingId: id,
      role: 'client',
      entityId: id
    });
  }

  function reviewSubmitted(booking) {
    if (!booking) return null;
    const id = booking.id || booking.bookingNumber;
    return create({
      type: 'review_submitted',
      title: 'Thank you for your feedback',
      body: 'Your review has been submitted successfully.',
      actionLabel: 'View Bookings',
      actionUrl: 'mybookings.html',
      bookingId: id,
      role: 'client',
      entityId: id
    });
  }

  function jobAvailable(job) {
    const id = (job && (job.id || job.title)) || ('job_' + Date.now());
    return create({
      type: 'job_available',
      title: 'New cleaning available',
      body: (job && job.title) ? job.title + ' is available in your area.' : 'A cleaning job matching your area is available.',
      actionLabel: 'View Job',
      actionUrl: 'jobs.html' + (job && job.id ? '?id=' + encodeURIComponent(job.id) : ''),
      role: 'worker',
      entityId: id,
      force: true
    });
  }

  function jobAccepted(job) {
    return create({
      type: 'job_accepted',
      title: 'Job accepted',
      body: 'The cleaning has been added to your schedule.',
      actionLabel: 'View Active Job',
      actionUrl: 'worker-dashboard.html',
      role: 'worker',
      entityId: (job && job.id) || ('accepted_' + Date.now()),
      force: true
    });
  }

  function promotionSpring() {
    if (localStorage.getItem('tc_spring_promo_2026')) return null;
    localStorage.setItem('tc_spring_promo_2026', '1');
    return create({
      type: 'promotion_spring',
      title: 'Spring Deep Clean — R750',
      body: 'Kitchen, lounge, bathroom & bedroom. Book your spring special.',
      actionLabel: 'Book My Deep Clean',
      actionUrl: 'booking.html',
      role: 'client',
      entityId: 'spring_2026'
    });
  }

  /* ---------- Inbox API ---------- */

  function listForRole(role) {
    const r = role || localStorage.getItem('tc_role') || 'client';
    return readList().filter(n => {
      if (!n.role || n.role === 'all') return true;
      if (r === 'admin') return true;
      return n.role === r || (r === 'guest' && n.role === 'client');
    });
  }

  function getUnreadCount(role) {
    return listForRole(role).filter(n => n.unread).length;
  }

  function markAsRead(id) {
    const list = readList();
    const item = list.find(n => n.id === id);
    if (item) item.unread = false;
    writeList(list);
    updateBadges();
    return item;
  }

  function markAllAsRead(role) {
    const r = role || localStorage.getItem('tc_role') || 'client';
    const list = readList();
    list.forEach(n => {
      if (!n.role || n.role === 'all' || n.role === r || r === 'admin') n.unread = false;
    });
    writeList(list);
    updateBadges();
  }

  function openAction(id) {
    const item = markAsRead(id);
    if (item && item.actionUrl) {
      location.href = item.actionUrl;
    }
  }

  function updateBadges() {
    const count = getUnreadCount();
    document.querySelectorAll('[data-notif-badge]').forEach(el => {
      if (count > 0) {
        el.textContent = count > 9 ? '9+' : String(count);
        el.style.display = '';
        el.classList.remove('hide');
      } else {
        el.textContent = '';
        el.style.display = 'none';
        el.classList.add('hide');
      }
    });
  }

  // relative time labels
  function refreshTimeLabels() {
    const list = readList();
    const now = Date.now();
    list.forEach(n => {
      const t = n.createdAt ? new Date(n.createdAt).getTime() : now;
      const mins = Math.floor((now - t) / 60000);
      if (mins < 1) n.time = 'Just now';
      else if (mins < 60) n.time = mins + 'm ago';
      else if (mins < 1440) n.time = Math.floor(mins / 60) + 'h ago';
      else n.time = Math.floor(mins / 1440) + 'd ago';
    });
    writeList(list);
  }

  const api = {
    event: create,
    create,
    hasEvent,
    accountCreated,
    bookingCreated,
    paymentReceived,
    paymentFailed,
    bookingRescheduled,
    bookingCancelled,
    cleanerAssigned,
    cleanerOnWay,
    cleanerArrived,
    cleaningStarted,
    cleaningCompleted,
    reviewRequested,
    reviewSubmitted,
    jobAvailable,
    jobAccepted,
    promotionSpring,
    listForRole,
    getUnreadCount,
    markAsRead,
    markAllAsRead,
    openAction,
    updateBadges,
    refreshTimeLabels
  };

  w.TerraNotifications = api;

  // Bridge legacy tcNotify → generic event (no dedupe entity)
  w.tcNotify = function (title, body) {
    create({
      type: 'general',
      title: title || 'Update',
      body: body || '',
      role: localStorage.getItem('tc_role') || 'client',
      entityId: 'general_' + Date.now(),
      force: true
    });
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      refreshTimeLabels();
      updateBadges();
    });
  } else {
    refreshTimeLabels();
    updateBadges();
  }
})(window);

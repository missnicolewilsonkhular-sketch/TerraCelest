/**
 * TerraCelest Booking — Pricing
 */
(function (w) {
  'use strict';
  var TC = w.TCBooking = w.TCBooking || {};

TC.calcQuote = function() {
  const base = TC.SERVICE_PRICES[TC.data.service] || 750;
  const roomCount = TC.data.rooms.length;
  const extraRooms = Math.max(0, roomCount - TC.INCLUDED_ROOMS);
  const roomsTotal = extraRooms * TC.EXTRA_ROOM_RATE;
  let addonsTotal = 0;
  TC.data.addons.forEach(a => { addonsTotal += (TC.ADDON_PRICES[a] || 0); });
  const subtotal = base + roomsTotal + addonsTotal;
  const vat = Math.round(subtotal * 0.15);
  const total = subtotal + vat;
  // duration estimate: 45min base + 25min per room + 15min per addon
  const minutes = 45 + roomCount * 25 + TC.data.addons.length * 15;
  const hours = Math.max(1, Math.round(minutes / 60 * 10) / 10);
  const teamSize = hours > 4 ? 3 : hours > 2.5 ? 2 : 1;
  return { base, roomsTotal, addonsTotal, subtotal, vat, total, hours, teamSize, roomCount, extraRooms, includedRooms: TC.INCLUDED_ROOMS };
}

TC.updatePriceBar = function() {
  const pill = TC.$('pricePill');
  const bottom = TC.$('bottomPrice');
  if (!pill || !bottom) return;
  const showFrom = TC.activeSteps.indexOf('rooms');
  const hideOn = ['welcome','account','details','service','property','done'];
  const key = TC.activeSteps[TC.stepIndex];
  const shouldShow = showFrom >= 0 && TC.stepIndex >= showFrom && !hideOn.includes(key) && (TC.data.rooms.length > 0 || TC.data.service);

  if (shouldShow) {
    const q = TC.calcQuote();
    const totalStr = 'R' + q.total.toLocaleString();
    const metaStr = '~' + q.hours + ' hrs · ' + q.teamSize + ' cleaner' + (q.teamSize > 1 ? 's' : '');
    const changed = TC.lastPriceTotal !== null && TC.lastPriceTotal !== q.total;

    TC.$('pricePillTotal').textContent = totalStr;
    TC.$('bottomPriceTotal').textContent = totalStr;
    TC.$('bottomPriceMeta').textContent = metaStr;

    pill.classList.add('visible');
    bottom.classList.add('visible');

    if (changed) {
      pill.classList.remove('pulse');
      bottom.classList.remove('pulse');
      void pill.offsetWidth;
      pill.classList.add('pulse');
      bottom.classList.add('pulse');
      setTimeout(() => { pill.classList.remove('pulse'); bottom.classList.remove('pulse'); }, 500);
    }
    TC.lastPriceTotal = q.total;
  } else {
    pill.classList.remove('visible');
    bottom.classList.remove('visible');
  }
}

TC.jumpToQuote = function() {
  const qi = TC.activeSteps.indexOf('quote');
  if (qi < 0) return;
  const roomsIdx = TC.activeSteps.indexOf('rooms');
  if (roomsIdx >= 0 && TC.stepIndex < roomsIdx) return;
  TC.collectCurrent();
  TC.stepIndex = qi;
  TC.renderStep();
}

})(window);

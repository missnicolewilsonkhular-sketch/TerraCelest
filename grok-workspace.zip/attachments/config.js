/**
 * TerraCelest Booking — Config
 */
(function (w) {
  'use strict';
  var TC = w.TCBooking = w.TCBooking || {};


  TC.MAX_ACTIVE_BOOKINGS = 3;

  TC.STEPS = [
    'welcome','account','details','service','property','rooms',
    'addons','access','booking','instructions',
    'quote','confirm','payment','done'
  ];

  TC.RETURNING_STEPS = [
    'service','property','rooms',
    'addons','access','booking','instructions',
    'quote','confirm','payment','done'
  ];

  TC.STEP_TITLES = {
  welcome: 'Welcome', account: 'Account', details: 'Your Details', service: 'Service Type',
  property: 'Property Info', rooms: 'Select Rooms',
  addons: 'Add-On Services',
  access: 'Access Info', booking: 'Preferred Date', instructions: 'Special Notes',
  quote: 'Your Quote', confirm: 'Confirm Booking', payment: 'Payment', done: 'Confirmed'
};

  TC.UPSELL_MAP = {
  'Kitchen': ['Inside Oven', 'Inside Fridge', 'Dish Washing'],
  'Bathroom': ['Wall Spot Cleaning'],
  'En-suite Bathroom': ['Wall Spot Cleaning'],
  'Lounge': ['Blind Cleaning', 'Ceiling Fan Cleaning'],
  'Main Bedroom': ['Blind Cleaning'],
  'Guest Bedroom': ['Blind Cleaning'],
  'Balcony': ['Balcony Cleaning'],
  'Garage': ['Garage Cleaning'],
  'Patio': ['Patio Cleaning']
};

// Pricing model (ZAR)
// Promotional / standard base covers up to 4 rooms; extra rooms charged separately.
  TC.INCLUDED_ROOMS = 4;
  TC.EXTRA_ROOM_RATE = 80;
  TC.SERVICE_PRICES = {
  'Standard Cleaning': 450,
  'Deep Cleaning': 750,
  'Spring Cleaning': 750,
  'Spring Clean': 750,
  'Move-In Cleaning': 900,
  'Move-Out Cleaning': 950,
  'Recurring Cleaning': 400,
  'Standard': 450,
  'Deep Clean': 750
};
  TC.ROOM_LIST = [
  'Kitchen', 'Main Bedroom', 'Guest Bedroom', 'Bathroom',
  'En-suite Bathroom', 'Lounge', 'Dining Room', 'Laundry',
  'Balcony', 'Garage', 'Study', 'Patio'
];
// Kept for legacy references; individual room prices no longer shown on selection
  TC.ROOM_PRICES = {
  'Kitchen': 80, 'Main Bedroom': 80, 'Guest Bedroom': 80, 'Bathroom': 80,
  'En-suite Bathroom': 80, 'Lounge': 80, 'Dining Room': 80, 'Laundry': 80,
  'Balcony': 80, 'Garage': 80, 'Study': 80, 'Patio': 80
};
  TC.CONDITION_MULT = {
  'Light Cleaning': 1.0, 'Normal Cleaning': 1.0, 'Heavy Dirt': 1.0,
  'Very Dirty': 1.0, 'Post Renovation': 1.0
};
  TC.ADDON_PRICES = {
  'Inside Oven': 150, 'Inside Fridge': 120, 'Interior Windows': 100,
  'Exterior Windows': 180, 'Wall Spot Cleaning': 80, 'Dish Washing': 60,
  'Laundry': 90, 'Ironing': 80, 'Balcony Cleaning': 70, 'Garage Cleaning': 100,
  'Patio Cleaning': 80, 'Blind Cleaning': 60, 'Ceiling Fan Cleaning': 50
};

/** Available flexible time slots (demo / illustrative) */
  TC.FLEXIBLE_SLOTS = [
  { dateOffset: 1, time: '09:00', label: 'Tomorrow morning' },
  { dateOffset: 1, time: '14:00', label: 'Tomorrow afternoon' },
  { dateOffset: 2, time: '09:00', label: 'In 2 days · morning' },
  { dateOffset: 2, time: '14:00', label: 'In 2 days · afternoon' },
  { dateOffset: 3, time: '10:00', label: 'In 3 days · mid-morning' },
  { dateOffset: 4, time: '09:00', label: 'In 4 days · morning' },
  { dateOffset: 5, time: '13:00', label: 'In 5 days · afternoon' }
];


})(window);

# TerraCelest Database Standards

## Primary Field
- Every table must have a **Name** field as the primary field (human-readable).
- IDs live in a separate field (Auto Number or generated): Booking ID, Client ID, Invoice ID, EMP-0001, etc.
- Note: Existing autoNumber primary tables cannot be converted via API — recreate in UI if required.

## Dates & Times
- Time zone: **Africa/Johannesburg (SAST)**
- Display: DD MMMM YYYY HH:mm (e.g. 04 August 2026 15:45)
- Every table: **Created Date** (Created Time), **Last Modified Date** (Last Modified Time)
- Note: Created/Modified Time fields must be added in Airtable UI where missing (API cannot create them).

## Currency
- All money fields: **ZAR (R)**, 2 decimal places. Never mix currencies.

## Soft Delete
- **Deleted** (Checkbox)
- **Deleted Date** (DateTime, SAST)
- **Deleted By** (optional, Collaborator or Text)
- Never permanently delete records.

## Recommended Fields (Every Table)
1. Name (primary)
2. Reference Number (unique, e.g. BK-000001)
3. Status (Single Select — table-specific options)
4. Created Date
5. Created By
6. Last Modified Date
7. Last Modified By
8. Deleted
9. Deleted Date
10. Deleted By
11. Active (Checkbox — for master data)
12. Notes (Long text)
13. Tags (Multiple select)

## Status Examples
- **Booking:** Draft, Pending, Confirmed, Assigned, In Progress, Completed, Cancelled, No Show
- **Invoice:** Draft, Sent, Partially Paid, Paid, Overdue, Cancelled
- **Quote:** Draft, Sent, Accepted, Declined, Expired
- **Task:** To Do, In Progress, Blocked, Done, Cancelled
- **Client:** Active, Lead, Inactive, Archived
- **Team:** Active, On Leave, Probation, Suspended, Resigned, Terminated, Retired

## Ownership & Audit
- Created By, Assigned To, Last Modified By on operational tables.
- Full audit: Created/Modified dates + by, Deleted + date + by.

## Attachments
- Standard names: Photos, Documents, Files

## Unique Reference Numbers
- BK-, QT-, INV-, PAY-, CLI-, PROP-, EMP-, EXP- prefixes with zero-padded sequences.

## Applied (2026-08-04)
- Added to tables: Deleted, Active, Notes, Tags, Deleted Date
- Status added where operational (Bookings, Invoices, Quotes, Tasks, Payments, Expenses, Clients, Team Members patterns)
- Text primary fields renamed to Name where safe
- AutoNumber primaries left unchanged (API limitation)

# TerraCelest

Professional **home cleaning** booking PWA for Ekurhuleni East (South Africa).  
Spring special from **R750** · Quote → Book → Pay → Track → Review.

---

## Quick start

### Option A — local static server (required for PWA)

```bash
cd tr508-new
npx --yes serve -p 3000
# or: python3 -m http.server 3000
```

Open `http://localhost:3000/splash.html`.

> `file://` will break service worker, install prompt, and some browser APIs. Use a local server or HTTPS host.

### Option B — static host

Deploy the entire `tr508-new/` folder to Netlify, Vercel, Cloudflare Pages, Firebase Hosting, etc.

**Start URL:** `splash.html` (also set in `manifest.json`).

---

## What’s in the box

| Path | Role |
|------|------|
| `*.html` | App screens |
| `booking.html` + `booking.css` + `booking/*.js` | Modular booking wizard |
| `styles.css` | Design system + fixed-viewport shell |
| `app.js` | Booking schema, roles, modals, swipe-back |
| `nav.js` | Bottom nav / drawer |
| `notifications.js` | Event notifications + dedupe |
| `airtable.js` | Airtable API client & field mapping |
| `pwa.js` / `sw.js` / `manifest.json` | Installable PWA |
| `icons/` | Logo-derived app icons |
| `docs/` | Product spec, UI/UX, Airtable mapping |

---

## Main user flow

```
index / dashboard
    → booking.html (?mode=quote | ?mode=book)
    → checkout.html?id=...
    → confirmation.html?id=...
    → tracking.html?id=...
    → post-job.html?id=...
```

- **Get a free quote** → estimate; writes **Quotes** (no payment).  
- **Book now** → full path through payment.

---

## Configuration

### Airtable

Configured in `airtable.js`:

- Base ID: `appgzWiwsyL0qAisg` (TerraCelest)
- Auth: Personal Access Token (PAT)

**Production warning:** Move the PAT to a backend proxy. Client-side tokens can be extracted from the bundle.

### WhatsApp

Prefill number used in booking/landing deep links: `27848642597` (update in HTML/JS if needed).

### Brand

- Primary teal: `#00A69C`
- Navy: `#0B1D3A`
- Logo: `logo.png` → generated `icons/*`

---

## Roles (localStorage `tc_role`)

| Value | Home |
|-------|------|
| `guest` | `index.html` |
| `client` | `dashboard.html` |
| `worker` | `worker-dashboard.html` |
| `admin` | `admin.html` |

Sign-in codes are stored in Airtable **Users.PIN** (plain text in MVP).

---

## Scripts load order (typical app page)

```html
<script src="airtable.js"></script>
<script src="app.js"></script>
<script src="notifications.js"></script>
<script src="nav.js"></script>
<script src="pwa.js"></script>
```

---

## Documentation

| Document | Description |
|----------|-------------|
| [docs/PRODUCT_SPECIFICATION.md](docs/PRODUCT_SPECIFICATION.md) | Full product spec |
| [docs/UI_UX.md](docs/UI_UX.md) | UI/UX system & patterns |
| [docs/AIRTABLE_MAPPING.md](docs/AIRTABLE_MAPPING.md) | Tables & field mapping |

---

## Known MVP limits

- Payments are **simulated** (no Yoco/PayFast/Ozow)
- Worker & admin boards are largely **mock**
- Tracking progress is **demo timers**, not live GPS
- Airtable PAT must not ship in production frontend

---

## Project layout (screens)

```
splash → onboarding → index / auth
dashboard, booking, checkout, confirmation, tracking
mybookings, booking-details, post-job, reviews
notifications, account, settings, support, chat, help, rewards
worker-dashboard, jobs, cleaner_profile, admin
careers, about, privacy, terms, verify, 404
```

---

## License / ownership

Proprietary — TerraCelest Facilities. All rights reserved unless otherwise agreed.

/**
 * TerraCelest Core Application Framework (app.js)
 * Includes zero-popup modal and toast system + state helpers.
 */
(function (window, document) {
  'use strict';

  // --- In-App Modal Dialog (Replaces native alert/confirm) ---
  function showAppModal(opts) {
    var existing = document.getElementById('tcGlobalModal');
    if (existing) existing.remove();

    var overlay = document.createElement('div');
    overlay.id = 'tcGlobalModal';
    overlay.className = 'modal-overlay open';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');

    var type = opts.type || 'info';
    var iconClass = type === 'error' ? 'fa-circle-exclamation' :
                    type === 'success' ? 'fa-circle-check' :
                    type === 'warning' ? 'fa-triangle-exclamation' : 'fa-circle-info';
    var iconColor = type === 'error' ? 'var(--error)' :
                    type === 'success' ? 'var(--success)' : 'var(--primary)';

    overlay.innerHTML = `
      <div class="modal" style="max-width:380px; padding:24px 20px; text-align:center; animation:modalIn 0.25s ease;">
        <div style="font-size:2.2rem; color:${iconColor}; margin-bottom:12px;">
          <i class="fa-solid ${iconClass}"></i>
        </div>
        <h3 style="font-size:1.15rem; font-weight:800; color:var(--navy); margin-bottom:6px;">${opts.title || 'TerraCelest'}</h3>
        <p style="font-size:0.9rem; color:var(--text-2); line-height:1.5; margin-bottom:18px;">${opts.message || ''}</p>
        <div style="display:flex; gap:10px;">
          ${opts.cancelLabel ? `<button type="button" class="btn btn-secondary" id="tcModalCancel" style="flex:1;">${opts.cancelLabel}</button>` : ''}
          <button type="button" class="btn btn-primary" id="tcModalOk" style="flex:1;">${opts.confirmLabel || 'OK'}</button>
        </div>
      </div>
    `;

    document.body.appendChild(overlay);

    return new Promise(function (resolve) {
      document.getElementById('tcModalOk').onclick = function () {
        overlay.remove();
        resolve(true);
      };
      if (opts.cancelLabel) {
        document.getElementById('tcModalCancel').onclick = function () {
          overlay.remove();
          resolve(false);
        };
      }
      overlay.onclick = function (e) {
        if (e.target === overlay) {
          overlay.remove();
          resolve(false);
        }
      };
    });
  }

  // --- In-App Toast Notification (Bottom Floating Snackbar) ---
  function showToast(message, type) {
    var existing = document.getElementById('tcGlobalToast');
    if (existing) existing.remove();

    var toast = document.createElement('div');
    toast.id = 'tcGlobalToast';
    var bg = type === 'error' ? 'var(--error)' : (type === 'success' ? 'var(--success)' : 'var(--navy)');
    toast.style.cssText = `
      position: fixed; bottom: calc(24px + var(--safe-b, 0px)); left: 50%; transform: translateX(-50%) translateY(20px);
      background: ${bg}; color: #fff; padding: 12px 20px; border-radius: 99px; font-size: 0.88rem; font-weight: 700;
      box-shadow: 0 8px 24px rgba(0,0,0,0.25); z-index: 99999; opacity: 0; transition: all 0.25s ease; pointer-events: none;
      display: flex; align-items: center; gap: 8px; max-width: 90%; text-align: center;
    `;
    toast.innerHTML = `<i class="fa-solid ${type==='error'?'fa-circle-exclamation':(type==='success'?'fa-circle-check':'fa-bell')}"></i> ${message}`;
    document.body.appendChild(toast);

    requestAnimationFrame(function () {
      toast.style.opacity = '1';
      toast.style.transform = 'translateX(-50%) translateY(0)';
    });

    setTimeout(function () {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(-50%) translateY(10px)';
      setTimeout(function () { toast.remove(); }, 300);
    }, 2800);
  }

  // Override standard alerts with in-app promises
  window.tcAlert = function (message, title) {
    return showAppModal({ title: title || 'TerraCelest', message: String(message), type: 'info', confirmLabel: 'OK' });
  };

  window.tcConfirm = function (message, title) {
    return showAppModal({ title: title || 'Confirm Action', message: String(message), type: 'warning', confirmLabel: 'Yes, Proceed', cancelLabel: 'Cancel' });
  };

  window.tcToast = showToast;
  window.tcNotify = function (title, body) { showToast(title + ': ' + body, 'info'); };

  // --- Booking Query and Storage Helpers ---
  window.tcQueryId = function () {
    var params = new URLSearchParams(window.location.search);
    return params.get('id') || params.get('ref') || params.get('bookingNumber') || '';
  };

  window.tcGetBooking = function (id) {
    var list = JSON.parse(localStorage.getItem('tc_bookings') || '[]');
    if (!id && list.length) return list[0];
    return list.find(function (b) { return b.id === id || b.bookingNumber === id; }) || null;
  };

  window.tcSaveBooking = function (booking) {
    var list = JSON.parse(localStorage.getItem('tc_bookings') || '[]');
    var ref = booking.bookingNumber || booking.id;
    var idx = list.findIndex(function (b) { return (b.bookingNumber || b.id) === ref; });
    if (idx >= 0) list[idx] = Object.assign({}, list[idx], booking);
    else list.unshift(booking);
    localStorage.setItem('tc_bookings', JSON.stringify(list.slice(0, 30)));
  };

  window.tcListBookings = function () {
    return JSON.parse(localStorage.getItem('tc_bookings') || '[]');
  };
})(window, document);

/* --- Dem-X Enhanced Site-Wide Loader --- */
(function() {
  var loader = document.createElement("div");
  loader.id = "demx-sparkle-loader";
  loader.style.cssText = "position:fixed;inset:0;z-index:9999;background:var(--surface);display:flex;align-items:center;justify-content:center;opacity:0;pointer-events:none;transition:opacity 0.4s ease;visibility:hidden;";
  
  var canvas = document.createElement("canvas");
  canvas.id = "demx-sparkle-canvas";
  canvas.style.cssText = "position:absolute;inset:0;width:100%;height:100%;";
  
  var spinner = document.createElement("div");
  spinner.style.cssText = "width:48px;height:48px;border:4px solid var(--border);border-top-color:var(--primary);border-radius:50%;animation:spin 0.8s linear infinite;z-index:2;";
  
  loader.appendChild(canvas);
  loader.appendChild(spinner);
  document.body.appendChild(loader);

  var ctx = canvas.getContext("2d");
  var particles = [];
  var w, h, animId;
  
  function resize() { w = canvas.width = window.innerWidth; h = canvas.height = window.innerHeight; }
  window.addEventListener("resize", resize);
  resize();

  function createParticle() {
    return { x: Math.random()*w, y: Math.random()*h, size: Math.random()*3+1, speedY: Math.random()*1+0.5, opacity: Math.random(), fade: Math.random()*0.02+0.005 };
  }
  for(var i=0; i<60; i++) particles.push(createParticle());

  function animate() {
    ctx.clearRect(0,0,w,h);
    var style = getComputedStyle(document.documentElement);
    var color = style.getPropertyValue("--primary").trim() || "#00A69C";
    
    particles.forEach(function(p) {
      p.y -= p.speedY;
      p.opacity -= p.fade;
      if(p.opacity <= 0 || p.y < 0) Object.assign(p, createParticle(), {y: h, opacity: 0});
      p.opacity += p.fade; 
      if(p.opacity > 1) p.opacity = 1;
      
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI*2);
      ctx.fillStyle = color;
      ctx.globalAlpha = p.opacity;
      ctx.fill();
    });
    animId = requestAnimationFrame(animate);
  }

  function show() { loader.style.visibility="visible"; loader.style.opacity="1"; loader.style.pointerEvents="auto"; if(!animId) animate(); }
  function hide() { loader.style.opacity="0"; loader.style.pointerEvents="none"; loader.style.visibility="hidden"; cancelAnimationFrame(animId); animId=null; }

  window.addEventListener("beforeunload", show);
  document.addEventListener("click", function(e) { if(e.target.closest("a[href]") && !e.target.closest("a[href^=\"#\"]") && !e.target.closest("a[target=\"_blank\"]")) show(); });
  window.addEventListener("pageshow", hide);
  window.addEventListener("DOMContentLoaded", hide);
})();

/* --- Dem-X Scroll Reveal Module --- */
(function() {
  var style = document.createElement("style");
  style.textContent = ".demx-reveal{opacity:0;transform:translateY(30px);transition:opacity 0.6s ease,transform 0.6s ease}.demx-reveal.visible{opacity:1;transform:translateY(0)}";
  document.head.appendChild(style);

  var targets = document.querySelectorAll(".hero-section,.services-grid-container,.pathways-grid,.coverage-pill-row,.card");
  targets.forEach(function(el){ el.classList.add("demx-reveal"); });

  if ("IntersectionObserver" in window) {
    var obs = new IntersectionObserver(function(entries) {
      entries.forEach(function(e) {
        if (e.isIntersecting) { e.target.classList.add("visible"); obs.unobserve(e.target); }
      });
    }, { threshold: 0.15 });
    targets.forEach(function(el){ obs.observe(el); });
  } else {
    targets.forEach(function(el){ el.classList.add("visible"); });
  }
})();
